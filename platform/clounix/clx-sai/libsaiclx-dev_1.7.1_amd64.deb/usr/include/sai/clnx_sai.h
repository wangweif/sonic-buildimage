#if !defined (__CLNX_SAI_H_)
#define __CLNX_SAI_H_

#include <clnx_sai_version.h>
#ifndef CLNX_SAI_HEAD_VERSION
#define CLNX_SAI_HEAD_VERSION                 "1.7.1"
#endif

#ifdef CLX_SDK
#include <clx_types.h>
#include <clx_module.h>
#include <clx_vm.h>
#include <clx_init.h>
#include <clx_error.h>
#include <clx_lag.h>
#include <clx_ifmon.h>
#include <clx_acl.h>
#include <clx_swc.h>
#include <clx_l3t.h>
#include <clx_netif.h>
#include <clx_pkt.h>
#include <clx_fcoe.h>
#include <clx_l3.h>
#include <clx_stk.h>
#include <clx_nv.h>
#include <clx_sec.h>
#include <clx_mpls.h>
#include <clx_port.h>
#include <clx_l2.h>
#include <clx_stp.h>
#include <clx_ver.h>
#include <clx_mir.h>
#include <clx_cfg.h>
#include <clx_meter.h>
#include <clx_trill.h>
#include <clx_vlan.h>
#include <clx_tm.h>
#include <clx_stat.h>
#include <clx_qos.h>
#include <clx_dtel.h>
#include <cdb/cdb.h>
#include <osal/osal_types.h>
#include <osal/osal.h>
#include <osal/osal_lib.h>
#include <osal/osal_dma.h>
#endif

#include <sai.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <stdarg.h>
#include <assert.h>
#include <inttypes.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <clnx_sdk.h>
#include <hal/common/hal_io.h>


#define SAI_PACKET_ACTION_MAX           8
#define END_FUNCTIONALITY_ATTRIBS_ID    0xFFFFFFFF
#define CLNX_OBJ_EXTENDED_DATA_SIZE      3
#define MAX_KEY_STR_LEN                 100
#define MAX_VALUE_STR_LEN               100
#define MAX_LIST_VALUE_STR_LEN          1000
#ifdef PATH_MAX
#undef PATH_MAX
#endif
#define PATH_MAX                        256


extern sai_service_method_table_t       g_services;
extern const sai_policer_api_t          policer_api;
extern const sai_port_api_t             port_api;
extern const sai_qos_map_api_t          qosmap_api;
extern const sai_queue_api_t            queue_api;
extern const sai_route_api_t            route_api;
extern const sai_router_interface_api_t routerinterface_api;
extern const sai_rpf_group_api_t        rpfgroup_api;
extern const sai_samplepacket_api_t     samplepacket_api;
extern const sai_scheduler_api_t        scheduler_api;
extern const sai_scheduler_group_api_t  schedulergroup_api;
extern const sai_stp_api_t              stp_api;
extern const sai_switch_api_t           switch_api;
extern const sai_tunnel_api_t           tunnel_api;
extern const sai_udf_api_t              udf_api;
extern const sai_virtual_router_api_t   virtualrouter_api;
extern const sai_vlan_api_t             vlan_api;
extern const sai_wred_api_t             wred_api;
extern const sai_acl_api_t              acl_api;
extern const sai_bridge_api_t           bridge_api;
extern const sai_buffer_api_t           buffer_api;
extern const sai_fdb_api_t              fdb_api;
extern const sai_hash_api_t             hash_api;
extern const sai_hostif_api_t           hostif_api;
extern const sai_ipmc_api_t             ipmc_api;
extern const sai_ipmc_group_api_t       ipmcgroup_api;
extern const sai_l2mc_api_t             l2mc_api;
extern const sai_l2mc_group_api_t       l2mcgroup_api;
extern const sai_lag_api_t              lag_api;
extern const sai_mcast_fdb_api_t        mcastfdb_api;
extern const sai_mirror_api_t           mirror_api;
extern const sai_neighbor_api_t         neighbor_api;
extern const sai_next_hop_api_t         nexthop_api;
extern const sai_next_hop_group_api_t   nexthopgroup_api;
extern const sai_mpls_api_t             mpls_api;
extern const sai_segmentroute_api_t     segmentroute_api;
//extern const sai_tam_api_t              tam_api;
#if SAI_VERSION_CODE < SAI_VER(1,4,1)
extern const sai_uburst_api_t           uburst_api;
#endif
extern const sai_dtel_api_t               dtel_api;
extern const sai_bfd_api_t               bfd_api;
#if SAI_VERSION_CODE >= SAI_VER(1,4,0)
extern const sai_isolation_group_api_t   isolationgroup_api;
#endif
#if SAI_VERSION_CODE >= SAI_VER(1,5,0)
extern const sai_counter_api_t counter_api;
extern const sai_debug_counter_api_t debug_counter_api;
#endif
extern const sai_status_t               ext_clx_status_to_sai_map[CLX_E_LAST];
extern const char*                      ext_sai_type_to_str_map[SAI_OBJECT_TYPE_MAX];
extern const CLX_FWD_ACTION_T           ext_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];
extern const sai_packet_action_t        ext_clx_action_to_sai_map[CLX_FWD_ACTION_LAST];
extern const CLX_FWD_ACTION_T           swc_sai_action_to_clx_map[SAI_PACKET_ACTION_MAX];
#if SAI_VERSION_CODE >= SAI_VER(1,4,0)
extern const sai_isolation_group_api_t   isolationgroup_api;
#endif
#if SAI_VERSION_CODE >= SAI_VER(1,5,0)
extern const sai_nat_api_t   nat_api;

#endif
#if SAI_VERSION_CODE >= SAI_VER(1,6,0)
extern const sai_macsec_api_t   macsec_api;
extern const sai_system_port_api_t   system_port_api;
#endif
/*
 *  SAI operation type
 *  Values must start with 0 base and be without gaps
 */
typedef enum sai_operation_t {
    SAI_OPERATION_CREATE,
    SAI_OPERATION_REMOVE,
    SAI_OPERATION_SET,
    SAI_OPERATION_GET,
    SAI_OPERATION_MAX
} sai_operation_t;

/*
 *  Attribute value types
 */
typedef enum _sai_attribute_value_type_t {
    SAI_ATTR_VAL_TYPE_UNDETERMINED,
    SAI_ATTR_VAL_TYPE_BOOL,
    SAI_ATTR_VAL_TYPE_CHARDATA,
    SAI_ATTR_VAL_TYPE_U8,
    SAI_ATTR_VAL_TYPE_S8,
    SAI_ATTR_VAL_TYPE_U16,
    SAI_ATTR_VAL_TYPE_S16,
    SAI_ATTR_VAL_TYPE_U32,
    SAI_ATTR_VAL_TYPE_S32,
    SAI_ATTR_VAL_TYPE_U64,
    SAI_ATTR_VAL_TYPE_S64,
    SAI_ATTR_VAL_TYPE_MAC,
    SAI_ATTR_VAL_TYPE_IPV4,
    SAI_ATTR_VAL_TYPE_IPV6,
    SAI_ATTR_VAL_TYPE_IPADDR,
    SAI_ATTR_VAL_TYPE_OID,
    SAI_ATTR_VAL_TYPE_OBJLIST,
    SAI_ATTR_VAL_TYPE_U8LIST,
    SAI_ATTR_VAL_TYPE_S8LIST,
    SAI_ATTR_VAL_TYPE_U16LIST,
    SAI_ATTR_VAL_TYPE_S16LIST,
    SAI_ATTR_VAL_TYPE_U32LIST,
    SAI_ATTR_VAL_TYPE_S32LIST,
    SAI_ATTR_VAL_TYPE_U32RANGE,
    SAI_ATTR_VAL_TYPE_S32RANGE,
    SAI_ATTR_VAL_TYPE_MAPLIST,
    SAI_ATTR_VAL_TYPE_VLANLIST,
    SAI_ATTR_VAL_TYPE_QOSMAP,
    SAI_ATTR_VAL_TYPE_TUNNELMAP,
    SAI_ATTR_VAL_TYPE_ACLFIELD_BOOLDATA,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U8,
    SAI_ATTR_VAL_TYPE_ACLFIELD_S8,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U16,
    SAI_ATTR_VAL_TYPE_ACLFIELD_S16,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U32,
    SAI_ATTR_VAL_TYPE_ACLFIELD_S32,
    SAI_ATTR_VAL_TYPE_ACLFIELD_MAC,
    SAI_ATTR_VAL_TYPE_ACLFIELD_IPV4,
    SAI_ATTR_VAL_TYPE_ACLFIELD_IPV6,
    SAI_ATTR_VAL_TYPE_ACLFIELD_OID,
    SAI_ATTR_VAL_TYPE_ACLFIELD_OBJLIST,
    SAI_ATTR_VAL_TYPE_ACLFIELD_U8LIST,
    SAI_ATTR_VAL_TYPE_ACLACTION_U8,
    SAI_ATTR_VAL_TYPE_ACLACTION_S8,
    SAI_ATTR_VAL_TYPE_ACLACTION_U16,
    SAI_ATTR_VAL_TYPE_ACLACTION_S16,
    SAI_ATTR_VAL_TYPE_ACLACTION_U32,
    SAI_ATTR_VAL_TYPE_ACLACTION_S32,
    SAI_ATTR_VAL_TYPE_ACLACTION_MAC,
    SAI_ATTR_VAL_TYPE_ACLACTION_IPV4,
    SAI_ATTR_VAL_TYPE_ACLACTION_IPV6,
    SAI_ATTR_VAL_TYPE_ACLACTION_OID,
    SAI_ATTR_VAL_TYPE_ACLACTION_OBJLIST,
    SAI_ATTR_VAL_TYPE_ACLACTION_NONE,
    SAI_ATTR_VAL_TYPE_ACLCAPABILITY,
    SAI_ATTR_VALUE_TYPE_ACL_RESOURCE_LIST,
    SAI_ATTR_VALUE_TYPE_TLV_LIST,
    SAI_ATTR_VALUE_TYPE_SEGMENT_LIST,
    SAI_ATTR_VALUE_TYPE_IP_ADDRESS_LIST,
    SAI_ATTR_VALUE_TYPE_PORT_EYE_VALUES_LIST,
    SAI_ATTR_VALUE_TYPE_TIMESPEC,
    SAI_ATTR_VALUE_TYPE_OUTSEG,
    SAI_ATTR_VALUE_TYPE_OUTSEG_TTL,
    SAI_ATTR_VALUE_TYPE_OUTSEG_EXP,
    SAI_ATTR_VALUE_TYPE_SYSTEM_PORT_CONFIG_LIST,
    SAI_ATTR_VALUE_TYPE_PORT_ERR_STATUS_LIST,
    SAI_ATTR_VALUE_TYPE_FABRIC_PORT_REACHABILITY
} sai_attribute_value_type_t;

typedef struct _sai_attribute_entry_t {
    sai_attr_id_t              id;
    bool                       mandatory_on_create;
    bool                       valid_for_create;
    bool                       valid_for_set;
    bool                       valid_for_get;
    const char                *attrib_name;
    sai_attribute_value_type_t type;
} sai_attribute_entry_t;

typedef struct _clnx_object_id_t {
    sai_uint8_t  object_type;
    sai_uint8_t  extended_data[CLNX_OBJ_EXTENDED_DATA_SIZE];
    sai_uint32_t data;
} clnx_object_id_t;

typedef sai_status_t (*sai_attribute_set_fn)(
    _In_ const sai_object_key_t *key,
    _In_ const sai_attribute_value_t *value,
         void *arg);

typedef union {
    int dummy;
} vendor_cache_t;

typedef sai_status_t (*sai_attribute_get_fn)(
    _In_ const sai_object_key_t *key,
    _Inout_ sai_attribute_value_t *value,
    _In_ uint32_t attr_index, _Inout_ vendor_cache_t *cache, void *arg);

typedef struct _sai_vendor_attribute_entry_t {
    sai_attr_id_t        id;
    bool                 is_implemented[SAI_OPERATION_MAX];
    bool                 is_supported[SAI_OPERATION_MAX];
    sai_attribute_get_fn getter;
    void                *getter_arg;
    sai_attribute_set_fn setter;
    void                *setter_arg;
} sai_vendor_attribute_entry_t;

 typedef enum {
    MUTEX_TYPE_NORMAL=0,
    MUTEX_TYPE_RECURSIVE,
     /*now i only need this type, want more? define it here*/
    MUTEX_TYPE_MAX
 }mutex_type_t;
CLX_SEMAPHORE_ID_T clnx_sai_create_mutex(_In_ int type);
CLX_ERROR_NO_T clnx_sai_destroy_mutex(CLX_SEMAPHORE_ID_T  ptr_semaphore_id);
int clnx_sai_mutex_lock(_In_ CLX_SEMAPHORE_ID_T sema);
int clnx_sai_mutex_unlock(_In_ CLX_SEMAPHORE_ID_T sema);

extern sai_vendor_attribute_entry_t* vendor_attributes[];
extern uint32_t    vendor_attributes_count[];
#define OBJECT_VENDOR_ATTRIBUTE_REGISTER(object_type, attributes)  \
    do { \
        if ((object_type) < SAI_OBJECT_TYPE_MAX)          \
        {\
            vendor_attributes[(object_type)] = (sai_vendor_attribute_entry_t*)(&attributes);             \
            vendor_attributes_count[(object_type)] = sizeof(attributes)/sizeof(sai_vendor_attribute_entry_t);       \
        }\
        else        \
            CLNX_LOG_ERR(__MODULE__, "error object type %d", object_type);       \
    } while(0)

 #define SAI_TYPE_STR(__type__)     \
    ({int t = (__type__); t< SAI_OBJECT_TYPE_MAX ? ext_sai_type_to_str_map[t] : "Unknown object type";})
#define CLNX_STATUS_TO_SAI(__rc__)  \
    ({CLX_ERROR_NO_T tmp = (__rc__); ((tmp < CLX_E_LAST) ? ext_clx_status_to_sai_map[tmp] : CLX_E_LAST);})
#define CLNX_LOG_PRINT(module, severity, fmt, arg ...)                       \
    do {                                                                    \
        clnx_utils_print(module, severity,                                   \
                        "%s:%d " fmt,  __FUNCTION__,__LINE__, ## arg);                 \
    } while (0)
#define CLNX_LOG_PRINT_WITHOUT_CODE_INFO(module, severity, fmt, arg ...)                \
    do {                                                                    \
        clnx_utils_print(module, severity, fmt, ## arg);                 \
    } while (0)

#define CLNX_LOG_TYPE_SAI      0
#define CLNX_LOG_TYPE_DIAG   1
#define CLNX_LOG_DBG(module, fmt, arg ...)     CLNX_LOG_PRINT(module, SAI_LOG_LEVEL_DEBUG,   fmt, ## arg)
#define CLNX_LOG_INF(module, fmt, arg ...)     CLNX_LOG_PRINT(module, SAI_LOG_LEVEL_INFO,    fmt, ## arg)
#define CLNX_LOG_WRN(module, fmt, arg ...)     CLNX_LOG_PRINT(module, SAI_LOG_LEVEL_WARN,    fmt, ## arg)
#define CLNX_LOG_ERR(module, fmt, arg ...)     CLNX_LOG_PRINT(module, SAI_LOG_LEVEL_ERROR,   fmt, ## arg)
#define CLNX_LOG_NTC(module, fmt, arg ...)     CLNX_LOG_PRINT(module, SAI_LOG_LEVEL_NOTICE,  fmt, ## arg)
#define CLNX_LOG_CTL(module, fmt, arg ...)     CLNX_LOG_PRINT(module, SAI_LOG_LEVEL_CRITICAL,fmt, ## arg)

#define CHECK_RET_FAIL_RETURN(ret, unlock, level, fmt, arg ...)  do {\
    if ((ret)!= SAI_STATUS_SUCCESS) \
    {\
        (void)(unlock);\
        CLNX_LOG_##level(__MODULE__, fmt" "#ret"=%d", ##arg, (ret));\
        return ret;\
    }\
}while (0)
#define CHECK_RET_ERR_RETURN(fmt, arg ...)  CHECK_RET_FAIL_RETURN(ret, (ret), ERR, fmt, ##arg)
#define CHECK_RET_ERR_CLEAR_RETURN(unlock, fmt, arg ...)  CHECK_RET_FAIL_RETURN(ret, unlock, ERR, fmt, ##arg)

#define CHECK_RC_FAIL_RETURN(rc, unlock, level, fmt, arg ...)  do {\
    if ((rc)!= CLX_E_OK) \
    {\
        (void)(unlock);\
        CLNX_LOG_##level(__MODULE__, fmt" - %s", ##arg, clx_error_getString(rc));\
        return CLNX_STATUS_TO_SAI(rc);\
    }\
}while (0)
#define CHECK_RC_ERR_RETURN(fmt, arg ...)  CHECK_RC_FAIL_RETURN(rc, (rc), ERR, fmt, ##arg)
#define CHECK_RC_ERR_CLEAR_RETURN(unlock, fmt, arg ...)  CHECK_RC_FAIL_RETURN(rc, unlock, ERR, fmt, ##arg)

#define SAI_FWD_ACTION_TO_CLNX(__action__)     ext_sai_action_to_clx_map[__action__]
#define CLNX_FWD_ACTION_TO_SAI(__action__)     ext_clx_action_to_sai_map[__action__]

typedef enum
{
    CLX_CFG_TYPE_EXTEND_DIAG_LOG_SEVERITY = CLX_CFG_TYPE_LAST + 1,
    CLX_CFG_TYPE_PORT_BREAKOUT_LANE_NUM_MAX,

    CLX_CFG_TYPE_EXTEND_LAST
}CLX_CFG_TYPE_EXTEND_T;

sai_status_t
clnx_check_attribs_metadata(
    _In_ uint32_t                            attr_count,
    _In_ const sai_attribute_t               *attr_list,
    _In_ const sai_attribute_entry_t         *functionality_attr,
    _In_ const sai_vendor_attribute_entry_t  *functionality_vendor_attr,
    _In_ sai_operation_t                     oper);

sai_status_t
clnx_find_attrib_in_list(
    _In_ uint32_t                       attr_count,
    _In_ const sai_attribute_t          *attr_list,
    _In_ sai_attr_id_t                  attrib_id,
    _Out_ const sai_attribute_value_t   **attr_value,
    _Out_ uint32_t                      *index);

sai_status_t
clnx_sai_set_attribute(
    _In_ const sai_object_key_t              *key,
    _In_ const char                          *key_str,
    _In_ const sai_attribute_entry_t         *functionality_attr,
    _In_ const sai_vendor_attribute_entry_t  *functionality_vendor_attr,
    _In_ const sai_attribute_t               *attr);

sai_status_t
clnx_sai_get_attributes(
    _In_ const sai_object_key_t              *key,
    _In_ const char                          *key_str,
    _In_ const sai_attribute_entry_t         *functionality_attr,
    _In_ const sai_vendor_attribute_entry_t  *functionality_vendor_attr,
    _In_ uint32_t                            attr_count,
    _Inout_ sai_attribute_t                  *attr_list);

sai_status_t
clnx_sai_value_to_str(
    _In_ sai_attribute_value_t      value,
    _In_ sai_attribute_value_type_t type,
    _In_ uint32_t                   max_length,
    _Out_ char                      *value_str);

sai_status_t
clnx_sai_attr_list_to_str(
    _In_ uint32_t                     attr_count,
    _In_ const sai_attribute_t        *attr_list,
    _In_ const sai_attribute_entry_t  *functionality_attr,
    _In_ uint32_t                     max_length,
    _Out_ char                        *list_str);

sai_status_t 
clnx_sai_attr_value_to_str(
    _In_ const sai_attr_id_t            id,
    _In_ const sai_attribute_value_t    *ptr_value,
    _In_ const sai_attribute_entry_t    *pfunctionality_attr,
    _In_ uint32_t                       max_length,
    _Out_ char                          *ptr_list_str);

void
clnx_sai_mac_to_str(
    _In_ sai_mac_t mac,
    _In_ uint32_t max_length,
    _Out_ char *key_str,
    _Out_ uint32_t *key_len);

sai_status_t
clnx_sai_ipprefix_to_str(
    _In_ sai_ip_prefix_t value,
    _In_ uint32_t max_length,
    _Out_ char *value_str);

sai_status_t
clnx_sai_ipaddr_to_str(
    _In_ sai_ip_address_t value,
    _In_ uint32_t         max_length,
    _Out_ char            *value_str,
    _Out_ int             *chars_written);

sai_status_t
clnx_sai_nexthops_to_str(
    _In_ uint32_t               next_hop_count,
    _In_ const sai_object_id_t  *nexthops,
    _In_ uint32_t               max_length,
    _Out_ char                  *str);

sai_status_t
clnx_object_to_data(
    sai_object_id_t    object_id,
    sai_object_type_t  type,
    uint32_t           *ptr_data);

sai_status_t
clnx_object_to_data_ext(
    sai_object_id_t    object_id,
    sai_object_type_t  type,
    uint32_t           *ptr_data,
    uint8_t            *ptr_extended_data);

sai_status_t
clnx_create_object(
    sai_object_type_t type,
    uint32_t          data,
    sai_object_id_t   *ptr_object_id);

sai_status_t
clnx_create_object_ext(
    sai_object_type_t type,
    uint32_t          data,
    uint8_t           *ptr_extended_data,
    sai_object_id_t   *ptr_object_id);

sai_status_t
clnx_object_to_port(
    sai_object_id_t    object_id,
    CLX_PORT_T         *ptr_port,
    sai_object_type_t  *ptr_type);

sai_status_t
clnx_port_to_object(
    CLX_PORT_T         port,
    sai_object_type_t  type,
    sai_object_id_t    *ptr_object_id);

sai_status_t
clnx_object_to_port_bmp(
    _In_ const uint32_t             unit,
    _In_ const sai_object_id_t      oid,
    _Out_ CLX_PORT_BITMAP_T         bmp);

sai_status_t
clnx_fill_objlist(
    sai_object_id_t *data,
    uint32_t count,
    sai_object_list_t *list);

sai_status_t
clnx_fill_u32list(
    uint32_t *data,
    uint32_t count,
    sai_u32_list_t *list);

sai_status_t
clnx_fill_s32list(
    int32_t *data,
    uint32_t count,
    sai_s32_list_t *list);

sai_status_t
clnx_fill_vlanlist(
    sai_vlan_id_t *data,
    uint32_t count,
    sai_vlan_list_t *list);

sai_status_t
clnx_fill_AttrObjlist(
    _In_ sai_object_list_t   *ptr_list_src,
    _Inout_ sai_object_list_t   *ptr_attr_list);

sai_status_t
clnx_refill_Objlist(
    _In_ const sai_object_list_t   *ptr_list_src,
    _Inout_ sai_object_list_t   *ptr_list_dst);

#define CLNX_ACCEPT_TYPE_TO_DROPFLAGS(accept_type, drop_untag, drop_tag) \
{\
    (void) drop_untag;\
    (void) drop_tag;\
    drop_untag = (accept_type == CLX_PORT_ACCEPTABLE_TYPE_TAGGED)||(accept_type == CLX_PORT_ACCEPTABLE_TYPE_NONE);\
    drop_tag = (accept_type == CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED)||(accept_type == CLX_PORT_ACCEPTABLE_TYPE_NONE);\
}

#define CLNX_DROPFLAGS_TO_ACCEPT_TYPE(drop_untag, drop_tag, accept_type) \
    (drop_untag)?((accept_type) = (drop_tag) ? CLX_PORT_ACCEPTABLE_TYPE_NONE: CLX_PORT_ACCEPTABLE_TYPE_TAGGED):\
        ((accept_type) = (drop_tag) ? CLX_PORT_ACCEPTABLE_TYPE_UNTAGGED: CLX_PORT_ACCEPTABLE_TYPE_ALL)
#define SAI_KEY_INIT_LED_FILE                     "SAI_INIT_LED_CONFIG_FILE"

void
clx_pbm_to_str(
    CLX_PORT_BITMAP_T pbm,
    char* str);

sai_status_t
clnx_sai_ip_address_to_sdk(
    _In_ const sai_ip_address_t *sai_addr,
    _Out_ CLX_IP_ADDR_T *sdk_addr);

sai_status_t
clnx_sdk_ip_address_to_sai(
    _In_ const CLX_IP_ADDR_T *sdk_addr,
    _Out_ sai_ip_address_t *sai_addr);

sai_status_t
clnx_sai_ip_prefix_to_sdk(
    _In_ const sai_ip_prefix_t      *sai_prefix,
    _Out_ CLX_L3_IP_NETWORK_ADDR_T *sdk_prefix);

sai_status_t
clnx_sdk_ip_prefix_to_sai(
    _In_ const CLX_L3_IP_NETWORK_ADDR_T *sdk_prefix,
    _Out_ sai_ip_prefix_t               *sai_prefix);

CLX_ERROR_NO_T
clnx_utils_setModuleLogLevel(
    const sai_api_t             module,
    const uint32_t              type,
    const sai_log_level_t       severity);

CLX_ERROR_NO_T
clnx_utils_setModuleDebugEnable(
    const sai_api_t             module,
    const BOOL_T                enabled);

void
clnx_utils_print(
    const sai_api_t             module,
    const sai_log_level_t       severity,
    const C8_T                  *ptr_fmt,
    ...)
__attribute__ ((__format__ (__printf__, 3, 4)));


void
clnx_diag_printToCmdOutBuf(
    const void      *ptr_buf,
    UI32_T          len);

void
clnx_switch_printf(
    const void      *ptr_buf,
    UI32_T          len);

sai_status_t
clnx_check_bulk_attrs_validate(
    _In_ uint32_t                 object_count,
    _In_ const uint32_t          *attr_count,
    _In_ const sai_attribute_t  **attr_list_for_create, sai_attribute_t **attr_list_for_get,
    _In_ const sai_attribute_t   *attr_list_for_set,
    _In_ sai_bulk_op_error_mode_t mode,
    _In_ sai_status_t            *object_statuses,
    _In_ sai_common_api_t         api,
    _Out_ bool                   *stop_on_error);

sai_status_t
clnx_bulk_statuses_log(
    _In_ const char         *object_type_str,
    _In_ const sai_status_t *object_statuses,
    _In_ uint32_t            object_count,
    _In_ sai_common_api_t    api);

I32_T sai_ip_address_cmp(void *s, void *d);

bool
clnx_sai_dataAllZero(
    const char *ptr_data,
    const uint32_t data_size);

sai_status_t
clnx_sai_saveArrayWithIdx(
    const uint32_t  length,
    const uint32_t  count,
    const void  *ptr_array,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clnx_sai_restoreArrayWithIdx(
    const uint32_t       length,
    const uint32_t       count,
    void    *ptr_array,
    const HAL_IO_OBJ_META_T *ptr_obj_meta);

sai_status_t
clnx_sai_restoreList(
    const UI32_T             length,
    const CMLIB_LIST_T       *ptr_list,
    const HAL_IO_OBJ_META_T  *ptr_obj_meta);

sai_status_t
clnx_sai_saveList(
    const UI32_T       length,
    const CMLIB_LIST_T *ptr_list,
    HAL_IO_OBJ_META_T  *ptr_obj_meta);

sai_status_t
clnx_sai_saveAvlTree(
    const uint32_t           length,
    const CMLIB_AVL_HEAD_T *ptr_avl,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clnx_sai_saveGeneralData(
    const uint32_t  length,
    const char  *ptr_data,
    HAL_IO_OBJ_META_T   *ptr_obj_meta);

sai_status_t
clnx_sai_nonvolatile_to_wbdb(
    _In_ uint32_t   *module_length,
    _In_ void   **module_data,
    _In_ uint32_t   module_ver,
    _Out_ HAL_IO_WB_DB_T  **pptr_db);

sai_status_t
clnx_sai_wbdb_to_nonvolatile(
    _In_ HAL_IO_WB_DB_T  *ptr_db,
    _In_ uint32_t   module_ver,
    _Out_ uint32_t  *module_length,
    _Out_ void  **module_data);

sai_status_t
clnx_sai_getWbObj(
    const HAL_IO_WB_DB_T *ptr_db,
    UI32_T               obj_id,
    HAL_IO_OBJ_META_T    *ptr_obj);

void
clnx_sai_destoryWbObjList(
    uint32_t    wbdb_obj_list_cnt,
    HAL_IO_OBJ_META_T   *wbdb_obj_list);

sai_status_t
clnx_switch_initModule(
    _In_ uint32_t       unit);

sai_status_t
clnx_policer_getMeterCfg(
    _In_ const sai_object_id_t      policer_id,
    _Out_ uint32_t      *ptr_meter_id,
    _Out_ CLX_METER_CFG_T   *ptr_meter_cfg);

sai_status_t clnx_port_wred_apply(
    _In_ sai_object_id_t obj_id,
    _In_ sai_object_id_t wred_id);

sai_status_t clnx_port_pool_getWredProfileID(
        uint32_t unit,uint32_t port, 
        _Out_ sai_object_id_t* wredId);

void clnx_sai_printACLEntryClassify(
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    char *buf, UI32_T buf_size);

void clnx_sai_printACLEntryAction(
    const UI32_T              unit,
    const CLX_ACL_ACTION_T    *ptr_action,
    char *buf, UI32_T buf_size);

#define CLNX_ATTRIBS_LOG(_module,_clnx_range_attr_arr,_dbg_level) \
{\
    char _list_str[MAX_LIST_VALUE_STR_LEN] = {0};\
    clnx_sai_attr_list_to_str(attr_count, attr_list, _clnx_range_attr_arr, MAX_LIST_VALUE_STR_LEN, _list_str);\
    CLNX_LOG_PRINT(_module, _dbg_level,"%s", _list_str);\
}

#define CLNX_ATTR_VALUE_LOG(module, _id, _attr_value, _clnx_range_attr_arr, _dbg_level) \
{\
    char _value_str[MAX_VALUE_STR_LEN] = {0};\
    clnx_sai_attr_value_to_str(_id, _attr_value, _clnx_range_attr_arr, MAX_VALUE_STR_LEN, _value_str);\
    CLNX_LOG_PRINT(module, _dbg_level, "%s", _value_str);\
}

#define CHECK_RET_FAIL_LOG(ret, level, fmt, arg ...)  do {\
    if ((ret)!= SAI_STATUS_SUCCESS) \
    {\
        CLNX_LOG_##level(__MODULE__, fmt" "#ret"=%d", ##arg, (ret));\
    }\
}while (0)

#define CHECK_RET_ERR_LOG(fmt, arg ...)  CHECK_RET_FAIL_LOG(ret, ERR, fmt, ##arg)

#define CLNX_COUNTER_ID_LOG(module, _num_of_cnt, _cnt_ids, _dbg_level)\
{\
    uint32_t _cnt_id_idx = 0;\
    for (_cnt_id_idx=0;_cnt_id_idx<_num_of_cnt;_cnt_id_idx++)\
    {\
        CLNX_LOG_PRINT(module, _dbg_level, "counter id[%u]=%u",_cnt_id_idx,_cnt_ids[_cnt_id_idx]);\
    }\
}

#define CLNX_COUNTER_ID_AND_VALUE_LOG(module, _num_of_cnt, _cnt_ids, _cnt_value, _dbg_level)\
{\
    uint32_t _cnt_idx = 0;\
    for (_cnt_idx=0;_cnt_idx<_num_of_cnt;_cnt_idx++)\
    {\
        CLNX_LOG_PRINT(module, _dbg_level, "counter id[%u]=%d,value=%#" PRIx64 ,_cnt_idx,_cnt_ids[_cnt_idx],_cnt_value[_cnt_idx]);\
    }\
}
#if 0

void utils_log(const sai_log_level_t severity, const char *module_name, const char *p_str, ...);


#define QUOTEME_(x) #x                        /* add "" to x */
#define QUOTEME(x)  QUOTEME_(x)

#define CLNX_ASSERT(exp) assert((exp))

#ifndef _WIN32

#define UNREFERENCED_PARAMETER(X)
#define UTILS_LOG(level, fmt, arg ...)                                \
    do {                                            \
        utils_log(level, QUOTEME(__MODULE__), "%s[%d]- %s: " fmt,            \
                  __FILE__, __LINE__, __FUNCTION__, ## arg);            \
    } while (0)

typedef enum _sai_log_t {
    SAI_LOG_DEBUG,
    SAI_LOG_INFO,
    SAI_LOG_WARN,
    SAI_LOG_ERROR,
    SAI_LOG_NOTICE,
    SAI_LOG_LAST
} sai_log_t;

#define CLNX_LOG_DBG(fmt, arg ...) UTILS_LOG(SAI_LOG_DEBUG, fmt, ## arg)
#define CLNX_LOG_INF(fmt, arg ...) UTILS_LOG(SAI_LOG_INFO, fmt, ## arg)
#define CLNX_LOG_WRN(fmt, arg ...) UTILS_LOG(SAI_LOG_WARN, fmt, ## arg)
#define CLNX_LOG_ERR(fmt, arg ...) UTILS_LOG(SAI_LOG_ERROR, fmt, ## arg)
#define CLNX_LOG_NTC(fmt, arg ...) UTILS_LOG(SAI_LOG_NOTICE, fmt, ## arg)

#else /* WIN32 */

#define PRId64 "lld"
#include <windows.h>
#define UTILS_LOG(level, fmt, ...)                                \
    do {                                            \
        utils_log(level, QUOTEME(__MODULE__), "%s[%d]- %s: " fmt,            \
                  __FILE__, __LINE__, __FUNCTION__, __VA_ARGS__);            \
    } while (0)

#define CLNX_LOG_ENTER()       UTILS_LOG(SAI_LOG_DEBUG, "%s: [\n", __FUNCTION__)
#define CLNX_LOG_EXIT()        UTILS_LOG(SAI_LOG_DEBUG, "%s: ]\n", __FUNCTION__)
#define CLNX_LOG_DBG(fmt, ...) UTILS_LOG(SAI_LOG_DEBUG, fmt, __VA_ARGS__)
#define CLNX_LOG_INF(fmt, ...) UTILS_LOG(SAI_LOG_INFO, fmt, __VA_ARGS__)
#define CLNX_LOG_WRN(fmt, ...) UTILS_LOG(SAI_LOG_WARN, fmt, __VA_ARGS__)
#define CLNX_LOG_ERR(fmt, ...) UTILS_LOG(SAI_LOG_ERROR, fmt, __VA_ARGS__)
#define CLNX_LOG_NTC(fmt, ...) UTILS_LOG(SAI_LOG_NOTICE, fmt, __VA_ARGS__)

#endif
#endif

#endif /* __CLNX_SAI_H_ */
