#define CLNX_SAI_COMMIT_ID "75e15da806023f6eb9e18477e40c42f48b2e58f5"
#define CLNX_SAI_GIT_BRANCH "v1.7_ks-dirty"
#define CLNX_SAI_BUILD_TIME "Mon Jun 13 10:01:26 UTC 2022"
#define CLNX_SDK_COMMIT_ID "b90376a236754027d0fddd2e50ed7a21b029e8da(clx_system_1.1.2_RC3)"
#define CLNX_SAI_BUILD_BY "yangjie-bj@1dc6d4017a31"
#define SAI_VERSION_CODE 67329
#define CLNX_SAI_HEAD_VERSION "1.7.1"
#define SAI_VER(a,b,c) (((a)<<16)+((b)<<8)+(c))
