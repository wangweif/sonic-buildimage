/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   ifmap_clx_tm.h
 * PURPOSE:
 *      It provides user port to CLX port translation API.
 * NOTES:
 */

#ifndef IFMAP_CLX_TM_H
#define IFMAP_CLX_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
ifmap_clx_tm_createHandler(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_TM_HANDLER_TYPE_T     handler_type,
    const UI32_T                    queue_id,
    CLX_TM_HANDLER_T                *ptr_handler);

CLX_ERROR_NO_T
ifmap_clx_tm_deleteHandler(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_TM_HANDLER_T          handler);

CLX_ERROR_NO_T
ifmap_clx_tm_setScheduleTopology(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_SCH_TOPOLOGY_ENTRY_T   *ptr_topology_entry,
    const UI32_T                        entry_count);

CLX_ERROR_NO_T
ifmap_clx_tm_getScheduleTopology(
    const UI32_T                        unit,
    const UI32_T                        port,
    CLX_TM_SCH_TOPOLOGY_ENTRY_T         *ptr_topology_entry,
    UI32_T                              entry_count,
    UI32_T                              *ptr_actual_entry_count);

CLX_ERROR_NO_T
ifmap_clx_tm_setBandwidth(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_BANDWIDTH_T    *ptr_bandwidth);

CLX_ERROR_NO_T
ifmap_clx_tm_getBandwidth(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    CLX_TM_BANDWIDTH_T          *ptr_bandwidth);

CLX_ERROR_NO_T
ifmap_clx_tm_setScheduleMode(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_SCH_MODE_T     mode,
    const UI32_T                weight);

CLX_ERROR_NO_T
ifmap_clx_tm_getScheduleMode(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    CLX_TM_SCH_MODE_T           *ptr_mode,
    UI32_T                      *ptr_weight);

CLX_ERROR_NO_T
ifmap_clx_tm_setTcQueueMapping(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    tc,
    const CLX_TM_HANDLER_TYPE_T     type,
    const CLX_TM_HANDLER_T          handler);

CLX_ERROR_NO_T
ifmap_clx_tm_getTcQueueMapping(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    tc,
    const CLX_TM_HANDLER_TYPE_T     type,
    CLX_TM_HANDLER_T                *ptr_handler);


CLX_ERROR_NO_T
ifmap_clx_tm_setProperty(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_PROPERTY_T             property,
    const UI32_T                        param0,
    const UI32_T                        param1);

CLX_ERROR_NO_T
ifmap_clx_tm_getProperty(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_PROPERTY_T             property,
    UI32_T                              *ptr_param0,
    UI32_T                              *ptr_param1);

CLX_ERROR_NO_T
ifmap_clx_tm_setCngCtrl(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_CNG_T                  mode);

CLX_ERROR_NO_T
ifmap_clx_tm_getCngCtrl(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_CNG_T                        *ptr_mode);

CLX_ERROR_NO_T
ifmap_clx_tm_setWredQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_WRED_QUEUE_CFG_T       *ptr_entry);

CLX_ERROR_NO_T
ifmap_clx_tm_getWredQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_WRED_QUEUE_CFG_T             *ptr_entry);

CLX_ERROR_NO_T
ifmap_clx_tm_setDctcpQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        profile_id);

CLX_ERROR_NO_T
ifmap_clx_tm_getDctcpQueueConfig(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_profile_id);

CLX_ERROR_NO_T
ifmap_clx_tm_setPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

CLX_ERROR_NO_T
ifmap_clx_tm_getPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

CLX_ERROR_NO_T
ifmap_clx_tm_setPcpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

CLX_ERROR_NO_T
ifmap_clx_tm_getPcpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

CLX_ERROR_NO_T
ifmap_clx_tm_setDscpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        dscp_count,
    UI32_T                              *ptr_dscp_list);

CLX_ERROR_NO_T
ifmap_clx_tm_getDscpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_dscp_count,
    UI32_T                              *ptr_dscp_list);

CLX_ERROR_NO_T
ifmap_clx_tm_setQueuePfcPriMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        bitmap);

CLX_ERROR_NO_T
ifmap_clx_tm_getQueuePfcPriMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_bitmap);

CLX_ERROR_NO_T
ifmap_clx_tm_setPfcPriQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    const CLX_TM_HANDLER_T              handler);

CLX_ERROR_NO_T
ifmap_clx_tm_getPfcPriQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    UI32_T                              *ptr_handler);

CLX_ERROR_NO_T
ifmap_clx_tm_setBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

CLX_ERROR_NO_T
ifmap_clx_tm_getBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_THRESHOLD_T              *ptr_entry);

CLX_ERROR_NO_T
ifmap_clx_tm_getBufOccupancy(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_OCCUPANCY_T              *ptr_entry);

CLX_ERROR_NO_T
ifmap_clx_tm_getBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry);

CLX_ERROR_NO_T
ifmap_clx_tm_clearBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type);

CLX_ERROR_NO_T
ifmap_clx_tm_getBufWatermarkList(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T     type,
    const UI32_T                list_cnt,
    CLX_TM_BUF_WATERMARK_T      *ptr_entry_list);

CLX_ERROR_NO_T
ifmap_clx_tm_clearBufWatermarkList(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T     type,
    const UI32_T                list_cnt);

CLX_ERROR_NO_T
ifmap_clx_tm_registerBufSnapshotCallback(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
ifmap_clx_tm_deregisterBufSnapshotCallback(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
ifmap_clx_tm_getPauseStatus(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_status);


#endif /* End of #ifndef IFMAP_CLX_TM_H */

