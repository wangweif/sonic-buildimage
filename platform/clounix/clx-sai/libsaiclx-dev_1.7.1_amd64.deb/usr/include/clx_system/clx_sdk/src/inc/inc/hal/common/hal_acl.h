/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_acl.h
 * PURPOSE:
 *    Provide HAL driver API functions of ACL module.
 *
 * NOTES:
 *
 */

#ifndef HAL_ACL_H
#define HAL_ACL_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_acl.h>
#include <hal/common/hal_l3.h>
#include <hal/common/hal_cmn.h>
#include <hal/common/hal.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_ACL_UDF_KEY_BITS                (208)
#define HAL_ACL_UCP_ENTRY_NUM               (1024)

#define HAL_ACL_PER_UCP_CFG_NUM             (320)
#define HAL_ACL_UCP_CFG_FRM_TYP_NUM         (5)
#define HAL_ACL_PER_UCP_FRM_TYPE_CFG_NUM    (HAL_ACL_PER_UCP_CFG_NUM / HAL_ACL_UCP_CFG_FRM_TYP_NUM)

#define HAL_ACL_KEY_1X_WORDS                (CDB_ICIA_KEY_TCAM_1X_U_L2_WORDS)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_ACL_UCP_CFG_ENTRY_IDX(__ucp_id__, __frm_typ__)                                                  \
    (((__ucp_id__) * HAL_ACL_PER_UCP_CFG_NUM) + ((__frm_typ__) * HAL_ACL_PER_UCP_FRM_TYPE_CFG_NUM))

#define HAL_ACL_GET_ENTRY_TBL_ID(__tbl_id__, __type__, __norm_width__) do                                   \
{                                                                                                           \
    if (CLX_ACL_GROUP_INGRESS == (__type__))                                                                \
    {                                                                                                       \
        switch ((__norm_width__))                                                                           \
        {                                                                                                   \
            case (1):                                                                                       \
                (__tbl_id__) = TBL_ICIA_COM_TCAM_1X_ID;                                                     \
                break;                                                                                      \
            case (2):                                                                                       \
                (__tbl_id__) = TBL_ICIA_COM_TCAM_2X_ID;                                                     \
                break;                                                                                      \
            default :   /* 4 */                                                                             \
                (__tbl_id__) = TBL_ICIA_COM_TCAM_4X_ID;                                                     \
                break;                                                                                      \
        }                                                                                                   \
    }                                                                                                       \
    else /* CLX_ACL_GROUP_EGRESS == (__type__) */                                                           \
    {                                                                                                       \
        switch ((__norm_width__))                                                                           \
        {                                                                                                   \
            case (1):                                                                                       \
                (__tbl_id__) = TBL_ECIA_COM_TCAM_1X_ID;                                                     \
                break;                                                                                      \
            case (2):                                                                                       \
                (__tbl_id__) = TBL_ECIA_COM_TCAM_2X_ID;                                                     \
                break;                                                                                      \
            default :   /* 4 */                                                                             \
                (__tbl_id__) = TBL_ECIA_COM_TCAM_4X_ID;                                                     \
                break;                                                                                      \
        }                                                                                                   \
    }                                                                                                       \
} while (0)

#define HAL_ACL_PLANE_BMP_FOREACH(__unit__, __plane_idx__)                                                  \
    for ((__plane_idx__) = 0; (__plane_idx__) < HAL_PLANE_NUM; (__plane_idx__)++)                           \
        if(CMLIB_BITMAP_BIT_CHK((HAL_PLANE_BMP((__unit__))), (__plane_idx__)))

#define HAL_ACL_COPY_TBL(__rc__, __unit__, __tbl_id__, __src_entry__, __dst_entry__, __dir__, __num__)  do  \
{                                                                                                           \
    UI32_T    __plane_idx__;                                                                                \
    HAL_ACL_PLANE_BMP_FOREACH((__unit__), (__plane_idx__))                                                  \
    {                                                                                                       \
        (__rc__) = hal_cmn_dmaCopyTcam((__unit__), (__plane_idx__), 0, (__tbl_id__),                        \
                          (__src_entry__), (__dst_entry__), (__dir__), (__num__));                          \
        if (CLX_E_OK != (__rc__))                                                                           \
        {                                                                                                   \
            break;                                                                                          \
        }                                                                                                   \
    }                                                                                                       \
} while (0)


/* DATA TYPE DECLARATIONS
 */

typedef enum
{
    HAL_ACL_WBDB_GROUP_CB_IGR_GROUP_INFO_ARR = 0,
    HAL_ACL_WBDB_GROUP_CB_EGR_GROUP_INFO_ARR,
    HAL_ACL_WBDB_GROUP_CB_GROUP_BMP,
    HAL_ACL_WBDB_UDF_CB_IGR_UDF_INFO_ARR,
    HAL_ACL_WBDB_UDF_CB_EGR_UDF_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_IGR_ENTRY_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_EGR_ENTRY_INFO_ARR,
    HAL_ACL_WBDB_ENTRY_CB_IGR_ENTRY_BMP,
    HAL_ACL_WBDB_ENTRY_CB_EGR_ENTRY_BMP,
    HAL_ACL_WBDB_ENTRY_CB_ENTRY_INTERNAL_ID,
    HAL_ACL_WBDB_ENTRY_CB_IGR_ENC_TCP_FLG_REF,
    HAL_ACL_WBDB_ENTRY_CB_EGR_ENC_TCP_FLG_REF,
    HAL_ACL_WBDB_FLOW_CB_ENTRY_INFO,
    HAL_ACL_WBDB_REWR_CB_REWR_PAGE,
    HAL_ACL_WBDB_ADJ_ECMP_AVL,
    HAL_ACL_WBDB_EGR_UCP_EN_BMP,
    HAL_ACL_WBDB_LAST
} HAL_ACL_WBDB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_acl_init
 * PURPOSE:
 *      Init ACL module.
 * INPUT:
 *      unit            -- Device unit number
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK        -- init success.
 *      CLX_E_NO_MEMORY -- allocate control block failed.
 *      CLX_E_OTHERS    -- Init fail.
 *      CLX_E_BAD_PARAMETER -- parameter invalid
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_acl_init(
    const UI32_T    unit);

/* FUNCTION NAME: hal_acl_deinit
 * PURPOSE:
 *      Deinit ACL module.
 * INPUT:
 *      unit            -- Device unit number.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK        -- deinit success.
 *      CLX_E_OTHERS    -- deInit fail.
 *      CLX_E_BAD_PARAMETER -- parameter invalid
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_acl_deinit(
    const UI32_T    unit);

/* FUNCTION NAME: hal_acl_addGroup
 * PURPOSE:
 *      The API is used to add a UCP group.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      priority            -- UCP group priority
 *      ptr_group_profile   -- UCP group profile
 * OUTPUT:
 *      ptr_group_id        -- UCP group id
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_addGroup(
    const UI32_T                     unit,
    const CLX_ACL_GROUP_T            type,
    const UI32_T                     priority,
    const CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile,
    UI32_T                           *ptr_group_id);

/* FUNCTION NAME: hal_acl_delGroup
 * PURPOSE:
 *      The API is used to delete a UCP group.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- The UCP group id to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_delGroup(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id);

/* FUNCTION NAME: hal_acl_getGroup
 * PURPOSE:
 *      The API is used to get the configuration information of UCP group.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- The UCP group id to be deleted
 * OUTPUT:
 *      ptr_priority        -- UCP group priority to be returned
 *      ptr_group_profile   -- UCP group profile to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_getGroup(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const UI32_T               group_id,
    UI32_T                     *ptr_priority,
    CLX_ACL_GROUP_PROFILE_T    *ptr_group_profile);

/* FUNCTION NAME:   hal_acl_addUdfKeyProfile
 * PURPOSE:
 *      The API is used to add a udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      udf_key_profile_id  -- The udf key profile id to be added
 *      ptr_pkt_format      -- The packet format
 *      ptr_profile         -- The programming key format
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_addUdfKeyProfile(
    const UI32_T                       unit,
    const CLX_ACL_GROUP_T              type,
    const UI32_T                       udf_key_profile_id,
    const CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    const CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

/* FUNCTION NAME:   hal_acl_delUdfKeyProfile
 * PURPOSE:
 *      The API is used to delete a udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      udf_key_profile_id  -- udf key profile id to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_delUdfKeyProfile(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             udf_key_profile_id);

/* FUNCTION NAME:   hal_acl_getUdfKeyProfile
 * PURPOSE:
 *      The API is used to get the configuration information of udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      udf_key_profile_id  -- The udf key profile id to be get
 * OUTPUT:
 *      ptr_pkt_format      -- The packet format information to be returned
 *      ptr_profile         -- The programming key format information to be returned
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_getUdfKeyProfile(
    const UI32_T                 unit,
    const CLX_ACL_GROUP_T        type,
    const UI32_T                 udf_key_profile_id,
    CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

/* FUNCTION NAME: hal_acl_addLou
 * PURPOSE:
 *      The API is used to add/set the LOU configuration information.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      lou_id              -- The LOU id to be added/set
 *      ptr_lou             -- The LOU configuration information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_addLou(
    const UI32_T               unit,
    const CLX_ACL_GROUP_T      type,
    const UI32_T               id,
    const UI32_T               lou_id,
    const CLX_ACL_LOU_CFG_T    *ptr_lou);

/* FUNCTION NAME: hal_acl_delLou
 * PURPOSE:
 *      The API is used to delete the LOU configuration information.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      lou_id              -- The LOU id to be deleted
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_delLou(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             id,
    const UI32_T             lou_id);

/* FUNCTION NAME: hal_acl_getLou
 * PURPOSE:
 *      The API is used to get the LOU configuration information.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      lou_id              -- The LOU id to be get
 * OUTPUT:
 *      ptr_lou             -- The LOU configuration information to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_getLou(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             id,
    const UI32_T             lou_id,
    CLX_ACL_LOU_CFG_T        *ptr_lou);

/* FUNCTION NAME: hal_acl_allocEntryId
 * PURPOSE:
 *      The API is used to allocate a logic id for UCP entry.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Allocate a entry id from UCP group
 *      entry_priority      -- entry priority
 * OUTPUT:
 *      ptr_entry_id        -- The entry id to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_allocEntryId(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_priority,
    UI32_T                   *ptr_entry_id);

/* FUNCTION NAME: hal_acl_freeEntryId
 * PURPOSE:
 *      The API is used to free the logic id for UCP entry.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_freeEntryId(
    const UI32_T    unit,
    const UI32_T    entry_id);

/* FUNCTION NAME: hal_acl_getEntryIdInfo
 * PURPOSE:
 *      The API is used to get logic id information for UCP entry.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- Entry id
 * OUTPUT:
 *      ptr_type            -- the UCP group type of the entry id to be returned
 *      ptr_group_id        -- the group id of the entry id to be returned
 *      ptr_entry_priority  -- the entry priority of the entry id to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_getEntryIdInfo(
    const UI32_T       unit,
    const UI32_T       entry_id,
    CLX_ACL_GROUP_T    *ptr_type,
    UI32_T             *ptr_group_id,
    UI32_T             *ptr_entry_priority);

/* FUNCTION NAME: hal_acl_addEntry
 * PURPOSE:
 *      The API is used to add/set an UCP entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id
 *      entry_valid         -- The status of the entry: TRUE for valid and FALSE for invalid
 *      ptr_classify        -- The classified information of the entry
 *      ptr_action          -- The action to be taken of the entry when the classified information is matched
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *      If both ptr_classify and ptr_action are NULL, the API will only modify valid bit of entry.
 */
CLX_ERROR_NO_T
hal_acl_addEntry(
    const UI32_T                unit,
    const UI32_T                entry_id,
    const BOOL_T                entry_valid,
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    const CLX_ACL_ACTION_T      *ptr_action);

/* FUNCTION NAME:   hal_acl_delEntry
 * PURPOSE:
 *      The API is used to delete an UCP entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id

 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 *      CLX_E_OTHERS        --  Other error.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_delEntry(
    const UI32_T    unit,
    const UI32_T    entry_id);

/* FUNCTION NAME: hal_acl_getEntry
 * PURPOSE:
 *      The API is used to get an UCP entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      entry_id            -- entry id
 * OUTPUT:
 *      entry_valid         -- The status of the entry to be returned
 *      ptr_classify        -- The classified information of the entry to be returned
 *      ptr_action          -- The action to be taken of the entry to be returned
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_acl_getEntry(
    const UI32_T          unit,
    const UI32_T          entry_id,
    BOOL_T                *ptr_entry_valid,
    CLX_ACL_CLASSIFY_T    *ptr_classify,
    CLX_ACL_ACTION_T      *ptr_action);

/* FUNCTION NAME: hal_acl_addFlowEntry
 * PURPOSE:
 *      The API is used to add an exact match entry to HW.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      ptr_classify        -- The classified information of the entry
 *      ptr_action          -- The action to be taken of the entry when the classified information is matched
 * OUTPUT:
 *      ptr_entry_id        -- The returned entry id from HW
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 */
CLX_ERROR_NO_T
hal_acl_addFlowEntry(
    const UI32_T                unit,
    const CLX_ACL_GROUP_T       type,
    const UI32_T                group_id,
    const CLX_ACL_CLASSIFY_T    *ptr_classify,
    const CLX_ACL_ACTION_T      *ptr_action,
    UI32_T                      *ptr_entry_id);

/* FUNCTION NAME: hal_acl_delFlowEntry
 * PURPOSE:
 *      The API is used to delete an exact match entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      entry_id            -- Entry id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 */
CLX_ERROR_NO_T
hal_acl_delFlowEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_id);

/* FUNCTION NAME: hal_acl_getFlowEntry
 * PURPOSE:
 *      The API is used to get an exact match entry from HW.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      entry_id            -- Entry id
 * OUTPUT:
 *      ptr_classify        -- The classified information of the entry
 *      ptr_action          -- The action to be taken of the entry
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 */
CLX_ERROR_NO_T
hal_acl_getFlowEntry(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_id,
    const UI32_T             entry_id,
    CLX_ACL_CLASSIFY_T       *ptr_classify,
    CLX_ACL_ACTION_T         *ptr_action);

/* FUNCTION NAME: hal_acl_traverseGroup
 * PURPOSE:
 *      The API is used to traverse UCP groups.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      callback            -- The callback function of type CLX_ACL_GROUP_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
hal_acl_traverseGroup(
    const UI32_T                           unit,
    const CLX_ACL_GROUP_T                  type,
    const CLX_ACL_GROUP_TRAVERSE_FUNC_T    callback,
    void                                   *ptr_cookie);

/* FUNCTION NAME: hal_acl_traverseEntry
 * PURPOSE:
 *      The API is used to traverse UCP entries.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      group_id            -- Group id
 *      callback            -- The callback function of type CLX_ACL_ENTRY_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
hal_acl_traverseEntry(
    const UI32_T                           unit,
    const CLX_ACL_GROUP_T                  type,
    const UI32_T                           group_id,
    const CLX_ACL_ENTRY_TRAVERSE_FUNC_T    callback,
    void                                   *ptr_cookie);

/* FUNCTION NAME: hal_acl_traverseUdfKeyProfile
 * PURPOSE:
 *      The API is used to traverse udf key profile.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      callback            -- The callback function of type CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
hal_acl_traverseUdfKeyProfile(
    const UI32_T                                     unit,
    const CLX_ACL_GROUP_T                            type,
    const CLX_ACL_UDF_KEY_PROFILE_TRAVERSE_FUNC_T    callback,
    void                                             *ptr_cookie);

/* FUNCTION NAME: hal_acl_traverseLou
 * PURPOSE:
 *      The API is used to traverse lou.
 * INPUT:
 *      unit                -- Device unit number
 *      type                -- UCP group type: Ingress/Egress
 *      id                  -- Udf key profile id.
 *      callback            -- The callback function of type CLX_ACL_LOU_TRAVERSE_FUNC_T
 *      ptr_cookie          -- The cookie data as input parameter of callback function
 * OUTPUT:
 *      ptr_cookie          -- The cookie data as output parameter of callback function
 * RETURN:
 *      CLX_E_OK            -- Operate success
 *      CLX_E_BAD_PARAMETER -- Bad parameter
 *      CLX_E_OTHERS        -- Other error
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
hal_acl_traverseLou(
    const UI32_T                         unit,
    const CLX_ACL_GROUP_T                type,
    const UI32_T                         id,
    const CLX_ACL_LOU_TRAVERSE_FUNC_T    callback,
    void                                 *ptr_cookie);

CLX_ERROR_NO_T
hal_acl_updateAdjInfo(
    const UI32_T               unit,
    const UI32_T               adj_id,
    const HAL_L3_ADJ_INFO_T    *ptr_adj_info);

CLX_ERROR_NO_T
hal_acl_updateEcmpInfo(
    const UI32_T                unit,
    const UI32_T                ecmp_group_id,
    const HAL_L3_ECMP_INFO_T    *ptr_ecmp_info);

CLX_ERROR_NO_T
hal_acl_getCapacity(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_size);

CLX_ERROR_NO_T
hal_acl_getUsage(
    const UI32_T            unit,
    const CLX_SWC_RSRC_T    type,
    const UI32_T            param,
    UI32_T                  *ptr_cnt);

CLX_ERROR_NO_T
hal_acl_setPortProperty(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_PROPERTY_T    property,
    const UI32_T                 param0,
    const UI32_T                 param1);

CLX_ERROR_NO_T
hal_acl_getPortProperty(
    const UI32_T                 unit,
    const UI32_T                 port,
    const CLX_PORT_PROPERTY_T    property,
    UI32_T                       *ptr_param0,
    UI32_T                       *ptr_param1);

CLX_ERROR_NO_T
hal_acl_setActiveGroup(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    const UI32_T             group_bmp);

CLX_ERROR_NO_T
hal_acl_getActiveGroup(
    const UI32_T             unit,
    const CLX_ACL_GROUP_T    type,
    UI32_T                   *ptr_group_bmp);

CLX_ERROR_NO_T
hal_acl_getEntryPbrIdx(
    const UI32_T    unit,
    const UI32_T    is_flow,
    const UI32_T    entry_id,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_pbr_idx);

CLX_ERROR_NO_T
hal_acl_addUdfKeyProfileWValid(
    const UI32_T                       unit,
    const CLX_ACL_GROUP_T              type,
    const UI32_T                       udf_key_profile_id,
    const BOOL_T                       valid,
    const CLX_ACL_PKT_FORMAT_T         *ptr_pkt_format,
    const CLX_ACL_UDF_KEY_PROFILE_T    *ptr_profile);

#endif /* End of HAL_ACL_H */

