/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   hal_lightning_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_LIGHTNING_TM_H
#define HAL_LIGHTNING_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>


/* NAMING CONSTANT DECLARATIONS
 */

/*#define HAL_LIGHTNING_TM_DEBUG_PRINTF_EABLED*/
/*high 4 bit(bit[31:28]) means object type*/
#define HAL_LIGHTNING_TM_HANDLER_TYPE_SHIFT (28)

/*bit[31:28] object type encoding*/
#define HAL_LIGHTNING_TM_HANDLER_LEGACY_QUEUE_TYPE         (0)
#define HAL_LIGHTNING_TM_HANDLER_UNICAST_QUEUE_TYPE        (1)
#define HAL_LIGHTNING_TM_HANDLER_MULTICAST_QUEUE_TYPE      (2)
#define HAL_LIGHTNING_TM_HANDLER_SCHEDULE_NODE_TYPE        (3)

/* queue num*/
#define HAL_LIGHTNING_TM_CPU_QUEUE_NUM        (48)
#define HAL_LIGHTNING_TM_UNICAST_QUEUE_NUM    (8)
#define HAL_LIGHTNING_TM_MULTICAST_QUEUE_NUM  (8)
#define HAL_LIGHTNING_TM_LEGACY_QUEUE_NUM     (8)
#define HAL_LIGHTNING_TM_CPI_QUEUE_NUM        (8)


/*DEQ ranker queue status query time(unit is us)*/
#define HAL_LIGHTNING_TM_DEQ_RANKER_QUERY_TIME (50)

/*DEQ ranker queue status query loops is limited to be 160*/
#define HAL_LIGHTNING_TM_DEQ_RANKER_QUERY_MAX_LOOP (160)


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_LIGHTNING_TM_HANDLER_SET(handler, type, id)                        \
        ((handler) = ((type) << HAL_LIGHTNING_TM_HANDLER_TYPE_SHIFT) + (id))

#define HAL_LIGHTNING_TM_HANDLER_GET(handler, type, id) do {                   \
        (type) = ((handler) >> HAL_LIGHTNING_TM_HANDLER_TYPE_SHIFT);           \
        (id) = ((handler) & ((1U << HAL_LIGHTNING_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while(0)

/* handler id valid check*/
#define HAL_LIGHTNING_TM_UNICAST_QUEUE_HANDLER_ID_VALID(id)   \
        (((id) >= 0) && ((id) < HAL_LIGHTNING_TM_UNICAST_QUEUE_NUM))

#define HAL_LIGHTNING_TM_MULTICAST_QUEUE_HANDLER_ID_VALID(id) \
        (((id) >= 0) && ((id) < HAL_LIGHTNING_TM_MULTICAST_QUEUE_NUM))

#define HAL_LIGHTNING_TM_CPU_QUEUE_HANDLER_ID_VALID(id)       \
        (((id) >= 0) && ((id) < HAL_LIGHTNING_TM_CPU_QUEUE_NUM))

#define HAL_LIGHTNING_TM_LEGACY_QUEUE_HANDLER_ID_VALID(id)    \
        (((id) >= 0) && ((id) < HAL_LIGHTNING_TM_LEGACY_QUEUE_NUM))

/*schedule node handler id valid check, root node is exculde*/
#define HAL_LIGHTNING_TM_SCHEDULE_NODE_HANDLER_ID_VALID(id)   \
        (((id) >= 0) && ((id) < HAL_LIGHTNING_TM_SCH_NODE_NUM - 1))

/*check macro*/
#define  HAL_LIGHTNING_TM_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__)   \
        (((__value__) > (__max__)) || ((__value__) < (__min__)))


/* DATA TYPE DECLARATIONS
 */
/* Port Speed */
/* Please check HW define for all speed setting when add other speed*/
typedef enum
{
    HAL_LIGHTNING_TM_PORT_SPEED_1G = 0,
    HAL_LIGHTNING_TM_PORT_SPEED_10G,
    HAL_LIGHTNING_TM_PORT_SPEED_25G,
    HAL_LIGHTNING_TM_PORT_SPEED_40G,
    HAL_LIGHTNING_TM_PORT_SPEED_50G,
    HAL_LIGHTNING_TM_PORT_SPEED_100G,
    HAL_LIGHTNING_TM_PORT_SPEED_200G,
    HAL_LIGHTNING_TM_PORT_SPEED_400G,
    HAL_LIGHTNING_TM_PORT_SPEED_NONE,
    HAL_LIGHTNING_TM_PORT_SPEED_LAST
} HAL_LIGHTNING_TM_PORT_SPEED_T;

/*structure of TM MAC MACRO*/
typedef struct HAL_LIGHTNING_TM_MAC_MACRO_S
{
    UI8_T   subdp_macro_id;     /*0~7*/
    UI32_T  gp;                 /*1:gaurantee port; 0: non-gautantee port*/
} HAL_LIGHTNING_TM_MAC_MACRO_T;

/*structure of TM PPID*/
typedef struct HAL_LIGHTNING_TM_PPID_S
{
    UI16_T  submp_macro_id;     /*0~7*/
    UI16_T  gp;                 /*1:gaurantee port; 0: non-gautantee port*/
} HAL_LIGHTNING_TM_PPID_T;

/*Type of CLX port translate*/
typedef enum
{
    HAL_LIGHTNING_TM_PORT_TRANS_TYPE_MP = 0,
    HAL_LIGHTNING_TM_PORT_TRANS_TYPE_PP,
    HAL_LIGHTNING_TM_PORT_TRANS_TYPE_LAST
} HAL_LIGHTNING_TM_PORT_TRANS_TYPE_T;

/*control block for misc module*/
typedef struct HAL_LIGHTNING_TM_MISC_CB_S
{
    CLX_SEMAPHORE_ID_T    misc_sema; /*semaphore for misc module*/
}HAL_LIGHTNING_TM_MISC_CB_T;

CLX_ERROR_NO_T
hal_lightning_tm_misc_lockResource (
    const UI32_T    unit );

CLX_ERROR_NO_T
hal_lightning_tm_misc_unlockResource (
    const UI32_T    unit );

CLX_ERROR_NO_T
hal_lightning_tm_init(
    const   UI32_T          unit);

CLX_ERROR_NO_T
hal_lightning_tm_deinit(
    const   UI32_T          unit);

CLX_ERROR_NO_T
hal_lightning_tm_misc_initCfg(
    const UI32_T unit);

void
hal_lightning_tm_logicalToPhysicalPlane(
    const UI32_T            unit,
    const UI32_T            logical_plane,
    UI32_T                  *ptr_phsical_plane);

CLX_ERROR_NO_T
hal_lightning_tm_setCutThrough(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              enable);

CLX_ERROR_NO_T
hal_lightning_tm_setProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_PROPERTY_T     property,
    const UI32_T                param0,
    const UI32_T                param1);

CLX_ERROR_NO_T
hal_lightning_tm_getProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_PROPERTY_T     property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);

CLX_ERROR_NO_T
hal_lightning_tm_setState(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_DIR_T           dir,
    const   UI32_T              all_queue,
    const   CLX_TM_HANDLER_T    handler,
    const   UI32_T              enable);

CLX_ERROR_NO_T
hal_lightning_tm_setTmiState(
    const UI32_T unit,
    const UI32_T port,
    const CLX_DIR_T dir,
    const UI32_T all_queue,
    const CLX_TM_HANDLER_T handler,
    const UI32_T enable);

CLX_ERROR_NO_T
hal_lightning_tm_getTmiState(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_DIR_T           dir,
    const   UI32_T              all_queue,
    const   CLX_TM_HANDLER_T    handler,
    UI32_T                      *ptr_enable);

CLX_ERROR_NO_T
hal_lightning_tm_setSpeed(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_SPEED_T    speed);

CLX_ERROR_NO_T
hal_lightning_tm_configTdm(
    const   UI32_T              unit);

CLX_ERROR_NO_T
hal_lightning_tm_updatePortTdm(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              lane_cnt);

CLX_ERROR_NO_T
hal_lightning_tm_setSteeringEnable(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              enable);

CLX_ERROR_NO_T
hal_lightning_tm_getSteeringEnable(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_enable);

CLX_ERROR_NO_T
hal_lightning_tm_setSteering(
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

CLX_ERROR_NO_T
hal_lightning_tm_getSteering(
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

CLX_ERROR_NO_T
hal_lightning_tm_setStackingPort(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

CLX_ERROR_NO_T
hal_lightning_tm_syncIgrAll(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    tbl_idx,
    const UI32_T    field_num,
    const UI32_T    entry_idx,
    const CDB_FVP_T *ptr_fvp);

CLX_ERROR_NO_T
hal_lightning_tm_syncEgrAll(
    const UI32_T    unit,
    const UI32_T    bin_idx,
    const UI32_T    tbl_idx,
    const UI32_T    field_num,
    const UI32_T    entry_idx,
    const CDB_FVP_T *ptr_fvp);

CLX_ERROR_NO_T
hal_lightning_tm_getSubIdxFromBinPlane(
    const UI32_T                            unit,
    const UI32_T                            bin_idx,
    const UI32_T                            plane_idx,
    UI32_T                                  *ptr_hw_sub_idx);

void
hal_lightning_tm_getValidSubidxBmp(
    const UI32_T            unit,
    UI32_T                  *ptr_bmp);

void
hal_lightning_tm_transLogicalToPhysicalBinIdx(
    const UI32_T            unit,
    const UI32_T            bin_idx,
    UI32_T                  *ptr_hw_bin_idx);

void
hal_lightning_tm_getDpFromPlane(
    const UI32_T                            unit,
    const UI32_T                            plane_idx,
    UI32_T                                  *ptr_dp);

CLX_ERROR_NO_T
hal_lightning_tm_setPortLaneCnt(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            cnt);

CLX_ERROR_NO_T
hal_lightning_tm_setEpmTdmReset(
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_PORT_SPEED_T            speed,
    const   UI32_T                      enable);

CLX_ERROR_NO_T
hal_lightning_tm_resetEpmSpeed(
    const   UI32_T                      unit,
    const   UI32_T                      port);

CLX_ERROR_NO_T
hal_lightning_tm_deinitPortFlow(
    const   UI32_T                      unit,
    const   UI32_T                      port);

CLX_ERROR_NO_T
hal_lightning_tm_checkHealthMon(
    const UI32_T                        unit,
    const UI32_T                        port);

CLX_ERROR_NO_T
hal_lightning_tm_setCpiQueueTruncateSize(
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_TM_HANDLER_T            handler,
    const   UI32_T                      param0);

CLX_ERROR_NO_T
hal_lightning_tm_getCpiQueueTruncateSize(
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_TM_HANDLER_T            handler,
    UI32_T                              *ptr_param0);

CLX_ERROR_NO_T
hal_lightning_tm_getPauseStatus(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_status);

CLX_ERROR_NO_T
hal_lightning_tm_dumpRegPortState(
    const   UI32_T                      unit,
    const   UI32_T                      port);

CLX_ERROR_NO_T
hal_lightning_tm_setPortDefault(
    const   UI32_T                      unit,
    const   UI32_T                      port);

CLX_ERROR_NO_T
hal_lightning_tm_resetPortDefault(
    const   UI32_T                      unit,
    const   UI32_T                      port);

CLX_ERROR_NO_T
hal_lightning_tm_getPfcWdTaskCtrlBlock(
    const UI32_T                    unit,
    HAL_TM_TASK_PFCWD_CB_T       **pptr_cb);

CLX_ERROR_NO_T
hal_lightning_tm_getPfcWdQueueEntry(
    const UI32_T                    unit,
    const CLX_PORT_T                port,
    const UI32_T                    queue,
    HAL_TM_PFCWD_QUEUE_ENTRY_T       **pptr_entry);

CLX_ERROR_NO_T
hal_lightning_tm_registerPfcWdCallback(
    const UI32_T                        unit,
    const CLX_TM_PFCWD_HANDLE_FUNC_T    notify_function,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_lightning_tm_deregisterPfcWdCallback(
    const UI32_T                        unit,
    const CLX_TM_PFCWD_HANDLE_FUNC_T    notify_function,
    void                                *ptr_cookie);

/* FUNCTION NAME:   hal_lightning_tm_setPfcWd
 * PURPOSE:
 *      This API is used to configure PFCWD on queue.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  physical port ID
 *      handler     --  Egress queue handler.
 *      ptr_entry   --  PFCWD Configuration
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lightning_tm_setPfcWd(
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_ENTRY_T                *ptr_entry);

/* FUNCTION NAME:   hal_lightning_tm_getPfcWd
 * PURPOSE:
 *      This API is used to get current configuration of PFCWD.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  physical port ID
 *      handler     --  Egress queue handler.
 *
 * OUTPUT:
 *      ptr_entry   --  PFCWD Configuration
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_lightning_tm_getPfcWd(
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_ENTRY_T                *ptr_entry);


/* FUNCTION NAME:   hal_lightning_tm_getPfcWdState
 * PURPOSE:
 *      This API is used to get current state of PFCWD.
 * INPUT:
 *      unit        --  Device unit number
 *      port        --  physical port ID
 *      handler     --  queue handler.
 *
 * OUTPUT:
 *      ptr_state       --  PFCWD Current State
 *
 * RETURN:
 *      CLX_E_OK  --  Operation succeeded.
 *      Others    --  Operation failed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T hal_lightning_tm_getPfcWdState(
    const UI32_T                        unit,
    const CLX_PORT_T                    port,
    const CLX_TM_HANDLER_T              handler,
    CLX_TM_PFCWD_STATE_T                *ptr_state);

#endif  /* #ifndef HAL_LIGHTNING_TM_H */

