/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   hal_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_TM_H
#define HAL_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>
#include <osal/osal_timer.h>
#include <hal/common/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* front port num + pcie + 2 cpi + 2 rc */
#define HAL_TM_HW_PORT_NUM                      (HAL_PORT_NUM + 1 + 2 + 2)

/*#define HAL_TM_DEBUG_PRINTF_EABLED*/
/*high 4 bit(bit[31:28]) means object type*/
#define HAL_TM_HANDLER_TYPE_SHIFT (28)

/*bit[31:28] object type encoding*/
#define HAL_TM_HANDLER_LEGACY_QUEUE_TYPE         (0)
#define HAL_TM_HANDLER_UNICAST_QUEUE_TYPE        (1)
#define HAL_TM_HANDLER_MULTICAST_QUEUE_TYPE      (2)
#define HAL_TM_HANDLER_SCHEDULE_NODE_TYPE        (3)

/* queue num*/
#define HAL_TM_CPU_QUEUE_NUM        (48)
#define HAL_TM_UNICAST_QUEUE_NUM    (8)
#define HAL_TM_MULTICAST_QUEUE_NUM  (8)
#define HAL_TM_LEGACY_QUEUE_NUM     (8)
#define HAL_TM_CPI_QUEUE_NUM        (8)


/*DEQ ranker queue status query time(unit is us)*/
#define HAL_TM_DEQ_RANKER_QUERY_TIME (50)

/*DEQ ranker queue status query loops is limited to be 160*/
#define HAL_TM_DEQ_RANKER_QUERY_MAX_LOOP (160)


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_MISC_LOCK(unit)          (hal_tm_misc_lockResource(unit))
#define HAL_TM_MISC_UNLOCK(unit)        (hal_tm_misc_unlockResource(unit))
#define HAL_TM_SNAPSHOT_LOCK(unit)      (hal_tm_snapshot_lockResource(unit))
#define HAL_TM_SNAPSHOT_UNLOCK(unit)    (hal_tm_snapshot_unlockResource(unit))


#define HAL_TM_HANDLER_SET(handler, type, id)                        \
        ((handler) = ((type) << HAL_TM_HANDLER_TYPE_SHIFT) + (id))

#define HAL_TM_HANDLER_GET(handler, type, id) do {                   \
        (type) = ((handler) >> HAL_TM_HANDLER_TYPE_SHIFT);           \
        (id) = ((handler) & ((1U << HAL_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while(0)

/* handler id valid check*/
#define HAL_TM_UNICAST_QUEUE_HANDLER_ID_VALID(id)   \
        (((id) >= 0) && ((id) < HAL_TM_UNICAST_QUEUE_NUM))

#define HAL_TM_MULTICAST_QUEUE_HANDLER_ID_VALID(id) \
        (((id) >= 0) && ((id) < HAL_TM_MULTICAST_QUEUE_NUM))

#define HAL_TM_CPU_QUEUE_HANDLER_ID_VALID(id)       \
        (((id) >= 0) && ((id) < HAL_TM_CPU_QUEUE_NUM))

#define HAL_TM_LEGACY_QUEUE_HANDLER_ID_VALID(id)    \
        (((id) >= 0) && ((id) < HAL_TM_LEGACY_QUEUE_NUM))

/*schedule node handler id valid check, root node is exculde*/
#define HAL_TM_SCHEDULE_NODE_HANDLER_ID_VALID(id)   \
        (((id) >= 0) && ((id) < HAL_TM_SCH_NODE_NUM - 1))

/*check macro*/
#define  HAL_TM_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__)   \
        (((__value__) > (__max__)) || ((__value__) < (__min__)))

#define HAL_TM_SNAPSHOT_TASK_NAME           ("SNAPSHOT_TASK")
#define HAL_TM_SNAPSHOT_SEM_NAME            ("TM_SNAPSHOT")
#define HAL_TM_SNAPSHOT_LIST_NAME           ("TM_SNAPSHOT_LIST")

/* unit 10ms */
#define HAL_TM_SNAPSHOT_INTERVAL_UNIT       (10 * 1000)
#define HAL_TM_SNAPSHOT_STACK_SIZE          (64 * 1024)
#define HAL_TM_SNAPSHOT_THREAD_PRI          (10)
#define HAL_TM_SNAPSHOT_CALLBACK_NUM        (3)

/* PFCWD Task */
#define HAL_TM_PFCWD_DEFAULT_INTERVAL_MS                (1) //Defaule 1ms
//#define HAL_TM_PFCWD_DEFAULT_INTERVAL_MICRO_SEC         (10 * 1000) //Defaule 1ms
#define HAL_TM_PFCWD_STACK_SIZE                         (64 * 1024)
#define HAL_TM_PFCWD_SEM_NAME                           ("TM_PFCWD")
#define HAL_TM_PFCWD_TASK_NAME                          ("PFCWD_TASK")
#define HAL_TM_PFCWD_THREAD_PRI                         (10)
#define HAL_TM_PFCWD_CALLBACK_NUM           (3)

/* customer init type default value*/
#define HAL_TM_CFG_TYPE_STEERING_TRUNCATE_ENABLE_DFLT   (0)     /* do not truncate */
#define HAL_TM_CFG_TYPE_BUF_SNAPSHOT_INTERVAL_DFLT      (100)   /* 100 units (100 * 10ms = 1s) */

#define HAL_TM_CFG_TYPE_BUF_FAIR_BUF_CTRL               (1)
#define HAL_TM_CFG_TYPE_BUF_USER_BUF_CTRL               (0)
#define HAL_TM_CFG_TYPE_FLOWCTRL_RESERVE_MODE           (0)

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_TDM_MACRO_PORT_ONE = 0,
    HAL_TDM_MACRO_PORT_TWO,
    HAL_TDM_MACRO_PORT_FOUR,
    HAL_TDM_MACRO_PARTIAL_PORT_ONE,
    HAL_TDM_MACRO_PARTIAL_PORT_TWO,
    HAL_TDM_MACRO_PARTIAL_PORT_THREE,
    HAL_TDM_MACRO_LAST
} HAL_TDM_RESULT_T;

/* TDM related structure */
typedef struct HAL_TM_PLANE_TDM_S
{
#define HAL_TM_TDM_OS_ONLY          (1U << 0)
#define HAL_TM_TDM_40G_ONLY         (1U << 1)
#define HAL_TM_TDM_CLOCK_900MHZ     (1U << 2)
#define HAL_TM_TDM_CLOCK_975MHZ     (1U << 3)
#define HAL_TM_TDM_CLOCK_1075MHZ    (1U << 4)
#define HAL_TM_TDM_WITH_PCI_PORT    (1U << 5)
#define HAL_TM_TDM_WITH_CPI_PORT    (1U << 6)
#define HAL_TM_TDM_CLOCK_924MHZ     (1U << 7)
#define HAL_TM_TDM_WITH_RC_PORT     (1U << 8)

    UI32_T  flags;
    UI32_T  slot_period;
    I16_T   slot_array[256];
} HAL_TM_PLANE_TDM_T;

typedef struct HAL_TM_TDM_CB_S
{
    HAL_TM_PLANE_TDM_T *ptr_plane_tdm_info[32]; /*avoid coverity*/
} HAL_TM_TDM_CB_T;

/* Port Speed */
/* Please check HW define for all speed setting when add other speed*/
typedef enum
{
    HAL_TM_PORT_SPEED_1G       = 1,
    HAL_TM_PORT_SPEED_10G      = 2,
    HAL_TM_PORT_SPEED_25G      = 3,
    HAL_TM_PORT_SPEED_40G      = 4,
    HAL_TM_PORT_SPEED_50G      = 5,
    HAL_TM_PORT_SPEED_100G     = 6,
    HAL_TM_PORT_SPEED_LAST
} HAL_TM_PORT_SPEED_T;

/*structure of TM MAC MACRO*/
typedef struct HAL_TM_MAC_MACRO_S
{
    UI8_T   ppid_lane0; /*PPID for lane 0, 63 for default*/
    UI8_T   ppid_lane1; /*PPID for lane 1, 63 for default*/
    UI8_T   ppid_lane2; /*PPID for lane 2, 63 for default*/
    UI8_T   ppid_lane3; /*PPID for lane 3, 63 for default*/
    UI32_T  gp;         /*1:gaurantee port; 0: non-gautantee port*/
} HAL_TM_MAC_MACRO_T;

/*structure of TM PPID*/
typedef struct HAL_TM_PPID_S
{
    UI16_T  mac_macro;  /*TM MAC MACRO ID*/
    UI16_T  lane;       /*0~3*/
} HAL_TM_PPID_T;

/*Type of CLX port translate*/
typedef enum
{
    HAL_TM_PORT_TRANS_TYPE_MP = 0,
    HAL_TM_PORT_TRANS_TYPE_PP,
    HAL_TM_PORT_TRANS_TYPE_LAST
} HAL_TM_PORT_TRANS_TYPE_T;

/*Type of Object ID for warm-boot*/
typedef enum
{
    HAL_TM_WBDB_SCH_TOPOLOGY,
    HAL_TM_WBDB_BUF_PROFILE,
    HAL_TM_WBDB_BUF_SS_EGR_HYS_THD,
    HAL_TM_WBDB_LAST
} HAL_TM_WBDB_T;

typedef enum
{
    HAL_TM_PFCWD_EVENT_ENABLE,             /* Feature turn to enable */
    HAL_TM_PFCWD_EVENT_DISABLE,
    HAL_TM_PFCWD_EVENT_DETECTED,
    HAL_TM_PFCWD_EVENT_RECOVER_TIMEOUT,
    HAL_TM_PFCWD_EVENT_CONFIG_CHANGE,      /* Already Enabled but configure change */
    HAL_TM_PFCWD_EVENT_PFC_ENABLE,
    HAL_TM_PFCWD_EVENT_PFC_DISABLE,
    HAL_TM_PFCWD_EVENT_LAST
} HAL_TM_PFCWD_EVENT_T;

/*control block for misc module*/
typedef struct HAL_TM_MISC_CB_S
{
    CLX_SEMAPHORE_ID_T    misc_sema; /*semaphore for misc module*/
}HAL_TM_MISC_CB_T;

typedef struct HAL_TM_SNAPSHOT_CALLBACK_S
{
    CLX_TM_SNAPSHOT_FUNC_T      callback;
    void                        *ptr_cookie;
}HAL_TM_SNAPSHOT_CALLBACK_T;

typedef struct HAL_TM_TASK_SNAPSHOT_CB_S
{
    CLX_SEMAPHORE_ID_T          sem_snapshot;
    CLX_THREAD_ID_T             snapshot_task_id;
    CLX_TM_POOL_BUF_SNAPSHOT_T  snapshot[HAL_BIN_NUM];
    UI32_T                      interval;
    UI32_T                      egr_global_hys_thd;
    HAL_TM_SNAPSHOT_CALLBACK_T  callback_list[HAL_TM_SNAPSHOT_CALLBACK_NUM];
} HAL_TM_TASK_SNAPSHOT_CB_T;

typedef struct HAL_TM_PFCWD_TIMER_ENTRY_S
{
    UI32_T                               unit;
    UI32_T                               port;
    UI8_T                                queue_id;
}HAL_TM_PFCWD_TIMER_ENTRY_T;
typedef struct HAL_TM_PFCWD_QUEUE_ENTRY_S
{
    BOOL_T                      enable;
    UI8_T                       queue;
    UI8_T                       reg_member_idx;
    CLX_TM_PFCWD_STATE_T        state;
    UI32_T                      detection_time;
    UI32_T                      recovery_time;
    CLX_TM_PFCWD_ACTION_T       action;
    CLX_PORT_FC_T               old_mac_pfc_config;
    UI32_T                      old_pfc_pcp_mapping;
    UI32_T                      old_dscp_pcp_mapping_list[HAL_QOS_DSCP_NUM];
    UI32_T                      old_dscp_pcp_mapping_count;
    OSAL_TIMER_ID_T             timerid;
    HAL_TM_PFCWD_TIMER_ENTRY_T  *restore_timer_entry;   /* arg for timeout, need free when timeout or timer stop*/
}HAL_TM_PFCWD_QUEUE_ENTRY_T;

typedef struct HAL_TM_PFCWD_PORT_ENTRY_S
{
    CLX_SEMAPHORE_ID_T          sem;
    UI8_T                       supported_pfc_num;
    HAL_TM_PFCWD_QUEUE_ENTRY_T  *queue_entry;     
}HAL_TM_PFCWD_PORT_ENTRY_T;

typedef struct HAL_TM_PFCWD_CALLBACK_S
{
    CLX_TM_PFCWD_HANDLE_FUNC_T      callback;
    void                        *ptr_cookie;
}HAL_TM_PFCWD_CALLBACK_T;

typedef struct HAL_TM_TASK_PFCWD_CB_S
{
    CLX_SEMAPHORE_ID_T          sem_pfcwd; //Protect callback_list, port entry also has it own lock.
    CLX_THREAD_ID_T             task_id;
    UI32_T                      interval;
    HAL_TM_PFCWD_PORT_ENTRY_T   entry_array[HAL_PORT_NUM];
    HAL_TM_PFCWD_CALLBACK_T     callback_list[HAL_TM_PFCWD_CALLBACK_NUM];
} HAL_TM_TASK_PFCWD_CB_T;

typedef struct HAL_TM_TASK_CB_S
{
    HAL_TM_TASK_SNAPSHOT_CB_T       snapshot_cb;
} HAL_TM_TASK_CB_T;


CLX_ERROR_NO_T
hal_tm_misc_lockResource (
    const UI32_T    unit );

CLX_ERROR_NO_T
hal_tm_misc_unlockResource (
    const UI32_T    unit );

CLX_ERROR_NO_T
hal_tm_misc_initRsrc(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_misc_deinitRsrc(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_misc_deinitCfg(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_initRsrc(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_deinitRsrc(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_deinitCfg(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_tm_setProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_PROPERTY_T     property,
    const UI32_T                param0,
    const UI32_T                param1);

CLX_ERROR_NO_T
hal_tm_getProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_PROPERTY_T     property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);

void
hal_tm_getPlaneNum(
    const   UI32_T              unit,
    UI32_T                      *ptr_plane_num);

void
hal_tm_getBinNum(
    const   UI32_T              unit,
    UI32_T                      *ptr_bin_num);

CLX_ERROR_NO_T
hal_tm_dumpDb(
    const UI32_T    unit,
    const UI32_T    flags);

CLX_ERROR_NO_T
hal_tm_dumpReg(
    const   UI32_T          unit,
    const   UI32_T          flags);

CLX_ERROR_NO_T
hal_tm_getTdmCtrlBlock(
    const UI32_T                    unit,
    HAL_TM_TDM_CB_T                 **pptr_cb);

CLX_ERROR_NO_T
hal_tm_getTdmPlaneCtrlBlock(
    const UI32_T                    unit,
    const UI32_T                    plane_idx,
    HAL_TM_PLANE_TDM_T            **pptr_pl_cb);

CLX_ERROR_NO_T
hal_tm_initTaskRsrc(
    const UI32_T                unit);

CLX_ERROR_NO_T
hal_tm_deinitTaskRsrc(
    const UI32_T                unit);

CLX_ERROR_NO_T
hal_tm_getSnapshotTaskCtrlBlock(
    const UI32_T                    unit,
    HAL_TM_TASK_SNAPSHOT_CB_T       **pptr_cb);

CLX_ERROR_NO_T
hal_tm_snapshot_lockResource(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_tm_snapshot_unlockResource(
    const UI32_T    unit);
#endif  /* #ifndef HAL_TM_H */

