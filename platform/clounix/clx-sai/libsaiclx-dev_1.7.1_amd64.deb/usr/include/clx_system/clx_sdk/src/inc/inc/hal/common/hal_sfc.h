/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_sfc.h
 * PURPOSE:
 *      It provide sfc hal layer api.
 * NOTES:
 *
 */

#ifndef HAL_SFC_H
#define HAL_SFC_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_sfc.h>

#include <hal/common/hal_vlan.h>
#include <hal/common/hal_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SFC_GET_IEV_ENCAP_BY_DI(__di__, __iev_encap_idx__)  \
    do                                                              \
    {                                                               \
        __iev_encap_idx__ = (__di__ - HAL_NSH_BASE_ID) + HAL_TUNNEL_NUM;\
    }   while(0)

#define HAL_SFC_GET_IEV_ENCAP_BY_CLXPORT(__port__, __iev_encap_idx__)       \
    do                                                                          \
    {                                                                           \
        HAL_OBJ_DI_GET(__port__, __iev_encap_idx__);                        \
        HAL_SFC_GET_IEV_ENCAP_BY_DI(__iev_encap_idx__, __iev_encap_idx__);  \
    }   while(0)

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
CLX_ERROR_NO_T
hal_sfc_init(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_sfc_deinit(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_sfc_createPort(
    const UI32_T unit,
    const CLX_SFC_ENCAP_KEY_T *ptr_key,
    CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_sfc_destroyPort(
    const UI32_T unit,
    const CLX_PORT_T port);

CLX_ERROR_NO_T
hal_sfc_getPort(
    const UI32_T unit,
    const CLX_SFC_ENCAP_KEY_T *ptr_key,
    CLX_PORT_T *ptr_port);

CLX_ERROR_NO_T
hal_sfc_getKey(
    const UI32_T unit,
    const CLX_PORT_T port,
    CLX_SFC_ENCAP_KEY_T *ptr_key);

CLX_ERROR_NO_T
hal_sfc_addForwarder(
    const UI32_T unit,
    const CLX_SFC_FORWARDER_T *ptr_forwarder);

CLX_ERROR_NO_T
hal_sfc_delForwarder(
    const UI32_T unit,
    const CLX_SFC_FORWARDER_T *ptr_forwarder);

CLX_ERROR_NO_T
hal_sfc_getForwarder(
    const UI32_T unit,
    CLX_SFC_FORWARDER_T *ptr_forwarder);





/* FUNCTION NAME: hal_sfc_getSrcSuppTag
 * PURPOSE:
 *      Get SFC's src_supp_tag
 * INPUT:
 *      unit              --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      ptr_src_supp_tag  --  source suppression tag
 * NOTES:
 */
UI32_T
hal_sfc_getSrcSuppTag(
    const UI32_T unit);

/* FUNCTION NAME: hal_sfc_getHwVidInfo
 * PURPOSE:
 *      Translate clx vlan action to hw vid_info
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  SFC clx_port
 *      ptr_vlan_tag_action --  User input vlan value
 *      vlan_action         --  User input vlan action
 * OUTPUT:
 *      ptr_vid_info        --  Hardware vid_info
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_sfc_getHwVidInfo(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VLAN_TAG_ACTION_T *ptr_vlan_tag_action,
    const CLX_VLAN_ACTION_T     vlan_action,
    HAL_VLAN_VID_CTL_T          *ptr_vid_info);

/* FUNCTION NAME: hal_sfc_getSwVidInfo
 * PURPOSE:
 *      Translate hw vid_info to clx vlan action
 * INPUT:
 *      unit                --  Device unit number
 *      ptr_vid_info        --  Hardware vid_info
 * OUTPUT:
 *      ptr_vlan_tag_action --  User vlan value
 *      ptr_vlan_action     --  User vlan action
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_sfc_getSwVidInfo(
    const UI32_T                 unit,
    const HAL_VLAN_VID_CTL_T     *ptr_vid_info,
    CLX_VLAN_TAG_ACTION_T        *ptr_vlan_tag_action,
    CLX_VLAN_ACTION_T            *ptr_vlan_action);

/* FUNCTION NAME: hal_sfc_getHwInitInfo
 * PURPOSE:
 *      Get seg&nvo3_encap_idx which init
 * INPUT:
 *      unit                --  Device unit number
 *      fdid                --  Forwarding domain (for udlay tunnel to get seg)
 *      port                --  SFC clx_port
 * OUTPUT:
 *      ptr_seg             --  Segment id
 *      ptr_nvo3_encap_idx  --  nvo3_encap_idx
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_sfc_getHwInitInfo(
    const UI32_T        unit,
    const UI32_T        fdid,
    const CLX_PORT_T    port,
    UI32_T              *ptr_seg,
    UI32_T              *ptr_nvo3_encap_idx);

/* FUNCTION NAME: hal_sfc_getSwInitInfo
 * PURPOSE:
 *      transform hardware fields to user view for GET function
 * INPUT:
 *      unit                --  Device unit number
 *      nvo3_encap_idx      --  nvo3_encap_idx
 * OUTPUT:
 *      ptr_port            --  Interface object
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 */
CLX_ERROR_NO_T
hal_sfc_getSwInitInfo(
    const UI32_T    unit,
    const UI32_T    nvo3_encap_idx,
    CLX_PORT_T      *ptr_port);

/* FUNCTION NAME: hal_sfc_addNshService
 * PURPOSE:
 *      This API is used to add/set nsh-based service.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Clx port
 *      ptr_seg_srv -- service information
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sfc_addNshService(
    const UI32_T unit,
    const CLX_PORT_T port,
    const CLX_PORT_SEG_SRV_T *ptr_seg_srv);

/* FUNCTION NAME: hal_sfc_delNshService
 * PURPOSE:
 *      This API is used to del nsh-based service.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Clx port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sfc_delNshService(
    const UI32_T unit,
    const CLX_PORT_T port);

/* FUNCTION NAME: hal_sfc_getNshService
 * PURPOSE:
 *      This API is used to get nsh-based service.
 * INPUT:
 *      unit -- Device unit number
 *      port -- Clx port
 * OUTPUT:
 *      ptr_seg_srv -- service information
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_sfc_getNshService(
    const UI32_T unit,
    const CLX_PORT_T port,
    CLX_PORT_SEG_SRV_T *ptr_seg_srv);

CLX_ERROR_NO_T
hal_sfc_updateAdjInfo(
    const UI32_T unit,
    const UI32_T adj_id,
    const HAL_L3_ADJ_INFO_T *ptr_adj_info);

CLX_ERROR_NO_T
hal_sfc_updateNvo3AdjInfo(
    const UI32_T unit,
    const UI32_T nvo3_adj_id,
    const CLX_PORT_T port);
#endif