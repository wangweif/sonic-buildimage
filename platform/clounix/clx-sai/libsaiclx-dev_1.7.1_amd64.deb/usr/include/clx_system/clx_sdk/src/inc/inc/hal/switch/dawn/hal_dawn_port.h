/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_port.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_DAWN_PORT_H
#define HAL_DAWN_PORT_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS */

/* FUNCTION NAME:   hal_dawn_port_setLaneMap
 * PURPOSE:
 *      This API is used to set the mapping between unit/port and mac/lane
 *      number.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 *      eth_macro       --  eth MAC macro ID
 *      lane            --  eth lane ID
 *      max_speed       --  The maximum speed of the physical port
 *      flags           --  Attributes of the physical port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *      This API is suggested to be used during SDK initialization.
 *
 */
CLX_ERROR_NO_T
hal_dawn_port_setLaneMap(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              eth_macro,
    const   UI32_T              lane,
    const   CLX_PORT_SPEED_T    max_speed,
    const   UI32_T              flags);

/* FUNCTION NAME:   hal_dawn_port_getLaneMap
 * PURPOSE:
 *      This API is used to get the mapping between unit/port and mac/lane
 *      number.
 * INPUT:
 *      unit            --  Device unit number
 *      port            --  Physical port ID
 * OUTPUT:
 *      ptr_eth_macro   --  eth MAC macro ID
 *      ptr_lane        --  eth lane ID
 *      ptr_max_speed   --  The maximum speed of the physical port
 *      ptr_flags       --  Attributes of the physical port
 * RETURN:
 *      CLX_E_OK                --  The operation success
 *      CLX_E_BAD_PARAMETER     --  Bad parameter
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_dawn_port_getLaneMap(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_eth_macro,
    UI32_T                      *ptr_lane,
    CLX_PORT_SPEED_T            *ptr_max_speed,
    UI32_T                      *ptr_flags);

#endif  /* #ifndef HAL_DAWN_PORT_H */
