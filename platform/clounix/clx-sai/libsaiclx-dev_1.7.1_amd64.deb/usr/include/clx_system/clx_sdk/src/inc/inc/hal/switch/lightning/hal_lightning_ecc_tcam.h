/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_ecc_tcam.h
 * PURPOSE:
 *  Provide HAL ECC TCAM manipulation APIs for CL8570.
 *
 * NOTES:
 *
 */

#ifndef HAL_LIGHTNING_ECC_TCAM_H
#define HAL_LIGHTNING_ECC_TCAM_H

/* INCLUDE FILE DECLARATIONS
 */

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_initTcam(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_deinitTcam(
    const UI32_T      unit,
    HAL_IO_WB_DB_T    *ptr_db);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_handleTcamIntr(
    const UI32_T             unit,
    const HAL_INTR_TYPE_T    intr_type);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_checkTcam(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    const UI32_T    entry_num,
    UI32_T          *ptr_ecc_found);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_enableTcam(
    const UI32_T    unit,
    const UI32_T    tip,
    const UI32_T    en);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_getTipInfoByTbl(
    const UI32_T    unit,
    const UI32_T    inst,
    const UI32_T    sub_inst,
    const UI32_T    tbl_id,
    const UI32_T    tbl_entry_idx,
    UI32_T          *ptr_tip);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_getTblByTipInfo(
    const UI32_T    unit,
    const UI32_T    tip,
    const UI32_T    tip_entry,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_tbl_entry_idx);

CLX_ERROR_NO_T
hal_lightning_ecc_tcam_getEccbypByTipInfo(
    const UI32_T    unit,
    const UI32_T    tip,
    UI32_T          *ptr_inst,
    UI32_T          *ptr_sub_inst,
    UI32_T          *ptr_tbl_id,
    UI32_T          *ptr_field_id_0,
    UI32_T          *ptr_field_id_1); /* HAL_INVALID_ID : invalid */

#endif  /* #ifndef HAL_LIGHTNING_ECC_TCAM_H */
