/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_swc_cim.h
 * PURPOSE:
 *      Provide Centralized Index Management API for special HW resource: e.g. IEV.
 *
 * NOTES:
 *
 *
 */

#ifndef HAL_SWC_CIM_H
#define HAL_SWC_CIM_H


/* INCLUDE FILE DECLARATIONS
 */
#include <cdb/cdb.h>
#include <hal/common/hal.h>

/* NAMING CONSTANT DECLARATIONS
 */


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SWC_CIM_FLAGS_EMI_FCM0_ACL              (0x1UL << 0)
#define HAL_SWC_CIM_FLAGS_EMI_FCM0_FLW              (0x1UL << 1)
#define HAL_SWC_CIM_FLAGS_EMI_FCM1_ACL              (0x1UL << 2)
#define HAL_SWC_CIM_FLAGS_EMI_FCM1_FLW              (0x1UL << 3)
#define HAL_SWC_CIM_FLAGS_IEV_L2_INDIR              (0x1UL << 4)
#define HAL_SWC_CIM_FLAGS_IEV_INDIR_SINGLE_1X       (0x1UL << 5)

#define HAL_SWC_CIM_IEV_MAX_BANK_NUM                16
#define HAL_SWC_CIM_IEV_ENTRY_NUM_PER_BANK          (16 * 1024)
#define HAL_SWC_CIM_IEV_ENTRY_NUM_PER_INDIR_BANK    (32 * 1024)

#if defined(CLX_EN_DAWN)
#define HAL_SWC_CIM_EMI_MAX_BANK_NUM                9
#define HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK       16
#elif defined(CLX_EN_LIGHTNING)
#define HAL_SWC_CIM_EMI_MAX_BANK_NUM                8
#define HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK       4
#else
#define HAL_SWC_CIM_EMI_MAX_BANK_NUM                1
#define HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK       1
#endif
#define HAL_SWC_CIM_EMI_ENTRY_NUM_PER_PAGE          1024
#define HAL_SWC_CIM_EMI_MAX_ENTRY_NUM_PER_BANK      (HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK * HAL_SWC_CIM_EMI_ENTRY_NUM_PER_PAGE)

#define HAL_SWC_CIM_FLAGS_EMI_FCM0                  (HAL_SWC_CIM_FLAGS_EMI_FCM0_ACL | HAL_SWC_CIM_FLAGS_EMI_FCM0_FLW)
#define HAL_SWC_CIM_FLAGS_EMI_FCM1                  (HAL_SWC_CIM_FLAGS_EMI_FCM1_ACL | HAL_SWC_CIM_FLAGS_EMI_FCM1_FLW)
#define HAL_SWC_CIM_FLAGS_EMI_FCM_NONE              0

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_SWC_CIM_IEV_TYPE_NONE,
    HAL_SWC_CIM_IEV_TYPE_L2,
    HAL_SWC_CIM_IEV_TYPE_L3,
    HAL_SWC_CIM_IEV_TYPE_L4,
    HAL_SWC_CIM_IEV_TYPE_L2_INDIR,
    HAL_SWC_CIM_IEV_TYPE_L3_INDIR,
    HAL_SWC_CIM_IEV_TYPE_L2_FDB,        /*Only for L2 FDB*/
    HAL_SWC_CIM_IEV_TYPE_LAST
} HAL_SWC_CIM_IEV_TYPE_T;

typedef struct
{
    HAL_SWC_CIM_IEV_TYPE_T  type;
    UI32_T              allocted_count;
} HAL_SWC_CIM_IEV_INFO_T;

typedef enum
{
    HAL_SWC_CIM_FCM_WIDTH_NONE = 0,
    HAL_SWC_CIM_FCM_WIDTH_1X,
    HAL_SWC_CIM_FCM_WIDTH_2X,
    HAL_SWC_CIM_FCM_WIDTH_4X,
    HAL_SWC_CIM_FCM_WIDTH_LAST
}HAL_SWC_CIM_FCM_WIDTH_T;

typedef struct
{
    UI32_T                  type[HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK];  /* HAL_SWC_CIM_FLAGS_EMI_FCM0_ACL or _FCM0_FLW type */
    HAL_SWC_CIM_FCM_WIDTH_T width[HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK]; /* entry width per page */
    UI32_T                  num[HAL_SWC_CIM_EMI_MAX_PAGE_NUM_PER_BANK];   /* entry num per page */
} HAL_SWC_CIM_EMI_FCM_T;

typedef struct
{
    UI32_T                  bit_flags[HAL_SWC_CIM_EMI_MAX_BANK_NUM];
    UI32_T                  adj_num[HAL_SWC_CIM_EMI_MAX_BANK_NUM];
    HAL_SWC_CIM_EMI_FCM_T   fcm_0[HAL_SWC_CIM_EMI_MAX_BANK_NUM];
    HAL_SWC_CIM_EMI_FCM_T   fcm_1[HAL_SWC_CIM_EMI_MAX_BANK_NUM];
    UI32_T                  nsh_num[HAL_SWC_CIM_EMI_MAX_BANK_NUM];
    UI32_T                  total_num[HAL_SWC_CIM_EMI_MAX_BANK_NUM];
} HAL_SWC_CIM_EMI_INFO_T;

typedef struct HAL_SWC_CIM_CB_S
{
    HAL_SWC_CIM_IEV_INFO_T  iev_info[HAL_SWC_CIM_IEV_MAX_BANK_NUM];
    HAL_SWC_CIM_EMI_INFO_T  emi_info;
    CLX_SEMAPHORE_ID_T      iev_sema;
    CLX_SEMAPHORE_ID_T      emi_sema;
} HAL_SWC_CIM_CB_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */
/* FUNCTION NAME:   hal_swc_cim_allocIndexEntry
 * PURPOSE:
 *      allocating a free IEV_RLST_U_* / EMI_RLST_U_* index and setting hw table.
 *
 * INPUT:
 *      unit            -- The unit number.
 *      inst_idx        -- The instance index.
 *      tbl_id          -- The hardware table id.
 *      flags           --  1. HAL_SWC_CIM_FLAGS_EMI_FCM0: table is EMI_RLST_U_FCM0
 *                          2. HAL_SWC_CIM_FLAGS_IEV_L2_INDIR: table is IEV_RLST_U_L2_INDIR
 *      field_num       -- Number of fields to be set.
 *      count           -- The requested consecutive count.
 *      ptr_field       -- The structure of CDB_FVP_T.
 * OUTPUT:
 *      entry_idx       -- The return index
 * RETURN:
 *      CLX_E_OK        -- Successfully init table.
 *      CLX_E_OTHERS    -- Fail to init table.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_swc_cim_allocIndexEntry(
    const UI32_T       unit,
    const UI32_T       inst_idx,
    const UI32_T       tbl_id,
    const UI32_T       flags,
    const UI32_T       field_num,
    const UI32_T       count,
    CDB_FVP_T          *ptr_field,
    UI32_T             *ptr_entry_idx);


/* FUNCTION NAME:   hal_swc_cim_freeIndexEntry
 * PURPOSE:
 *      free IEV_RLST_U_* / EMI_RLST_U_*entry index
 * INPUT:
 *      unit            -- The unit number.
 *      inst_idx        -- The instance index.
 *      tbl_id          -- The table id.
 *      flags           --  1. HAL_SWC_CIM_FLAGS_EMI_FCM0: table is EMI_RLST_U_FCM0, not the EMI_RLST_U_FCM1
 *                          2. HAL_SWC_CIM_FLAGS_IEV_L2_INDIR: table is IEV_RLST_U_L2_INDIR, not the IEV_RLST_U_L3_INDIR
 *      entry_idx       -- The return index
 *      count           -- The consecutive count.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK        -- Success.
 *      Others          -- Fail.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_swc_cim_freeIndexEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    tbl_id,
    const UI32_T    flags,
    const UI32_T    entry_idx,
    const UI32_T    count);


/* FUNCTION NAME:   hal_swc_cim_checkIndexEntry
 * PURPOSE:
 *      checking IEV_RLST_U_* / EMI_RLST_U_*entry index is valid or not.
 *
 * INPUT:
 *      unit            -- The unit number.
 *      inst_idx        -- The instance index.
 *      tbl_id          -- The table id.
 *      flags           --  1. HAL_SWC_CIM_FLAGS_EMI_FCM0: table is EMI_RLST_U_FCM0, not the EMI_RLST_U_FCM1
 *                          2. HAL_SWC_CIM_FLAGS_IEV_L2_INDIR: table is IEV_RLST_U_L2_INDIR, not the IEV_RLST_U_L3_INDIR
 *      entry_idx       -- The table index
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK                -- entry is found.
 *      CLX_E_ENTRY_NOT_FOUND   -- entry is not found.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
hal_swc_cim_checkIndexEntry(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    tbl_id,
    const UI32_T    flags,
    const UI32_T    entry_idx);

CLX_ERROR_NO_T
hal_swc_cim_showEmiInfo(const UI32_T    unit);

CLX_ERROR_NO_T
hal_swc_cim_showIevInfo(const UI32_T    unit);

CLX_ERROR_NO_T
hal_swc_cim_getEntryCnt(
    const UI32_T    unit,
    const UI32_T    inst_idx,
    const UI32_T    tbl_id,
    const UI32_T    flags,
    UI32_T          *ptr_entry_cnt);

CLX_ERROR_NO_T
hal_swc_cim_deinit(
    const UI32_T    unit,
    HAL_IO_WB_DB_T  *ptr_db);

CLX_ERROR_NO_T
hal_swc_cim_init(
    const UI32_T    unit,
    const UI32_T    l2_fdb_base,
    const UI32_T    l2_fdb_bank_num,
    C8_T            *ptr_nv_buf);
#endif
