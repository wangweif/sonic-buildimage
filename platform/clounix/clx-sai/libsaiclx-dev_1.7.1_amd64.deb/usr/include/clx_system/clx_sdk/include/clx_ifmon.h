/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   clx_ifmon.h
 * PURPOSE:
 *      It provides IFMON module API.
 * NOTES:
 */

#ifndef CLX_IFMON_H
#define CLX_IFMON_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Interface Monitor Mode */
typedef enum
{
    CLX_IFMON_MODE_INTR = 0 ,
    CLX_IFMON_MODE_POLL,
    CLX_IFMON_MODE_LAST
} CLX_IFMON_MODE_T;

typedef void (*CLX_IFMON_NOTIFY_FUNC_T)(
    const   UI32_T      unit,
    const   UI32_T      port,
    const   UI32_T      link,
    void                *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_ifmon_getMode
 * PURPOSE:
 *      This API is used to get interface monitor mode, interface monitor
 *      port bitmap, and interface monitor interval.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      ptr_mode            --  Pointer for interface monitor mode
 *      ptr_port_bitmap     --  Pointer for interface monitor port bitmap
 *      ptr_interval_us     --  Pointer for interface monitor polling interval
 *                              in microseconds
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      The polling interval is valid if and only if the interface monitor
 *      polling mode is used.
 */
CLX_ERROR_NO_T
clx_ifmon_getMode(
    const   UI32_T              unit,
    CLX_IFMON_MODE_T            *ptr_mode,
    CLX_PORT_BITMAP_T           *ptr_port_bitmap,
    UI32_T                      *ptr_interval_us);

/* FUNCTION NAME:   clx_ifmon_setMode
 * PURPOSE:
 *      This API is used to set interface monitor mode, interface monitor
 *      port bitmap, and interface monitor interval.
 * INPUT:
 *      unit                --  Device unit number
 *      mode                --  Interface monitor mode
 *      port_bitmap         --  Interface monitor port bitmap
 *      interval_us         --  Interface monitor polling interval in
 *                              microseconds
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      The polling interval is valid if and only if the interface monitor
 *      polling mode is used.
 */
CLX_ERROR_NO_T
clx_ifmon_setMode(
    const   UI32_T              unit,
    const   CLX_IFMON_MODE_T    mode,
    const   CLX_PORT_BITMAP_T   port_bitmap,
    const   UI32_T              interval_us);

/* FUNCTION NAME:   clx_ifmon_register
 * PURPOSE:
 *      This API is used to register a callback function to handle a port link change.
 * INPUT:
 *      unit                --  Device unit number
 *      notify_func         --  Callback function
 *      ptr_cookie          --  Cookie data of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_ifmon_register(
    const   UI32_T                      unit,
    const   CLX_IFMON_NOTIFY_FUNC_T     notify_func,
    void                                *ptr_cookie);

/* FUNCTION NAME:   clx_ifmon_deregister
 * PURPOSE:
 *      This API is used to deregister a callback function from callback functions.
 * INPUT:
 *      unit                --  Device unit number
 *      notify_func         --  Callback function
 *      ptr_cookie          --  Cookie data of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_ifmon_deregister(
    const   UI32_T                      unit,
    const   CLX_IFMON_NOTIFY_FUNC_T     notify_func,
    void                                *ptr_cookie);

#endif /* End of CLX_IFMON_H */
