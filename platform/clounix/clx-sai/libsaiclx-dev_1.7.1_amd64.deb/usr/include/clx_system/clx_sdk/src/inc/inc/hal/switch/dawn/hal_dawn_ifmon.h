/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_ifmon.h
 * PURPOSE:
 *      It provide HAL PORT module API.
 * NOTES:
 */

#ifndef HAL_DAWN_IFMON_H
#define HAL_DAWN_IFMON_H

/* INCLUDE FILE DECLARATIONS
 */

#include <clx_error.h>
#include <clx_types.h>
#include <cmlib/cmlib_list.h>
#include <clx_ifmon.h>

/* NAMING CONSTANT DECLARATIONS
 */

#if defined(CLX_LAMP)
#define HAL_DAWN_IFMON_MODE_DFLT         (CLX_IFMON_MODE_POLL)
#else
#define HAL_DAWN_IFMON_MODE_DFLT         (CLX_IFMON_MODE_INTR)
#endif

#define HAL_DAWN_IFMON_INTERVAL_DFLT     (500000)

#define HAL_DAWN_IFMON_STACK_SIZE        (64 * 1024)
#define HAL_DAWN_IFMON_THREAD_PRI        (85)

#define HAL_DAWN_IFMON_LANE_SHIFT_PER_MACRO  (2) /* 4 lanes per macro */
#define HAL_DAWN_IFMON_LANE_NUM_PER_MACRO    (1U << HAL_DAWN_IFMON_LANE_SHIFT_PER_MACRO)
#define HAL_DAWN_IFMON_LANE_MASK_PER_MACRO   (HAL_DAWN_IFMON_LANE_NUM_PER_MACRO - 1)

#define HAL_DAWN_IFMON_DIE_NUM               (2)
#define HAL_DAWN_IFMON_LANE_NUM_PER_DIE      (160)
#define HAL_DAWN_IFMON_LANE_NUM              (HAL_DAWN_IFMON_DIE_NUM * HAL_DAWN_IFMON_LANE_NUM_PER_DIE)
#define HAL_DAWN_IFMON_LANE_BITMAP_SIZE      (CLX_BITMAP_SIZE(HAL_DAWN_IFMON_LANE_NUM))

#define HAL_DAWN_IFMON_SPEED_BIT             (4)
#define HAL_DAWN_IFMON_SPEED_BITMAP_SIZE     (HAL_DAWN_IFMON_SPEED_BIT * HAL_DAWN_IFMON_LANE_BITMAP_SIZE)

#define HAL_DAWN_IFMON_NOTIFY_HANDLER_CNT    (16)

/* MACRO FUNCTION DECLARATIONS
 */

#define HAL_DAWN_IFMON_CFG_LOCK(unit)    hal_dawn_ifmon_lockIfmonResource(unit)
#define HAL_DAWN_IFMON_CFG_UNLOCK(unit)  hal_dawn_ifmon_unlockIfmonResource(unit)

#define HAL_DAWN_IFMON_FLOW_LOCK(unit)       hal_dawn_ifmon_lockFlow(unit)
#define HAL_DAWN_IFMON_FLOW_UNLOCK(unit)     hal_dawn_ifmon_unlockFlow(unit)

/* DATA TYPE DECLARATIONS
 */

typedef UI32_T  HAL_DAWN_IFMON_LANE_BITMAP_T[HAL_DAWN_IFMON_LANE_BITMAP_SIZE];
typedef UI32_T  HAL_DAWN_IFMON_SPEED_BITMAP_T[HAL_DAWN_IFMON_SPEED_BITMAP_SIZE];

typedef enum
{
    HAL_DAWN_IFMON_SPEED_ZERO = 0,
    HAL_DAWN_IFMON_SPEED_10M,
    HAL_DAWN_IFMON_SPEED_100M,
    HAL_DAWN_IFMON_SPEED_1G,
    HAL_DAWN_IFMON_SPEED_10G,
    HAL_DAWN_IFMON_SPEED_40G,
    HAL_DAWN_IFMON_SPEED_100G,
    HAL_DAWN_IFMON_SPEED_25G,
    HAL_DAWN_IFMON_SPEED_50G,
    HAL_DAWN_IFMON_SPEED_LAST
} HAL_DAWN_IFMON_SPEED_T;

typedef enum
{
    HAL_DAWN_IFMON_TYPE_DEV = 0,
    HAL_DAWN_IFMON_TYPE_HOST,
    HAL_DAWN_IFMON_TYPE_INTR,
    HAL_DAWN_IFMON_TYPE_CUR,
    HAL_DAWN_IFMON_TYPE_NEW,
    HAL_DAWN_IFMON_TYPE_SW,
    HAL_DAWN_IFMON_TYPE_LAST
} HAL_DAWN_IFMON_TYPE_T;

typedef enum
{
    HAL_DAWN_IFMON_FAULT_TYPE_LOCAL = 0,
    HAL_DAWN_IFMON_FAULT_TYPE_REMOTE,
    HAL_DAWN_IFMON_FAULT_TYPE_LAST
} HAL_DAWN_IFMON_FAULT_TYPE_T;

typedef struct HAL_DAWN_IFMON_STATE_S
{
    HAL_DAWN_IFMON_LANE_BITMAP_T     link_bitmap;
    HAL_DAWN_IFMON_LANE_BITMAP_T     fault_bitmap;
    HAL_DAWN_IFMON_SPEED_BITMAP_T    speed_bitmap;
} HAL_DAWN_IFMON_STATE_T;

typedef struct HAL_DAWN_IFMON_FAULT_STATE_S
{
    HAL_DAWN_IFMON_LANE_BITMAP_T     local_fault_bitmap;
    HAL_DAWN_IFMON_LANE_BITMAP_T     remote_fault_bitmap;
} HAL_DAWN_IFMON_FAULT_STATE_T;

typedef struct HAL_DAWN_IFMON_NOTIFY_HANDLER_S
{
    CLX_IFMON_NOTIFY_FUNC_T     notify_func;
    void                        *ptr_cookie;
} HAL_DAWN_IFMON_NOTIFY_HANDLER_T;

typedef struct HAL_DAWN_IFMON_CB_S
{
    CLX_SEMAPHORE_ID_T              sem_conf;
    CLX_SEMAPHORE_ID_T              sem_flow;
    BOOL_T                          monitor_state;
    CLX_THREAD_ID_T                 thread_id;
    CLX_IFMON_MODE_T                mode;
    UI32_T                          interval_us;
    HAL_DAWN_IFMON_STATE_T           dev_state;
    HAL_DAWN_IFMON_FAULT_STATE_T     dev_fault_type;
    HAL_DAWN_IFMON_STATE_T           host_state;
    HAL_DAWN_IFMON_STATE_T           intr_state;
    HAL_DAWN_IFMON_STATE_T           cur_state;
    HAL_DAWN_IFMON_STATE_T           new_state;
    HAL_DAWN_IFMON_STATE_T           sw_state;
    HAL_DAWN_IFMON_LANE_BITMAP_T     sw_status_bitmap;
    UI32_T                          callback_cnt;
    HAL_DAWN_IFMON_NOTIFY_HANDLER_T  notify_handler[HAL_DAWN_IFMON_NOTIFY_HANDLER_CNT];
    CMLIB_LIST_T                    *ptr_callback_list;
} HAL_DAWN_IFMON_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_dawn_ifmon_init
 *
 * PURPOSE:
 *      Initialize IfMon function.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  success
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_init(
    const   UI32_T          unit);

/* FUNCTION NAME: hal_dawn_ifmon_deinit
 *
 * PURPOSE:
 *      Deinitialize IfMon function.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  success
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_deinit(
    const   UI32_T          unit);

/* FUNCTION NAME: hal_dawn_ifmon_lockIfmonResource
 *
 * PURPOSE:
 *      Lock the resource of IfMon.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  success
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_lockIfmonResource(
    const UI32_T                    unit);

/* FUNCTION NAME: hal_dawn_ifmon_unlockIfmonResource
 *
 * PURPOSE:
 *      Unlock the resource of IfMon.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  success
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_unlockIfmonResource(
    const UI32_T                    unit);

/* FUNCTION NAME: hal_dawn_ifmon_lockFlow
 *
 * PURPOSE:
 *      Lock the flow of IfMon.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  success
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_lockFlow(
    const UI32_T                    unit);

/* FUNCTION NAME: hal_dawn_ifmon_unlockFlow
 *
 * PURPOSE:
 *      Unlock the flow of IfMon.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  success
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_unlockFlow(
    const UI32_T                    unit);

/* FUNCTION NAME:   hal_dawn_ifmon_getMonitorState
 * PURPOSE:
 *      To get monitor state.
 * INPUT:
 *      unit                -- Device unit number
 * OUTPUT:
 *      ptr_enable          -- Pointer for monitor state
 * RETURN:
 *      CLX_E_OK            -- Operation is successful.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getMonitorState(
    const UI32_T    unit,
    BOOL_T          *ptr_enable);

/* FUNCTION NAME:   hal_dawn_ifmon_setMonitorState
 * PURPOSE:
 *      To set monitor state.
 * INPUT:
 *      unit                -- Device unit number
 *      enable              -- Monitor state
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation is successful.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setMonitorState(
    const UI32_T    unit,
    const BOOL_T    enable);

/* FUNCTION NAME:   hal_dawn_ifmon_handleIsr
 * PURPOSE:
 *      To handle interrupt service routine.
 * INPUT:
 *      unit                --  Device unit number
 *      isr_cookie          --  ISR cookie
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_handleIsr(
    const   UI32_T          unit,
    const   UI32_T          isr_cookie);

/* FUNCTION NAME:   hal_dawn_ifmon_getSpeedFromBitmap
 * PURPOSE:
 *      To get speed from speed bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 *      speed_bitmap        --  Speed bitmap
 * OUTPUT:
 *         ptr_speed        --  Pointer for port speed
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getSpeedFromBitmap(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    HAL_DAWN_IFMON_SPEED_BITMAP_T    speed_bitmap,
    CLX_PORT_SPEED_T                *ptr_speed);

/* FUNCTION NAME:   hal_dawn_ifmon_setSpeedToBitmap
 * PURPOSE:
 *      To set speed to speed bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 *      speed               --  Port speed
 * OUTPUT:
 *         speed_bitmap     --  Speed bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setSpeedToBitmap(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    CLX_PORT_SPEED_T                speed,
    HAL_DAWN_IFMON_SPEED_BITMAP_T    speed_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_setSpeedBitmap
 * PURPOSE:
 *      To set speed bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      speed_bitmap        --  Speed bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setSpeedBitmap(
    const   UI32_T                  unit,
    const   HAL_DAWN_IFMON_TYPE_T    type,
    HAL_DAWN_IFMON_SPEED_BITMAP_T    speed_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_getSpeedBitmap
 * PURPOSE:
 *      To get speed bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      speed_bitmap        --  Speed bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getSpeedBitmap(
    const   UI32_T                  unit,
    const   HAL_DAWN_IFMON_TYPE_T    type,
    HAL_DAWN_IFMON_SPEED_BITMAP_T    speed_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_setLinkBitmap
 * PURPOSE:
 *      To set link port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      link_bitmap         --  Link port bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setLinkBitmap(
    const   UI32_T                  unit,
    const   HAL_DAWN_IFMON_TYPE_T    type,
    HAL_DAWN_IFMON_LANE_BITMAP_T     link_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_getLinkBitmap
 * PURPOSE:
 *      To get link port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      link_bitmap         --  Link port bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getLinkBitmap(
    const   UI32_T                  unit,
    const   HAL_DAWN_IFMON_TYPE_T    type,
    HAL_DAWN_IFMON_LANE_BITMAP_T     link_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_setFaultBitmap
 * PURPOSE:
 *      To set fault port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      fault_bitmap        --  Fault port bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setFaultBitmap(
    const   UI32_T                  unit,
    const   HAL_DAWN_IFMON_TYPE_T    type,
    HAL_DAWN_IFMON_LANE_BITMAP_T     fault_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_getFaultBitmap
 * PURPOSE:
 *      To get fault port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      fault_bitmap        --  Fault port bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getFaultBitmap(
    const   UI32_T                  unit,
    const   HAL_DAWN_IFMON_TYPE_T    type,
    HAL_DAWN_IFMON_LANE_BITMAP_T     fault_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_getFaultTypeBitmap
 * PURPOSE:
 *      To get local/remote fault port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      type                --  Database type
 * OUTPUT:
 *      fault_bitmap        --  Local/Remote fault port bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getFaultTypeBitmap(
    const   UI32_T                        unit,
    const   HAL_DAWN_IFMON_FAULT_TYPE_T    type,
    HAL_DAWN_IFMON_LANE_BITMAP_T           fault_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_getSwStatusBitmap
 * PURPOSE:
 *      To get software status port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      status_bitmap       --  Status port bitmap
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getSwStatusBitmap(
    const   UI32_T                  unit,
    HAL_DAWN_IFMON_LANE_BITMAP_T     status_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_setSwStatusBitmap
 * PURPOSE:
 *      To set software status port bitmap.
 * INPUT:
 *      unit                --  Device unit number
 *      status_bitmap       --  Status port bitmap
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setSwStatusBitmap(
    const   UI32_T                          unit,
    const   HAL_DAWN_IFMON_LANE_BITMAP_T     status_bitmap);

/* FUNCTION NAME:   hal_dawn_ifmon_recordTime
 * PURPOSE:
 *      To record time for time type.
 * INPUT:
 *      unit                --  Device unit number
 *      time_type           --  Time type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_recordTime(
    const   UI32_T                  unit,
    const   HAL_IFMON_TIME_T    time_type);

/* FUNCTION NAME:   hal_dawn_ifmon_getSpeed
 * PURPOSE:
 *      To get port speed.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      ptr_speed           --  Pointer for port speed
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getSpeed(
    const   UI32_T              unit,
    const   UI32_T              port,
    CLX_PORT_SPEED_T            *ptr_speed);

/* FUNCTION NAME:   hal_dawn_ifmon_setSpeed
 * PURPOSE:
 *      To set port speed.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 *      speed               --  Port speed
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setSpeed(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_SPEED_T    speed);

/* FUNCTION NAME:   hal_dawn_ifmon_getLink
 * PURPOSE:
 *      To get port link.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      ptr_link            --  Pointer for port link
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getLink(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_link);

/* FUNCTION NAME:   hal_dawn_ifmon_getFault
 * PURPOSE:
 *      To get port fault.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      ptr_fault           --  Pointer for port fault
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getFault(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_fault);

/* FUNCTION NAME:   hal_dawn_ifmon_register
 * PURPOSE:
 *      To register a callback function to handle a port link change.
 * INPUT:
 *      unit                --  Device unit number
 *      notify_func         --  Callback function
 *      ptr_cookie          --  Cookie data of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_register(
    const   UI32_T                      unit,
    const   CLX_IFMON_NOTIFY_FUNC_T     notify_func,
    void                                *ptr_cookie);

/* FUNCTION NAME:   hal_dawn_ifmon_deregister
 * PURPOSE:
 *      To deregister a callback function from callback functions.
 * INPUT:
 *      unit                --  Device unit number
 *      notify_func         --  Callback function
 *      ptr_cookie          --  Cookie data of callback function
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_deregister(
    const   UI32_T                      unit,
    const   CLX_IFMON_NOTIFY_FUNC_T     notify_func,
    void                                *ptr_cookie);

/* FUNCTION NAME:   hal_dawn_ifmon_getCallbackCnt
 * PURPOSE:
 *      To get callback function count.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      ptr_callback_cnt    --  Pointer for callback function count
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getCallbackCnt(
    const   UI32_T              unit,
    UI32_T                      *ptr_callback_cnt);

/* FUNCTION NAME:   hal_dawn_ifmon_getMode
 * PURPOSE:
 *      This API is used to get interface monitor mode, interface monitor
 *      port bitmap and interface monitor interval.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      ptr_mode            --  Pointer for interface monitor mode
 *      ptr_port_bitmap     --  Pointer for interface monitor port bitmap
 *      ptr_interval_us     --  Pointer for interface monitor polling interval
 *                              in microseconds
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      The polling interval is valid if and only if the interface monitor
 *      polling mode is used.
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getMode(
    const   UI32_T              unit,
    CLX_IFMON_MODE_T            *ptr_mode,
    CLX_PORT_BITMAP_T           *ptr_port_bitmap,
    UI32_T                      *ptr_interval_us);

/* FUNCTION NAME:   hal_dawn_ifmon_setMode
 * PURPOSE:
 *      This API is used to set interface monitor mode, interface monitor
 *      port bitmap and interface monitor interval.
 * INPUT:
 *      unit                --  Device unit number
 *      mode                --  Interface monitor mode
 *      port_bitmap         --  Interface monitor port bitmap
 *      interval_us         --  Interface monitor polling interval in
 *                              microseconds
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      The polling interval is valid if and only if the interface monitor
 *      polling mode is used.
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setMode(
    const   UI32_T              unit,
    const   CLX_IFMON_MODE_T    mode,
    const   CLX_PORT_BITMAP_T   port_bitmap,
    const   UI32_T              interval_us);

/* FUNCTION NAME:   hal_dawn_ifmon_getPortEeeMode
 * PURPOSE:
 *      To get port eee mode.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      ptr_mode            --  Pointer for port eee mode
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_getPortEeeMode(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    CLX_PORT_EEE_MODE_T             *ptr_mode);

/* FUNCTION NAME:   hal_dawn_ifmon_setPortEeeMode
 * PURPOSE:
 *      To set port eee mode.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 *      mode                --  Interface monitor mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_setPortEeeMode(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   CLX_PORT_EEE_MODE_T     mode);

/* FUNCTION NAME:   hal_dawn_ifmon_updateSwState
 * PURPOSE:
 *      To update sw state if port is at mac loopback or at uni-directional link.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      ptr_updated         --  State is updated or not
 * RETURN
 *      CLX_E_OK            --  Operation is successfull.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_updateSwState(
    const UI32_T    unit,
    const UI32_T    port,
    UI32_T          *ptr_updated);

/* FUNCTION NAME:   hal_dawn_ifmon_dumpLinkState
 * PURPOSE:
 *      To dump device/host state.
 * INPUT:
 *      unit                --  Device unit number
 * OUTPUT:
 *      None
 * RETURN
 *      CLX_E_OK            --  Operation is successfull.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_dumpLinkState(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_dawn_ifmon_addMonPort
 * PURPOSE:
 *      To add monitored port.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_addMonPort(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_dawn_ifmon_delMonPort
 * PURPOSE:
 *      To delete monitored port.
 * INPUT:
 *      unit                --  Device unit number
 *      port                --  Physical port ID
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            --  Operation is successful.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_delMonPort(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_dawn_ifmon_dumpDb
 * PURPOSE:
 *      Dump the database per physical port.
 * INPUT:
 *      unit        -- Device unit number
 *      flags       -- Database type
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_dawn_ifmon_dumpDb(
    const UI32_T    unit,
    const UI32_T    flags);

#endif  /* #ifndef HAL_DAWN_IFMON_H */
