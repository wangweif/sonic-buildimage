/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_l3t.h
 * PURPOSE:
 *      It provides l3 tunnel module api.
 * NOTES:
 *
 */

#ifndef CLX_L3T_H
#define CLX_L3T_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_l3.h>
#include <clx_qos.h>
#include <clx_types.h>

#include <clx_port.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define CLX_L3T_FLAGS_WITH_ID   (0x1U << 0)

#define CLX_L3T_FLAGS_FLEX_TUNNEL_UDP_IPV4_CHKSUM0_EN (0x1U << 0)
#define CLX_L3T_FLAGS_FLEX_TUNNEL_UDP_IPV6_CHKSUM0_EN (0x1U << 1)

#define CLX_L3T_FLEX_TUNNEL_HEADER_NUM  (6)
/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */

/* Tunnel MAC Entry */
typedef struct CLX_L3T_MAC_INFO_S
{
    CLX_PORT_T  port;                               /* Key: Physical port or LAG port ID */
    CLX_VLAN_T  cvid;                               /* Key: C-VLAN ID */
    CLX_VLAN_T  cvid_mask;                          /* Mask for the VID */
    CLX_VLAN_T  svid;                               /* Key: S-VLAN ID */
    CLX_VLAN_T  svid_mask;                          /* Mask for the VID */
    CLX_MAC_T   tunnel_mac;                         /* Key: Tunnel MAC address */
    CLX_MAC_T   tunnel_mac_mask;                    /* Mask for the tunnel MAC */

    #define CLX_L3T_MAC_INFO_FLAGS_PORT_VALID        (0x1U << 0)    /* Enable port comparison,
                                                                       set to 1 to compare port_lag_id;
                                                                       set to 0 to mask port_lag_id.
                                                                     */
    #define CLX_L3T_MAC_FLAGS_SVID_VALID             (0x1U << 1)    /* Indicate if svid is valid */
    #define CLX_L3T_MAC_FLAGS_CVID_VALID             (0x1U << 2)    /* Indicate if cvid is valid */
    #define CLX_L3T_MAC_FLAGS_VLAN_TAG_MODE_1Q       (0x1U << 3)    /* Indicate vlan tag mode */
    #define CLX_L3T_MAC_FLAGS_MPLS_EN                (0x1U << 4)    /* Enable MPLS */
    #define CLX_L3T_MAC_FLAGS_TRILL_EN               (0x1U << 5)    /* Enable TRILL */
    #define CLX_L3T_MAC_FLAGS_IP_TUNNEL_EN           (0x1U << 6)    /* Enable IP_TUNNEL */
    #define CLX_L3T_MAC_FLAGS_NSH_EN                 (0x1U << 7)    /* Enable NSH */
    #define CLX_L3T_MAC_FLAGS_TRILL_MC_RPF_CHK_EN    (0x1U << 8)    /* Enable TRILL */
    #define CLX_L3T_MAC_FLAGS_TRILL_MC_ADJ_CHK_EN    (0x1U << 9)    /* Enable TRILL multicast adjacency check */
    #define CLX_L3T_MAC_FLAGS_TRILL_UC_ADJ_CHK_EN    (0x1U << 10)   /* Enable TRILL unicast adjacency check */
    UI32_T      flags;                      /* Refer to CLX_L3T_MAC_FLAGS_XXX */
    UI32_T      l3_intf_id;                 /* L3 interface id */
    UI8_T       mpls_namespace;             /* MPLS namespace */
    UI16_T      l3_mtu_size;                /* L3 mtu size */
}CLX_L3T_MAC_INFO_T;

/* Tunnel ECN Value */
typedef enum
{
    CLX_L3T_ECN_NONE = 0,
    CLX_L3T_ECN_1,
    CLX_L3T_ECN_0,
    CLX_L3T_ECN_CE,
    CLX_L3T_ECN_LAST
}CLX_L3T_ECN_CODE_T;

/* tunnel Initiation Information. */
typedef struct CLX_L3T_INIT_INFO_S
{
    CLX_TUNNEL_KEY_T    key;                    /* L3 tunnel key */
    #define CLX_L3T_INIT_FLAGS_DST_IP_FROM_IPV6             (0x1U << 0)     /* Per tunnel init and only for auto tunnel,
                                                                             * set to 1 if destination IPv4 address
                                                                             * derived from inner destination IPv6
                                                                             * address.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_TTL_FROM_INNER               (0x1U << 1)     /* Per tunnel init.
                                                                             * set to 1 if outer TTL value from inner
                                                                             * header TTL.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_FLOWLABEL_FROM_INNER         (0x1U << 2)     /* Per tunnel init and only for IPv6 tunnel.
                                                                             * set to 1 if outer header flowlabel
                                                                             * value from inner header flowlabel.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_SET_DF                       (0x1U << 3)     /* Per tunnel init and only for IPv4 tunnel.
                                                                             * set to 1 if set DF bit  in outer IPv4
                                                                             * header.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_QOS_FROM_INNER               (0x1U << 4)     /* Per tunnel init.
                                                                             * Set to 1 if outer QoS value from inner
                                                                             * header QoS
                                                                             */
    #define CLX_L3T_INIT_FLAGS_ECN_FROM_INNER               (0x1U << 5)     /* Per tunnel init.
                                                                             * Set to 1 if outer header ECN value
                                                                             * from inner header ECN.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_KEEP_INNER_TAG               (0x1U << 6)     /* Per tunnel init and only for vxlan.
                                                                             * For nvgre, this flag must be 0.
                                                                             * set to 1 if keep inner tag.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_PHB_TO_DSCP_PROFILE_VALID    (0x1U << 7)     /* Per tunnel init.
                                                                             * set to 1 if remark egress DSCP by
                                                                             * traffic class and color.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_PHB_TO_PCP_DEI_PROFILE_VALID (0x1U << 8)     /* Per tunnel init.
                                                                             * set to 1 if remark egress PCP/DEI by
                                                                             * traffic class and color.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_METER_VALID                  (0x1U << 9)     /* Per tunnel init.
                                                                             * set to 1 if meter_id is applied.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_CNT_VALID                    (0x1U << 10)    /* Per tunnel init.
                                                                             * set to 1 if cnt_id is applied.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_DIST_CNT_VALID               (0x1U << 11)    /* Per tunnel init.
                                                                             * set to 1 if dist_cnt_id is applied.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_SAMPLE_TO_MIR                (0x1U << 12)    /* Sample packets to a mirror session
                                                                             * set to 1 if sample packets to a mirror session.
                                                                             * set to 0 if sample packets to CPU.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_SAMPLE_HIGH_LATENCY          (0x1U << 13)    /* Sample high latency packets
                                                                             * set to 1 if enable.
                                                                             */
    #define CLX_L3T_INIT_FLAGS_IOAM_VALID                   (0x1U << 14)    /* set to 1 to enable IOAM */
    #define CLX_L3T_INIT_FLAGS_DTEL                         (0x1U << 15)    /* set to 1 if dtel_profile_id is applied */

    UI32_T    flags;                            /* Refer to CLX_L3T_INIT_FLAGS_XXX. */
    UI32_T    ipv6_flow_label;                  /* If the outer header flow label is not from the
                                                 * inner header, assign the outer header flow label
                                                 * value.
                                                 */
    UI32_T    phb_to_dscp_profile_id;           /* Profile ID is valid if DSCP is remarked by
                                                 * traffic class and color.
                                                 */
    UI32_T    phb_to_pcp_dei_profile_id;        /* Profile ID is valid if PCP/DEI is remarked by
                                                 * traffic class and color.
                                                 */
    UI8_T    dscp;                              /* If the outer header QOS is not from the inner
                                                 * header, assign the outer header DSCP value.
                                                 */
    UI8_T    pcp;                               /* If the outer header QOS is not from the inner
                                                 * header, assign the outer header PCP value.
                                                 */
    UI8_T    dei;                               /* If the outer header QOS is not from the inner
                                                 * header, assign the outer header DEI value.
                                                 */
    CLX_L3T_ECN_CODE_T    ecn;                  /* If the outer header ECN is not from the inner
                                                 * header, assign the outer header ECN value.
                                                 */
    UI8_T    ttl;                               /* If the outer header TTL is not from the inner
                                                 * header, assign the outer header TTL value.
                                                 */
    UI32_T    mir_session_bitmap;               /* Mirror session ID bitmap */
    UI32_T    group_label;                      /* Group label */
    UI32_T    meter_id;                         /* Meter ID */
    UI32_T    cnt_id;                           /* Service counter ID */
    UI32_T    dist_cnt_id;                      /* Distribution counter ID */
    UI16_T    l2_mtu_size;                      /* L2 mtu size */

    UI32_T    sampling_rate;                    /* Sampling rate */
    UI32_T    sample_to_mir_session_id;         /* Sample packets to a mirror session */
    UI32_T    dtel_profile_id;                  /* DTEL profile ID */

    CLX_PORT_VLAN_TAG_T    inner_vlan_tag;      /* Inner header's TPID setting */
} CLX_L3T_INIT_INFO_T;

/* Tunnel termination Information */
typedef struct CLX_L3T_TERM_INFO_S
{
    CLX_TUNNEL_KEY_T    key;                    /* L3 tunnel key */
    #define CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_SIP_CHECK        (0x1U << 0)     /* Per tunnel term.
                                                                             * set to 1 if check auto tunnel inner header
                                                                             * SIP consistent with outer header SIP
                                                                             */
    #define CLX_L3T_TERM_FLAGS_AUTO_TUNNEL_DIP_CHECK        (0x1U << 1)     /* Per tunnel term.
                                                                             * set to 1 if check auto tunnel inner header
                                                                             * DIP consistent with outer  header DIP
                                                                             */
    #define CLX_L3T_TERM_FLAGS_USE_INNER_PHB                (0x1U << 2)     /* Per tunnel term.
                                                                             * set to 1 if user inner header QoS(DSCP/PCP
                                                                             * /DEI) as traffic class and color source
                                                                             */
    #define CLX_L3T_TERM_FLAGS_KEEP_INNER_QOS               (0x1U << 3)     /* Per tunnel term.
                                                                             * set to 1 if don't modify inner header
                                                                             * QoS(DSCP/PCP/DEI) value
                                                                             */
    #define CLX_L3T_TERM_FLAGS_COPY_OUTER_TTL_2_INNER       (0x1U << 4)     /* Per tunnel term.
                                                                             * set to 1 if copy outer TTL  to inner TTL.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_FORWARD_INNER_TAGGED_PACKET  (0x1U << 5)     /* Per tunnel term and only for vxlan.
                                                                             * For nvgre, this flag must be 0.
                                                                             * set to 1 if forward inner tagged packet.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_DSCP_TO_PHB_PROFILE_VALID    (0x1U << 6)     /* Per tunnel term.
                                                                             * set to 1 if use DSCP to initialize
                                                                             * traffic class and color.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_PCP_DEI_TO_PHB_PROFILE_VALID (0x1U << 7)     /* Per tunnel term.
                                                                             * set to 1 if use PCP/DEI to initialize
                                                                             * traffic class and color.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_METER_VALID                  (0x1U << 8)     /* Per tunnel term.
                                                                             * set to 1 if meter_id is applied.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_CNT_VALID                    (0x1U << 9)     /* Per tunnel term.
                                                                             * set to 1 if cnt_id is applied.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_DIST_CNT_VALID               (0x1U << 10)    /* Per tunnel term.
                                                                             * set to 1 if dist_cnt_id is applied.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_ECN_DISABLE                  (0x1U << 11)    /* Per tunnel term entry,
                                                                             * set to 1 if disable ECN.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_ADDR_DONT_LEARN              (0x1U << 12)    /* Per tunnel term and only for vxlan and nvgre.
                                                                             * set to 1 to disable MAC address learning.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_SAMPLE_TO_MIR                (0x1U << 13)    /* Sample packets to a mirror session
                                                                             * set to 1 if sample packets to a mirror session.
                                                                             * set to 0 if sample packets to CPU.
                                                                             */
    #define CLX_L3T_TERM_FLAGS_DTEL                         (0x1U << 14)    /* set to 1 if dtel_profile_id is applied */
    #define CLX_L3T_TERM_FLAGS_L3_MC_ID_VALID               (0x1U << 15)    /* Indicate if l3_mc_id is valid */

    UI32_T    flags;                                /* Refer to CLX_L3T_TERM_FLAGS_XXX. */
    CLX_FWD_ACTION_T    tunnel_term_miss_action;    /* The action when tunnel term table is full or
                                                     * lookup is failed. Only the following actions
                                                     * are supported: normal forwarding, dropped and
                                                     * copied to CPU, drop.
                                                     */
    UI32_T   intf_id;                           /* Tunnel interface ID */
    UI8_T    default_pcp;                       /* The default PCP will be used if the native packet
                                                 * is untagged, or the native VLAN tag is distrusted.
                                                 */
    UI8_T    default_dei;                       /* The default DEI will be used if the native packet
                                                 * is untagged or the native VLAN tag is distrusted.
                                                 */
    CLX_TRUST_MODE_T    trust_mode;             /* Whether to trust 1p or DSCP */
    UI32_T    dscp_to_phb_profile_id;           /* profile ID is valid if  DSCP is used to
                                                 * initialize the traffic class and color
                                                 */
    UI32_T    pcp_dei_to_phb_profile_id;        /* Profile ID is valid if PCP/DEI is used to
                                                 * initialize the traffic class and color.
                                                 */
    UI32_T      mir_session_bitmap;             /* Mirror session ID bitmap */
    UI32_T      group_label;                    /* Group label */
    UI32_T      meter_id;                       /* Meter ID */
    UI32_T      cnt_id;                         /* Service counter ID */
    UI32_T      dist_cnt_id;                    /* Distribution counter ID */
    CLX_PORT_T  port;                           /* Tunnel for mac learning */
    UI32_T      sampling_rate;                  /* Sampling rate */
    UI32_T      sample_to_mir_session_id;       /* Sample packets to a mirror session */
    UI32_T      dtel_profile_id;                /* DTEL profile ID */
    UI16_T      l2_mtu_size;                    /* L2 mtu size */
    UI8_T       mpls_namespace;                 /* MPLS namespace */
    CLX_PORT_VLAN_TAG_T inner_vlan_tag;         /* Inner header's TPID setting */
    UI32_T      l3_mc_id;                       /* L3 multicast id for transit copy */
}CLX_L3T_TERM_INFO_T;

/* NVO3 Route Information*/
typedef struct CLX_L3T_NVO3_ROUTE_INFO_S
{
    CLX_TUNNEL_KEY_T    key;                    /* L3 tunnel key */
    CLX_L3_OUTPUT_TYPE_T    output_type;        /* Refer to CLX_L3_OUTPUT_TYPE_T */
    UI32_T              output_id;              /* Support ADJ and ECMP type */
}CLX_L3T_NVO3_ROUTE_INFO_T;

typedef struct CLX_L3T_FLEX_TUNNEL_PROFILE_UDP_S
{
    UI32_T reserved[CLX_L3T_FLEX_TUNNEL_HEADER_NUM - 1]; /* decrease size of destination port and source port */
    UI16_T destination_port;
    UI16_T source_port;
}CLX_L3T_FLEX_TUNNEL_PROFILE_UDP_T;

typedef struct CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_S
{
    union
    {
        UI32_T user_defined[CLX_L3T_FLEX_TUNNEL_HEADER_NUM];
        CLX_L3T_FLEX_TUNNEL_PROFILE_UDP_T udp_header;
    } header;
    UI8_T  ip_protocol;
    UI8_T  len;                                 /* Flexible encap header length in bytes. 
                                                   The maximum encap len is 24 and only even number of len is allowed.
                                                   example: UDP = 8
                                                 */
}CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T;

typedef enum
{
    CLX_L3T_FLEX_TUNNEL_TYPE_GENEVE,
    CLX_L3T_FLEX_TUNNEL_TYPE_PIM,
    CLX_L3T_FLEX_TUNNEL_TYPE_GTP,
    CLX_L3T_FLEX_TUNNEL_TYPE_USER_DEFINED,
    CLX_L3T_FLEX_TUNNEL_TYPE_LAST
}   CLX_L3T_FLEX_TUNNEL_TYPE_T;

typedef CLX_ERROR_NO_T
(*CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T)(
    const UI32_T                unit,
    const UI32_T                index,
    const CLX_L3T_MAC_INFO_T    *ptr_tunnel_mac_info,
    void                        *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3T_INIT_TRAVERSE_FUNC_T)(
    const UI32_T                unit,
    const CLX_L3T_INIT_INFO_T   *ptr_tunnel_init_info,
    void                        *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3T_TERM_TRAVERSE_FUNC_T)(
    const UI32_T                unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info,
    void                        *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T)(
    const UI32_T                        unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T     *ptr_nvo3_route_info,
    void                                *ptr_cookie);

typedef CLX_ERROR_NO_T
(*CLX_L3T_PORT_TRAVERSE_FUNC_T)(
    const UI32_T                    unit,
    const CLX_TUNNEL_KEY_T          *ptr_key,
    const CLX_PORT_T                port,
    void                            *ptr_cookie);

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_l3t_setTunneling
 * PURPOSE:
 *      Allow or not allow tunnel termination on this port.
 * INPUT:
 *    unit    --  Device unit number
 *    port_id --  The tunneling feature is enabled or disabled according to this physical port ID.
 *    enable  --  TRUE: Allow tunnel termination on this port. <CL>
 *                FALSE: Not allow tunnel termination on this port.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK             --  Operate success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter. "unit" is invalid or port id beyond the range.
 *    CLX_E_NO_MEMORY      --  No available memory.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3t_setTunneling(
    const UI32_T      unit,
    const UI32_T      port_id,
    const BOOL_T      enable);

/* FUNCTION NAME:   clx_l3t_getTunneling
 * PURPOSE:
 *      Get the flag to allow or not allow tunnel termination on this port.
 * INPUT:
 *    unit    -- Device unit number
 *    port_id -- The tunneling feature is enabled or disabled according to this physical port ID.
 * OUTPUT:
 *    ptr_enable  -- TRUE: Allow tunnel termination on this port. <CL>
 *                   FALSE: Not allow tunnel termination on this port.
 * RETURN:
 *    CLX_E_OK             --  Operate success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter. "unit"  is invalid or port id beyond the range.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3t_getTunneling(
    const UI32_T       unit,
    const UI32_T       port_id,
    BOOL_T            *ptr_enable);

/* FUNCTION NAME:   clx_l3t_addTunnelMac
 * PURPOSE:
 *      Add a tunnel MAC entry.
 * INPUT:
 *    unit                -- Device unit number
 *    index               -- The entry index
 *    ptr_tunnel_mac_info -- The entry to be added
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK             --  Operate success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter. "unit"  is invalid or index beyond the range.
 *    CLX_E_TABLE_FULL     --  Hardware table is full, entry can not be added.
 *    CLX_E_NO_MEMORY      --  No available memory.
 * NOTES:
 *   This API is used to add a tunnel MAC entry. User needs to specify the index of
 *   My Tunnel MAC table and the data of entry, including the port LAG ID, S-VLAN ID,
 *   C-VLAN ID, tunnel MAC address and the mask of them. <CL>
 *   My Tunnel MAC table is used to judge whether the incoming packet needs to be
 *   sent via the tunnel termination packet flow.
 *   When packet arrives, if the tunnel is enabled, the ingress port ID,
 *   outer destination MAC address, and outer VLAN ID are used to lookup the MyTunnelMAC table.
 *   If the search result is hit, and outer source IP address and outer destination IP address
 *   are both hit in the tunnel term table, the packet will go through the tunnel termination packet flow.
 *   User can set the mask bit to 0 in order to multiplex one entry by multiple port IDs,
 *   VLAN IDs and MAC addresses.
 */
CLX_ERROR_NO_T
clx_l3t_addTunnelMac(
    const UI32_T              unit,
    const UI32_T              index,
    const CLX_L3T_MAC_INFO_T *ptr_tunnel_mac_info);

/* FUNCTION NAME:   clx_l3t_delTunnelMac
 * PURPOSE:
 *      Delete a tunnel MAC entry.
 * INPUT:
 *    unit          -- Device unit number
 *    index         -- The entry index
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK              --  Operate success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter. "unit"  is invalid or index beyond the range.
 *    CLX_E_ENTRY_NOT_FOUND --  No entry is found with input port_id or lag_id,MAC, VLAN id.
 *    CLX_E_NO_MEMORY       --  No available memory
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3t_delTunnelMac(
    const UI32_T        unit,
    const UI32_T        index);

/* FUNCTION NAME:   clx_l3t_getTunnelMac
 * PURPOSE:
 *      Get a tunnel MAC entry.
 * INPUT:
 *    unit   --  Device unit number
 *    index  --  The entry index
 * OUTPUT:
 *    ptr_tunnel_mac_info --  The tunnel MAC entry to be obtained
 * RETURN:
 *    CLX_E_OK               --  Operate success.
 *    CLX_E_BAD_PARAMETER    --  Bad parameter. "unit"  is invalid or index beyond the range.
 *    CLX_E_ENTRY_NOT_FOUND  --  No entry is found with input port_id or lag_id,
 *                            MAC,VLAN id.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_l3t_getTunnelMac(
    const UI32_T         unit,
    const UI32_T         index,
    CLX_L3T_MAC_INFO_T  *ptr_tunnel_mac_info);

/* FUNCTION NAME:   clx_l3t_traverseTunnelMac
 * PURPOSE:
 *      Traverse all configured tunnel mac entries.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- Callback function provided by user for traversed node operation.
 *      ptr_cookie  -- input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- output parameter of callback function
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_traverseTunnelMac(
    const UI32_T                                unit,
    const CLX_L3T_TUNNEL_MAC_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

/* FUNCTION NAME:   clx_l3t_addInit
 * PURPOSE:
 *    Add a tunnel initiation for IP tunnel. If the tunnel initiation existed, the tunnel
 *    initiation attributes will be updated.
 * INPUT:
 *    unit                 -- Device unit number
 *    ptr_tunnel_init_info -- The tunnel init information to be added
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK               --  Operate success.
 *    CLX_E_BAD_PARAMETER    --  Bad parameter. "unit"  is invalid.
 *    CLX_E_TABLE_FULL       --  Hardware table is full, entry can not be added.
 *    CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *  Source IP, destination IP, tunnel type and tunnel interface ID must be specified in ptr_tunnel_init_info.
 *  For automatic tunnel, DIP is not required. For detailed description of tunnel init information, refer to
 *  CLX_L3T_INIT_INFO_T.<CL>
 *  If the incoming packet needs to go through the tunnel initiation process, user can add the outer IP header
 *  to the original packet by this API. The outer IP header information, such as QOS and TTL, can be obtained
 *  from the inner IP header or by reassigning a new value.<CL>
 *  If the outer SIP and outer DIP are the same, VxLAN tunnel, NVGRE tunnel and other L3 GRE tunnel must share
 *  the same tunnel initiation configuration with IP in IP tunnel and automatic tunnel (6to4 and ISATAP).
 */
CLX_ERROR_NO_T
clx_l3t_addInit(
    const UI32_T                   unit,
    const CLX_L3T_INIT_INFO_T     *ptr_tunnel_init_info);

/* FUNCTION NAME:   clx_l3t_delInit
 * PURPOSE:
 *      Delete a tunnel initiation entry for IP tunnel.
 * INPUT:
 *    unit                 -- Device unit number
 *    ptr_tunnel_init_info -- The tunnel init information will be deleted.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK               --  Operate success.
 *    CLX_E_BAD_PARAMETER    --  Bad parameter.  "unit"  is invalid.
 *    CLX_E_ENTRY_NOT_FOUND  --  No entry is found with input tunnel init information.
 *    CLX_E_NO_MEMORY        --  No available memory
 * NOTES:
 *  Source IP, Destination IP and tunnel type must be specified in ptr_tunnel_init_info. <CL>
 *  But for automatic tunnel, SIP is not required. <CL>
 *  For detailed description of tunnel init information, refer to CLX_L3T_INIT_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3t_delInit(
    const UI32_T              unit,
    const CLX_L3T_INIT_INFO_T *ptr_tunnel_init_info);

/* FUNCTION NAME:   clx_l3t_getInit
 * PURPOSE:
 *      Get a tunnel initiation entry for IP tunnel.
 * INPUT:
 *    unit                 --  Device unit number
 * OUTPUT:
 *    ptr_tunnel_init_info --  The tunnel init information to be obtained.
 * RETURN:
 *    CLX_E_OK              --  Operate success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.  "unit"  is invalid.
 *    CLX_E_ENTRY_NOT_FOUND --  No entry is found with input tunnel init information.
 * NOTES:
 *  Source IP, destination IP and tunnel_type must be specified in ptr_tunnel_init_info. <CL>
 *  But for automatic tunnel, SIP is not required. <CL>
 *  Detail description for tunnel init information refers to CLX_L3T_INIT_INFO_T.
 *
 */
CLX_ERROR_NO_T
clx_l3t_getInit(
    const UI32_T               unit,
    CLX_L3T_INIT_INFO_T       *ptr_tunnel_init_info);

/* FUNCTION NAME:   clx_l3t_traverseInit
 * PURPOSE:
 *      Traverse all configured tunnel init entries.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- Callback function provided by user for traversed node operation.
 *      ptr_cookie  -- input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- output parameter of callback function
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_traverseInit(
    const UI32_T                        unit,
    const CLX_L3T_INIT_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:   clx_l3t_addTerm
 * PURPOSE:
 *     Add a tunnel termination entry for IP tunnel. If the tunnel termination existed,
 *     the tunnel termination attributes will be updated.
 * INPUT:
 *    unit                  --  Device unit number
 *    ptr_tunnel_term_info  --  The tunnel termination information will be added.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK             --  Operate success.
 *    CLX_E_BAD_PARAMETER  --  Bad parameter.  "unit"  is invalid.
 *    CLX_E_TABLE_FULL     --  Hardware table is full, entry can not be added.
 *    CLX_E_NO_MEMORY      --  No available memory
 * NOTES:
 *  This API is used to add a tunnel termination entry. For automatic tunnel, SIP is not required;
 *  Source IP, Destination IP, tunnel type and tunnel interface ID must be specified in ptr_tunnel_term_info. <CL>
 *  For detailed information of the tunnel terms, refer to CLX_L3T_TERM_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3t_addTerm(
    const UI32_T                 unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info );

/* FUNCTION NAME:   clx_l3t_delTerm
 * PURPOSE:
 *      Delete a tunnel termination entry for IP tunnel.
 * INPUT:
 *    unit                 -- Device unit number
 *    ptr_tunnel_term_info -- The tunnel termination information to be deleted; it
 *                            need to specify src_dip, dst_ip and tunnel_type.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK              --  Operate success.
 *    CLX_E_BAD_PARAMETER   --  Bad parameter.  "unit"  is invalid.
 *    CLX_E_ENTRY_NOT_FOUND --  No entry is found with input tunnel termination information.
 *    CLX_E_NO_MEMORY       --  No available memory
 * NOTES:
 *  Source IP, destination IP and tunnel type must be specified in ptr_tunnel_term_info.
 *  But for automatic tunnel, SIP is not required. <CL>
 *  For detailed information of the terms, refer to CLX_L3T_TERM_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3t_delTerm(
    const UI32_T                 unit,
    const CLX_L3T_TERM_INFO_T   *ptr_tunnel_term_info);

/* FUNCTION NAME:   clx_l3t_getTerm
 * PURPOSE:
 *      Get a specified tunnel termination entry for IP tunnel.
 * INPUT:
 *    unit --  Device unit number
 * OUTPUT:
 *    ptr_tunnel_term_info -- The tunnel termination information to be obtained
 * RETURN:
 *    CLX_E_OK --  Operate success.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND -- No entry is found with input tunnel termination information.
 * NOTES:
 *  Source IP, destination IP and tunnel type must be specified in ptr_tunnel_term_info.
 *  But for automatic tunnel, SIP is not required. <CL>
 *  For detailed information of the tunnel terms, refer to CLX_L3T_TERM_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3t_getTerm(
    const UI32_T            unit,
    CLX_L3T_TERM_INFO_T    *ptr_tunnel_term_info );

/* FUNCTION NAME:   clx_l3t_traverseTerm
 * PURPOSE:
 *      Traverse all configured tunnel termination entries.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- Callback function provided by user for traversed node operation.
 *      ptr_cookie  -- input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- output parameter of callback function
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_traverseTerm(
    const UI32_T                        unit,
    const CLX_L3T_TERM_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

/* FUNCTION NAME:   clx_l3t_addNvo3Route
 * PURPOSE:
 *      Add a NVO3 route. If ECMP flag is set, add a NVO3 ECMP route.
 * INPUT:
 *    unit                -- Device unit number
 *    ptr_nvo3_route_info -- The NVO3 route information to be added.
 *                           For ECMP route, the NVO3 ECMP group ID needs to be specified.
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *    CLX_E_TABLE_FULL    --  Hardware table is full, entry can not be added.
 *    CLX_E_NO_MEMORY     --  No available memory
 * NOTES:
 *   When user needs to set an IP packet forward from tunnel, it can be used
 *   to set the IP packet which matches one route entry forwarded from a tunnel.
 */
CLX_ERROR_NO_T
clx_l3t_addNvo3Route(
    const UI32_T                       unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info );

/* FUNCTION NAME:   clx_l3t_delNvo3Route
 * PURPOSE:
 *      Delete NVO3 route for IP tunnel.
 * INPUT:
 *    unit                --  Device unit number
 *    ptr_nvo3_route_info -- The NVO3 route information to be deleted
 * OUTPUT:
 *    None
 * RETURN:
 *    CLX_E_OK            --  Operate success.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *    CLX_E_NO_MEMORY     --  No available memory
 * NOTES:
 *  Destination IP, source IP and tunnel type must be specified in ptr_nvo3_route_info. <CL>
 *  For detailed information of NVO3 route, refer to CLX_L3T_NVO3_ROUTE_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3t_delNvo3Route(
    const UI32_T                       unit,
    const CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info );

/* FUNCTION NAME:   clx_l3t_getNvo3Route
 * PURPOSE:
 *      Get a NVO3 route of IP tunnel.
 * INPUT:
 *    unit --  Device unit number
 *    ptr_nvo3_route_info -- The key of NVO3 route information:  dst_ip
 * OUTPUT:
 *    ptr_nvo3_route_info -- The NVO3 route information to be obtained.
 *                           If it is ECMP route, it will return the ECMP group ID.
 * RETURN:
 *    CLX_E_OK --  Operate success.
 *    CLX_E_BAD_PARAMETER --  Bad parameter.
 *    CLX_E_ENTRY_NOT_FOUND -- No entry is found with input destination IP.
 * NOTES:
 *  Destination IP must be specified in ptr_nvo3_route_info. <CL>
 *  For detailed information of NVO3 route, refer to CLX_L3T_NVO3_ROUTE_INFO_T.
 */
CLX_ERROR_NO_T
clx_l3t_getNvo3Route(
    const UI32_T                 unit,
    CLX_L3T_NVO3_ROUTE_INFO_T    *ptr_nvo3_route_info );

/* FUNCTION NAME:   clx_l3t_traverseNvo3Route
 * PURPOSE:
 *      Traverse all configured nvo3_route entries.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- Callback function provided by user for traversed node operation.
 *      ptr_cookie  -- input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- output parameter of callback function
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_traverseNvo3Route(
    const UI32_T                             unit,
    const CLX_L3T_NVO3_ROUTE_TRAVERSE_FUNC_T callback,
    void                                     *ptr_cookie);

/* FUNCTION NAME:   clx_l3t_setUnusedEcnAction
 * PURPOSE:
 *      Set unused tunnel ECN action.
 * INPUT:
 *      unit       --    Device unit number
 *      action     --    Unused tunnel ECN action
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_setUnusedEcnAction(
    const UI32_T             unit,
    const CLX_FWD_ACTION_T   action);

/* FUNCTION NAME:   clx_l3t_getUnusedEcnAction
 * PURPOSE:
 *      Get unused tunnel ECN action.
 * INPUT:
 *      unit         --  Device unit number
 * OUTPUT:
 *      *ptr_action  --  Unused tunnel ECN action
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_getUnusedEcnAction(
    const UI32_T      unit,
    CLX_FWD_ACTION_T  *ptr_action);

/* FUNCTION NAME: clx_l3t_createPort
 * PURPOSE:
 *      Create tunnel port
 * INPUT:
 *      unit      --  Device unit number
 *      ptr_key   --  Tunnel key
 *      flag      --  Refers to CLX_L3T_FLAGS_XXX
 * OUTPUT:
 *      ptr_port  --  Pointer to the generated tunnel port
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_createPort(
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_key,
    const UI32_T            flag,
    CLX_PORT_T              *ptr_port);

/* FUNCTION NAME: clx_l3t_destroyPort
 * PURPOSE:
 *      Destroy tunnel port
 * INPUT:
 *      unit  --  Device unit number
 *      port  --  Tunnel port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_destroyPort(
    const UI32_T        unit,
    const CLX_PORT_T    port);

/* FUNCTION NAME: clx_l3t_getPort
 * PURPOSE:
 *      Get tunnel port from tunnel key
 * INPUT:
 *      unit     --  Device unit number
 *      ptr_key  --  Tunnel key
 * OUTPUT:
 *      ptr_port --  Tunnel port
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_getPort(
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_key,
    CLX_PORT_T              *ptr_port);

/* FUNCTION NAME: clx_l3t_getKey
 * PURPOSE:
 *      Get tunnel key from tunnel port
 * INPUT:
 *      unit     --  Device unit number
 *      port     --  Tunnel port
 * OUTPUT:
 *      ptr_key  --  Tunnel key
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_getKey(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    CLX_TUNNEL_KEY_T    *ptr_key);

/* FUNCTION NAME:   clx_l3t_traversePort
 * PURPOSE:
 *      Traverse all configured tunnel port entries.
 * INPUT:
 *      unit        -- Device unit number
 *      callback    -- Callback function provided by user for traversed node operation.
 *      ptr_cookie  -- input parameter of callback function
 * OUTPUT:
 *      ptr_cookie  -- output parameter of callback function
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_traversePort(
    const UI32_T                        unit,
    const CLX_L3T_PORT_TRAVERSE_FUNC_T  callback,
    void                                *ptr_cookie);

/* FUNCTION NAME: clx_l3t_addFlexTunnel
 * PURPOSE:
 *      Add flexible tunnel pattern
 * INPUT:
 *      unit    --  Device unit number
 *      index   --  Index of flexible tunnel pattern
 *      type    --  Flexible tunnel type
 *      flags   --  Refers to CLX_L3T_FLAGS_FLEX_TUNNEL_XXX
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_addFlexTunnel(
    const UI32_T unit,
    const UI32_T index,
    const CLX_L3T_FLEX_TUNNEL_TYPE_T type,
    const UI32_T flags);

/* FUNCTION NAME: clx_l3t_delFlexTunnel
 * PURPOSE:
 *      Delete flexible tunnel pattern
 * INPUT:
 *      unit    --  Device unit number
 *      index   --  Index of flexible tunnel pattern
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_delFlexTunnel(
    const UI32_T unit,
    const UI32_T index);

/* FUNCTION NAME: clx_l3t_getFlexTunnel
 * PURPOSE:
 *      Get flexible tunnel type by index
 * INPUT:
 *      unit    --  Device unit number
 *      index   --  Index of flexible tunnel pattern
 * OUTPUT:
 *      ptr_type    --  Flexible tunnel type
 *      ptr_flags   --  Refers to CLX_L3T_FLAGS_FLEX_TUNNEL_XXX
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_getFlexTunnel(
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_TYPE_T *ptr_type,
    UI32_T *ptr_flags);

/* FUNCTION NAME: clx_l3t_setFlexTunnelUdfProfile
 * PURPOSE:
 *      Set flexible tunnel Udf profile
 * INPUT:
 *      unit        --  Device unit number
 *      index       --  Index of flexible tunnel pattern
 *      ptr_profile --  Profile pointer
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      Flex tunnel used profile parameter when type is CLX_L3T_FLEX_TUNNEL_TYPE_USER_DEFINED 
 */
CLX_ERROR_NO_T
clx_l3t_setFlexTunnelUdfProfile(
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

/* FUNCTION NAME: clx_l3t_getFlexTunnelUdfProfile
 * PURPOSE:
 *      Get flexible tunnel Udf profile by index
 * INPUT:
 *      unit        --  Device unit number
 *      index       --  Index of flexible tunnel pattern
 * OUTPUT:
 *      ptr_profile --  Profile pointer
 * RETURN:
 *      CLX_ERROR_NO_T
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
clx_l3t_getFlexTunnelUdfProfile(
    const UI32_T unit,
    const UI32_T index,
    CLX_L3T_FLEX_TUNNEL_UDF_PROFILE_INFO_T *ptr_profile);

#endif
