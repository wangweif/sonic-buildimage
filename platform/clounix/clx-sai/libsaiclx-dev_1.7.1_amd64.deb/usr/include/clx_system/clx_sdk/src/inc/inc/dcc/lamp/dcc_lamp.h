/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  dcc_lamp.h
 * PURPOSE:
 *  1. Provide the interface descriptions of DCC to user.
 *  2. Define the necessary structs.
 *
 * NOTES:
 *
 */

#ifndef CLX_DCC_LAMP_H
#define CLX_DCC_LAMP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <osal/osal.h>
#include <hal/common/hal_drv.h>
#include <hal/common/hal_tbl.h>
#define CMODEL_HOST_IP "127.0.0.1"

/* NAMING CONSTANT DECLARATIONS
 */
#define DCC_CMD_DATA_BUF_LEN 64
#define DCC_RSP_DATA_BUF_LEN 64
#define DCC_CMDS_PER_FRAME   64

#define LAMP_DCC_DEBUG 0
#if defined(LAMP_DCC_DEBUG)
#define LAMP_DCC_PRINTF     osal_printf
#else
#define LAMP_DCC_PRINTF
#endif
#define ZC_PRINTF 0


/* DATA TYPE DECLARATIONS
 */
typedef CLX_ERROR_NO_T (*CLX_SWITCH_EVENT_CB_T)(
    const void *param);

typedef enum
{
    LRN_L2_FIFO_EVENT,
    PACKET_TX_EVT,
    PACKET_RX_EVT,
    TLVS_RSP_EVT,
    PACKET_EVENT_T_LAST
} DCE_TO_HOST_EVENT_T;

typedef struct
{
    UI16_T  pkt_len;
    UI8_T   pkt[1];
} DCE_TO_CPU_PACKET_T;

/*
 *  DCC command response code
 */
typedef enum
{
    DCC_CMD_OP_REG_READ,
    DCC_CMD_OP_REG_WRITE
} DCC_CMD_OP_T;

typedef enum
{
    DCC_OK = 0,
    DCC_TIMEOUT,
    DCC_INVALID_PARAMETER,
    DCC_NULL_CMD_FRAME,
    DCC_NULL_RSP_FRAME,
    DCC_INVALID_RSP
} DCC_RET_T;

typedef enum
{
    DCC_CMD_IO_MODE = 0,
    DCC_CMD_ZC_MODE,
} DCC_CMD_MODE_T;

typedef enum
{
    DCE_IDLE,
    DCE_READY,
    DCE_BUSY
} DCE_RSP_STATUS_T;

/*
 *  DCC control block
 */
typedef struct
{
    UI32_T              mmio_addr;
    UI8_T               asic_id;
    CLX_SEMAPHORE_ID_T  lock;
    UI32_T              timeout;
} DCC_LAMP_CB_T;

/*
 *  DCC IO mode command register structure
 */
typedef struct
{
    UI32_T cmd_addr;
    UI32_T cmd_ctl;
    UI32_T reserved[6];
    UI32_T rsp_stat;
    UI32_T rsp_data;
    UI32_T cmd[DCC_CMD_DATA_BUF_LEN];
    UI32_T seqn;  /* for debug purpose */
} DCC_LAMP_CMD_T;

/*
 *  DCC IO mode response structure
 */

typedef struct
{
    UI16_T rsp_code;
    UI8_T  rsp_len;
    UI8_T  rsp_status;
    UI32_T rsp[DCC_CMD_DATA_BUF_LEN];
    UI32_T seqn;  /* for debug purpose */
} DCC_RSP_T;

typedef struct
{
    UI8_T           cmd_count;
    DCC_LAMP_CMD_T  cmd[DCC_CMDS_PER_FRAME];
} DCC_MMIO_CMD_T;

typedef struct
{
    UI8_T      rsp_count;
    DCC_RSP_T  rsp[DCC_CMDS_PER_FRAME];
} DCC_MMIO_RSP_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* FUNCTION NAME: dcc_lamp_setSvrAddr
 * PURPOSE:
 *  1. Set the cmodel server's name or ip address to connect
 *
 * INPUT:
 *  ptr_svr_addr            -- the host name or ip of cmodel server
 *
 * OUTPUT:
 *  None
 *
 * RETURN:
 *  CLX_E_OK                -- operate successfully
 *  CLX_E_BAD_PARAMETER     -- fail due to bad parameters
 *
 * NOTES:
 *  None
 *
 */
CLX_ERROR_NO_T
dcc_lamp_setSvrAddr(
    const C8_T      *ptr_svr_addr);

/* FUNCTION NAME:   dcc_lamp_rstCmdl
 * PURPOSE:
 *      This function is used to reset the C-Model to default value
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     mode             -- mode of C-Model
 *
 * OUTPUT:
 *     NONE.
 *
 * RETURN:
 *      CLX_E_OK            -- operate successfully
 *      CLX_E_BAD_PARAMETER -- fail due to bad parameters
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_rstCmdl(
    const UI32_T    unit,
    const UI32_T    mode);

/* FUNCTION NAME:   dcc_lamp_runCmdl
 * PURPOSE:
 *      This function is used to run the C-Model to load the packet
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     ptr_pkt_path     -- the packet path at C-Model's view
 *
 * OUTPUT:
 *     NONE.
 *
 * RETURN:
 *      CLX_E_OK            -- operate successfully
 *      CLX_E_BAD_PARAMETER -- fail due to bad parameters
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_runCmdl(
    const UI32_T    unit,
    const C8_T      *ptr_pkt_path);

/* FUNCTION NAME:   dcc_lamp_txPkt
 * PURPOSE:
 *      This function is used to transmit the packet to C-Model
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     plane            -- number of plane id in chip
 *     ptr_pkt          -- pointer to sent packet
 *     pkt_len          -- length of the packet
 *
 * OUTPUT:
 *     NONE.
 *
 * RETURN:
 *      CLX_E_OK            -- operate successfully
 *      CLX_E_BAD_PARAMETER -- fail due to bad parameters
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_txPkt(
    const UI32_T    unit,
    const UI32_T    plane,
    const void      *ptr_pkt,
    const UI32_T    pkt_len);

/* FUNCTION NAME:   dcc_lamp_rxPkt
 * PURPOSE:
 *      This function is used to receive the packet from C-Model
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     ptr_pkt          -- pointer to received packet
 *     ptr_pkt_len      -- length of the packet
 *
 * OUTPUT:
 *     NONE.
 *
 * RETURN:
 *      CLX_E_OK            -- operate successfully
 *      CLX_E_BAD_PARAMETER -- fail due to bad parameters
 *      CLX_E_NO_MEMORY     -- fail due to no memory
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_rxPkt(
    const UI32_T    unit,
    void            *ptr_pkt,
    UI32_T          *ptr_pkt_len);

/* FUNCTION NAME:   dcc_lamp_regRxPktEvent
 * PURPOSE:
 *      This function is used to register the rx packet event handler
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     handler          -- rx packet handler
 *     cookie           -- cookie which will be passed to handler when event occur
 *
 * OUTPUT:
 *     NONE.
 *
 * RETURN:
 *      CLX_E_OK            -- operate successfully
 *      CLX_E_BAD_PARAMETER -- fail due to bad parameters
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_regRxPktEvent(
    const UI32_T                unit,
    const HAL_ISR_HANDLE_FUNC_T handler,
    const UI32_T                cookie);

/* FUNCTION NAME:   dcc_lamp_writeReg
 * PURPOSE:
 *      This function is used to write a REG content
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     addr_offset      -- register address
 *     ptr_data         -- pointer to register content
 *     len              -- register length
 * OUTPUT:
 *     NONE.
 * RETURN:
 *      CLX_E_OK            -- Register write successfully
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_writeReg(
    const UI32_T unit,
    const UI32_T addr_offset,
    const UI32_T *ptr_data,
    const UI32_T len);

/* FUNCTION NAME:   dcc_lamp_readReg
 * PURPOSE:
 *      This function is used to read a REG content
 *
 * INPUT:
 *     unit             -- number of ASIC
 *     addr_offset      -- register address
 *     ptr_data         -- pointer to register content
 *     len              -- register length
 * OUTPUT:
 *     NONE.
 * RETURN:
 *      CLX_E_OK            -- Register read successfully
 *      CLX_E_OTHERS        -- Fail due to internal error
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
dcc_lamp_readReg(
    const UI32_T unit,
    const UI32_T addr_offset,
    UI32_T *ptr_data,
    UI32_T len);

/* FUNCTION NAME:   dcc_lamp_init
 * PURPOSE:
 *      1. Init the necessary resources for dcc lamp.
 *
 * INPUT:
 *      unit       -- number of ASIC
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- SUCCESS.
 *      CLX_E_OTHERS -- FAIL.
 *
 * NOTES:
 *      handle dcc lamp init
 */
CLX_ERROR_NO_T
dcc_lamp_init(
    const UI32_T unit );

/* FUNCTION NAME:   dcc_lamp_deinit
 * PURPOSE:
 *      1. Deinit the necessary resources for dcc lamp.
 *
 * INPUT:
 *      unit       -- number of ASIC
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- SUCCESS.
 *      CLX_E_OTHERS -- FAIL.
 *
 * NOTES:
 *      handle dcc lamp deinit
 */
CLX_ERROR_NO_T
dcc_lamp_deinit(
    const UI32_T unit );

/* FUNCTION NAME:   dcc_lamp_en_txLog
 * PURPOSE:
 *      1. Enable TX log or not
 *
 * INPUT:
 *      en         -- Enable or not
 *                    FALSE: disable
 *                    TRUE: enable
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      NONE.
 *
 * NOTES:
 *      handle dcc lamp init
 */
void
dcc_lamp_en_txLog(
    BOOL_T en);

/* FUNCTION NAME:   dcc_lamp_setSrvPort
 * PURPOSE:
 *      1. Set C-Model service port number
 *
 * INPUT:
 *      port      -- C-Model service port number
 * OUTPUT:
 *      NONE
 * RETURN:
 *      NONE
 *
 * NOTES:
 *      NONE.
 */
void
dcc_lamp_setSrvPort(
    UI32_T  srv_port);

/* FUNCTION NAME:   dcc_lamp_getSrvPort
 * PURPOSE:
 *      1. Get C-Model service port number
 *
 * INPUT:
 *      NONE
 * OUTPUT:
 *      ptr_port  -- Pointer to C-Model service port number
 * RETURN:
 *      NONE
 *
 * NOTES:
 *      NONE.
 */
void
dcc_lamp_getSrvPort(
    UI32_T *ptr_port);

#endif /* CLX_DCC_LAMP_H  */
