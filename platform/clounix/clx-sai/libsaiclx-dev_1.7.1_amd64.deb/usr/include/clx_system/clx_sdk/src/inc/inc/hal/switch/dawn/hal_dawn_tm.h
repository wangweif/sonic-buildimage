/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:   hal_dawn_tm.h
 * PURPOSE:
 *      It provide HAL TM module API.
 * NOTES:
 */

#ifndef HAL_DAWN_TM_H
#define HAL_DAWN_TM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_init.h>
#include <clx_port.h>
#include <clx_swc.h>


/* NAMING CONSTANT DECLARATIONS
 */

/*#define HAL_DAWN_TM_DEBUG_PRINTF_EABLED*/
/*high 4 bit(bit[31:28]) means object type*/
#define HAL_DAWN_TM_HANDLER_TYPE_SHIFT (28)

/*bit[31:28] object type encoding*/
#define HAL_DAWN_TM_HANDLER_LEGACY_QUEUE_TYPE         (0)
#define HAL_DAWN_TM_HANDLER_UNICAST_QUEUE_TYPE        (1)
#define HAL_DAWN_TM_HANDLER_MULTICAST_QUEUE_TYPE      (2)
#define HAL_DAWN_TM_HANDLER_SCHEDULE_NODE_TYPE        (3)

/* queue num*/
#define HAL_DAWN_TM_CPU_QUEUE_NUM        (48)
#define HAL_DAWN_TM_UNICAST_QUEUE_NUM    (8)
#define HAL_DAWN_TM_MULTICAST_QUEUE_NUM  (8)
#define HAL_DAWN_TM_LEGACY_QUEUE_NUM     (8)
#define HAL_DAWN_TM_CPI_QUEUE_NUM        (8)


/*DEQ ranker queue status query time(unit is us)*/
#define HAL_DAWN_TM_DEQ_RANKER_QUERY_TIME (50)

/*DEQ ranker queue status query loops is limited to be 160*/
#define HAL_DAWN_TM_DEQ_RANKER_QUERY_MAX_LOOP (160)


/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_DAWN_TM_HANDLER_SET(handler, type, id)                        \
        ((handler) = ((type) << HAL_DAWN_TM_HANDLER_TYPE_SHIFT) + (id))

#define HAL_DAWN_TM_HANDLER_GET(handler, type, id) do {                   \
        (type) = ((handler) >> HAL_DAWN_TM_HANDLER_TYPE_SHIFT);           \
        (id) = ((handler) & ((1U << HAL_DAWN_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while(0)

/* handler id valid check*/
#define HAL_DAWN_TM_UNICAST_QUEUE_HANDLER_ID_VALID(id)   \
        (((id) >= 0) && ((id) < HAL_DAWN_TM_UNICAST_QUEUE_NUM))

#define HAL_DAWN_TM_MULTICAST_QUEUE_HANDLER_ID_VALID(id) \
        (((id) >= 0) && ((id) < HAL_DAWN_TM_MULTICAST_QUEUE_NUM))

#define HAL_DAWN_TM_CPU_QUEUE_HANDLER_ID_VALID(id)       \
        (((id) >= 0) && ((id) < HAL_DAWN_TM_CPU_QUEUE_NUM))

#define HAL_DAWN_TM_LEGACY_QUEUE_HANDLER_ID_VALID(id)    \
        (((id) >= 0) && ((id) < HAL_DAWN_TM_LEGACY_QUEUE_NUM))

/*schedule node handler id valid check, root node is exculde*/
#define HAL_DAWN_TM_SCHEDULE_NODE_HANDLER_ID_VALID(id)   \
        (((id) >= 0) && ((id) < HAL_DAWN_TM_SCH_NODE_NUM - 1))

/*check macro*/
#define  HAL_DAWN_TM_CHECK_MIN_MAX_RANGE(__value__, __min__, __max__)   \
        (((__value__) > (__max__)) || ((__value__) < (__min__)))


/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_DAWN_TDM_MACRO_PORT_ONE = 0,
    HAL_DAWN_TDM_MACRO_PORT_TWO,
    HAL_DAWN_TDM_MACRO_PORT_FOUR,
    HAL_DAWN_TDM_MACRO_PARTIAL_PORT_ONE,
    HAL_DAWN_TDM_MACRO_PARTIAL_PORT_TWO,
    HAL_DAWN_TDM_MACRO_PARTIAL_PORT_THREE,
    HAL_DAWN_TDM_MACRO_LAST
} HAL_DAWN_TDM_RESULT_T;

/* Port Speed */
/* Please check HW define for all speed setting when add other speed*/
typedef enum
{
    HAL_DAWN_TM_PORT_SPEED_1G       = 1,
    HAL_DAWN_TM_PORT_SPEED_10G      = 2,
    HAL_DAWN_TM_PORT_SPEED_25G      = 3,
    HAL_DAWN_TM_PORT_SPEED_40G      = 4,
    HAL_DAWN_TM_PORT_SPEED_50G      = 5,
    HAL_DAWN_TM_PORT_SPEED_100G     = 6,
    HAL_DAWN_TM_PORT_SPEED_LAST
} HAL_DAWN_TM_PORT_SPEED_T;

/*structure of TM MAC MACRO*/
typedef struct HAL_DAWN_TM_MAC_MACRO_S
{
    UI8_T   ppid_lane0; /*PPID for lane 0, 63 for default*/
    UI8_T   ppid_lane1; /*PPID for lane 1, 63 for default*/
    UI8_T   ppid_lane2; /*PPID for lane 2, 63 for default*/
    UI8_T   ppid_lane3; /*PPID for lane 3, 63 for default*/
    UI32_T  gp;         /*1:gaurantee port; 0: non-gautantee port*/
} HAL_DAWN_TM_MAC_MACRO_T;

/*structure of TM PPID*/
typedef struct HAL_DAWN_TM_PPID_S
{
    UI16_T  mac_macro;  /*TM MAC MACRO ID*/
    UI16_T  lane;       /*0~3*/
} HAL_DAWN_TM_PPID_T;

/*Type of CLX port translate*/
typedef enum
{
    HAL_DAWN_TM_PORT_TRANS_TYPE_MP = 0,
    HAL_DAWN_TM_PORT_TRANS_TYPE_PP,
    HAL_DAWN_TM_PORT_TRANS_TYPE_LAST
} HAL_DAWN_TM_PORT_TRANS_TYPE_T;

/*Type of Object ID for warm-boot*/
typedef enum
{
    HAL_DAWN_TM_WBDB_SCH_TOPOLOGY,
    HAL_DAWN_TM_WBDB_BUF_PROFILE,
    HAL_DAWN_TM_WBDB_LAST
} HAL_DAWN_TM_WBDB_T;

/*control block for misc module*/
/*at common*/

CLX_ERROR_NO_T
hal_dawn_tm_init(
    const   UI32_T          unit);

CLX_ERROR_NO_T
hal_dawn_tm_deinit(
    const   UI32_T          unit);

CLX_ERROR_NO_T
hal_dawn_tm_misc_initCfg(
    const UI32_T unit);

/* FUNCTION NAME:  hal_dawn_tm_resolvePorttoHwInstance
* PURPOSE:
*      To get plane index and sub index of CODA for TM.
* INPUT:
*       unit                    --  Device unit number.
*       port                    --  CLX port.
*       tbl_id                  --  Table ID.
*       port_num_per_hw_count   --  HW count per plane from TM node info for the target register.
*       type                    --  1: translated PPID view; 0: translated MPID view.
* OUTPUT:
*      *ptr_inst_idx            --  Plane index.
*      *ptr_sub_idx             --  HW count index.
* RETURN:
*      no return
* NOTES:
*/
void
hal_dawn_tm_resolvePorttoHwInstance(
    const   UI32_T                          unit,
    const   UI32_T                          port,
    const   UI32_T                          tbl_id,
    const   UI32_T                          port_num_per_hw_count,
    const   HAL_DAWN_TM_PORT_TRANS_TYPE_T    type,
    UI32_T                                  *ptr_inst_idx,
    UI32_T                                  *ptr_sub_idx);

/* FUNCTION NAME:  hal_dawn_tm_resolveHwInstance
* PURPOSE:
*      To get plane index and sub index of CODA for TM.
* INPUT:
*       unit                    --  Device unit number.
*       hw_idx                  --  PPID(0~127) or MPID(0~255).
*       tbl_id                  --  Table ID.
*       port_num_per_hw_count   --  HW count per plane from TM node info for the target register.
* OUTPUT:
*      *ptr_inst_idx            --  Plane index.
*      *ptr_sub_idx             --  HW count index.
* RETURN:
*      no return
* NOTES:
*/
void
hal_dawn_tm_resolveHwInstance(
    const   UI32_T          unit,
    const   UI32_T          hw_idx,
    const   UI32_T          tbl_id,
    const   UI32_T          port_num_per_hw_count,
    UI32_T                  *ptr_inst_idx,
    UI32_T                  *ptr_sub_idx);

CLX_ERROR_NO_T
hal_dawn_tm_getDebRankerQueueStatus(
    const UI32_T                unit,
    const UI32_T                port,
    const BOOL_T                all,
    const CLX_TM_HANDLER_T      handler,
    BOOL_T                      *ptr_empty_status);

CLX_ERROR_NO_T
hal_dawn_tm_setCutThrough(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              enable);

CLX_ERROR_NO_T
hal_dawn_tm_setProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_PROPERTY_T     property,
    const UI32_T                param0,
    const UI32_T                param1);

CLX_ERROR_NO_T
hal_dawn_tm_getProperty(
    const UI32_T                unit,
    const UI32_T                port,
    const CLX_TM_HANDLER_T      handler,
    const CLX_TM_PROPERTY_T     property,
    UI32_T                      *ptr_param0,
    UI32_T                      *ptr_param1);

CLX_ERROR_NO_T
hal_dawn_tm_flushQueue(
    const UI32_T                unit,
    const UI32_T                port,
    const BOOL_T                flush_all,
    const CLX_TM_HANDLER_T      handler,
    const BOOL_T                enable);

CLX_ERROR_NO_T
hal_dawn_tm_setState(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_DIR_T           dir,
    const   UI32_T              all_queue,
    const   CLX_TM_HANDLER_T    handler,
    const   UI32_T              enable);

CLX_ERROR_NO_T
hal_dawn_tm_setEnbState(
    const UI32_T unit,
    const UI32_T port,
    const CLX_DIR_T dir,
    const UI32_T all_queue,
    const CLX_TM_HANDLER_T handler,
    const UI32_T enable);

CLX_ERROR_NO_T
hal_dawn_tm_getEnbState(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_DIR_T           dir,
    const   UI32_T              all_queue,
    const   CLX_TM_HANDLER_T    handler,
    UI32_T                      *ptr_enable);

CLX_ERROR_NO_T
hal_dawn_tm_setSpeed(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_PORT_SPEED_T    speed);

CLX_ERROR_NO_T
hal_dawn_tm_configTdm(
    const   UI32_T              unit);

CLX_ERROR_NO_T
hal_dawn_tm_updatePortTdm(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              lane_cnt);

CLX_ERROR_NO_T
hal_dawn_tm_setSteeringEnable(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   UI32_T              enable);

CLX_ERROR_NO_T
hal_dawn_tm_getSteeringEnable(
    const   UI32_T              unit,
    const   UI32_T              port,
    UI32_T                      *ptr_enable);

CLX_ERROR_NO_T
hal_dawn_tm_setSteering(
    const UI32_T                    unit,
    const CLX_SWC_STEERING_ENTRY_T  *ptr_str_entry);

CLX_ERROR_NO_T
hal_dawn_tm_getSteering(
    const UI32_T                    unit,
    CLX_SWC_STEERING_ENTRY_T        *ptr_str_entry);

CLX_ERROR_NO_T
hal_dawn_tm_setDebPortMapping(
    const UI32_T                    unit,
    const HAL_DAWN_TM_PPID_T         *ptr_ppid,
    const HAL_DAWN_TM_MAC_MACRO_T    *ptr_mac_macro);

CLX_ERROR_NO_T
hal_dawn_tm_initPortMapping(
    const UI32_T                    unit);

CLX_ERROR_NO_T
hal_dawn_tm_setStackingPort(
    const UI32_T    unit,
    const UI32_T    port,
    const UI32_T    enable);

CLX_ERROR_NO_T
hal_dawn_tm_dumpRegPortState(
    const   UI32_T          unit,
    const   UI32_T          port);

CLX_ERROR_NO_T
hal_dawn_tm_setPortDefault(
    const   UI32_T                      unit,
    const   UI32_T                      port);

CLX_ERROR_NO_T
hal_dawn_tm_resetPortDefault(
    const   UI32_T                      unit,
    const   UI32_T                      port);


#endif  /* #ifndef HAL_DAWN_TM_H */

