/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  clx_nv.h
 * PURPOSE:
 *      It provides the declarations of the APIs of nv(network virtualization,including VXLAN/NVGRE) module.
 *
 * NOTES:
 *
 */

#ifndef CLX_NV_H
#define CLX_NV_H



/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_vlan.h>
#include <clx_port.h>
#include <clx_l2.h>
#include <clx_l3t.h>


/* MACRO FUNCTION DECLARATIONS
 */


/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    CLX_NV_TYPE_VXLAN=0,    /* 0: VXLAN*/
    CLX_NV_TYPE_NVGRE,      /* 1: NVGRE*/
    CLX_NV_TYPE_LAST        /* Any valid value should be set before the last value. */
}CLX_NV_TYPE_T;

typedef enum
{
    CLX_NV_P2P_PRUNE_BY_FDID_VTEP= 0,       /* 0: Pruned by VNI and VTEP*/
    CLX_NV_P2P_PRUNE_BY_FDID,               /* 1: Pruned by VNI  */
    CLX_NV_P2P_PRUNE_LAST                   /* Any valid value should be set before the last value. */
} CLX_NV_P2P_PRUNE_T;

typedef enum
{
    CLX_NV_L3PAYLOAD = 0,  /* 0: Using L3 payload. */
    CLX_NV_L2PAYLOAD,      /* 1: Using L2 payload. */
    CLX_NV_PAYLOAD_TYPE_LAST    /* Any valid value should be set before the last value. */
} CLX_NV_PAYLOAD_TYPE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   clx_nv_setP2pPruneControl
 * PURPOSE:
 *      This API is used to set the prune control for multicast-P2P mode. Prune control
 *      can be as follows:<CL>
 *      (1) Pruned by FDID<CL>
 *      (2) Pruned by FDID+VTEP
 * INPUT:
 *        unit      -- Device unit number
 *        p2p_prune -- CLX_NV_P2P_PRUNE_BY_FDID_VTEP: Pruned by VNI and VTEP <CL>
 *                     CLX_NV_P2P_PRUNE_BY_FDID: Pruned by VNI
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 * NOTES:
 *        None
 *
 */

CLX_ERROR_NO_T
clx_nv_setP2pPruneControl(
    const UI32_T                 unit,
    const CLX_NV_P2P_PRUNE_T     p2p_prune);

/* FUNCTION NAME:   clx_nv_getP2pPruneControl
 * PURPOSE:
 *      This API is used to get the prune control for multicast-P2P mode. Prune control
 *      can be as follows:<CL>
 *      (1) Pruned by FDID<CL>
 *      (2) Pruned by FDID+VTEP
 * INPUT:
 *        unit           -- Device unit number
 * OUTPUT:
 *        ptr_p2p_prune  -- CLX_NV_P2P_PRUNE_BY_FDID_VTEP: Pruned by VNI and VTEP <CL>
 *                          CLX_NV_P2P_PRUNE_BY_FDID: Pruned by VNI
 *
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 * NOTES:
 *        None
 *
 */

CLX_ERROR_NO_T
clx_nv_getP2pPruneControl(
    const UI32_T            unit,
    CLX_NV_P2P_PRUNE_T      *ptr_p2p_prune);


/* FUNCTION NAME:   clx_nv_setPayloadType
 * PURPOSE:
 *      This API is used to set the payload type.<CL>
 *      (1) L2 payload<CL>
 *      (2) L3 payload
 * INPUT:
 *        unit               --    Device unit number
 *        bdid               --    A bridge domain
 *        payload_type       --    CLX_NV_L2PAYLOAD: L2 payload <CL>
 *                                 CLX_NV_L3PAYLOAD: L3 payload
 *
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND  --  Entry Not Found.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_setPayloadType(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const CLX_NV_PAYLOAD_TYPE_T     payload_type);

/* FUNCTION NAME:   clx_nv_getPayloadType
 * PURPOSE:
 *      This API is used to get the payload type.<CL>
 *      (1) L2 payload<CL>
 *      (2) L3 payload
 * INPUT:
 *        unit               --    Device unit number
 *        bdid               --    A bridge domain ID
 * OUTPUT:
 *        ptr_payload        --    CLX_NV_L2PAYLOAD: L2 payload <CL>
 *                                 CLX_NV_L3PAYLOAD: L3 payload
 * RETURN:
 *        CLX_E_OK --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND  --  Entry Not Found.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_getPayloadType(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_NV_PAYLOAD_TYPE_T           *ptr_payload);


/* FUNCTION NAME:   clx_nv_setSplitHorizonCheck
 * PURPOSE:
 *      This API is used to enable or disable the split horizon check function.
 * INPUT:
 *        unit              --    Device unit number
 *        ptr_tunnel_key    --    NV tunnel key
 *        enable            --    TRUE: Enable <CL>
 *                                FALSE: Disable
 * OUTPUT:
 *        None
 *
 * RETURN:
 *        CLX_E_OK --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_setSplitHorizonCheck(
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_tunnel_key,
    const BOOL_T            enable);


/* FUNCTION NAME:   clx_nv_getSplitHorizonCheck
 * PURPOSE:
 *      This API is used to get the split horizon check function status (enabled or disabled).
 * INPUT:
 *        unit             --    Device unit number
 *        ptr_tunnel_key   --    NV tunnel key
 *
 * OUTPUT:
 *        ptr_enable       --    TRUE: Enabled <CL>
 *                               FALSE: Disabled
 * RETURN:
 *        CLX_E_OK --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *
 * NOTES:
 *        None
 *
 */

CLX_ERROR_NO_T
clx_nv_getSplitHorizonCheck(
    const UI32_T            unit,
    const CLX_TUNNEL_KEY_T  *ptr_tunnel_key,
    BOOL_T                  *ptr_enable);

/* FUNCTION NAME:   clx_nv_bindMcastTunnel
 * PURPOSE:
 *      This API is used to bind the multicast tunnel and the NVO3 group with the bridge domain.
 * INPUT:
 *        unit               --    Device unit number
 *        bdid               --    A bridge domain ID
 *        ptr_local_vtep_ip  --    A local VTEP IP address
 *        ptr_mcast_group_ip --    A multicast group IP address
 *        nv_type            --    Network Virtualization Type: <CL>
 *                                 (1)CLX_NV_TYPE_VXLAN: VXLAN type <CL>
 *                                 (2)CLX_NV_TYPE_NVGRE: NVGRE type
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK            --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *        CLX_E_ENTRY_EXISTS --  The bridge domain has already bound with a tunnel.
 *
 *
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_nv_bindMcastTunnel(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    const CLX_IP_ADDR_T             *ptr_local_vtep_ip,
    const CLX_IP_ADDR_T             *ptr_mcast_group_ip,
    const CLX_NV_TYPE_T             nv_type);

/* FUNCTION NAME:   clx_nv_unbindMcastTunnel
 * PURPOSE:
 *      This API is used to unbind the multicast tunnel and the NVO3 group with the bridge domain.
 * INPUT:
 *        unit               --    Device unit number
 *        bdid               --    A bridge domain ID
 *
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK            --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *
 *
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_nv_unbindMcastTunnel(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid);

/* FUNCTION NAME:   clx_nv_getMcastTunnelBinding
 * PURPOSE:
 *      This API is used to get the binding multicast tunnel information of a given bridge domain.
 * INPUT:
 *        unit                  --    Device unit number
 *        bdid                  --    A bridge domain ID
 *
 * OUTPUT:
 *        ptr_local_vtep_ip     --    A local VTEP IP address
 *        ptr_mcast_group_ip    --    A multicast group IP address
 *        ptr_nv_type           --    Network Virtualization Type: <CL>
 *                                    (1)CLX_NV_TYPE_VXLAN: VXLAN type <CL>
 *                                    (2)CLX_NV_TYPE_NVGRE: NVGRE type
 * RETURN:
 *        CLX_E_OK              -- Operation is successful.
 *        CLX_E_BAD_PARAMETER   -- Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND -- Entry not found
 *
 * NOTES:
 *        None
 */
CLX_ERROR_NO_T
clx_nv_getMcastTunnelBinding(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    CLX_IP_ADDR_T                   *ptr_local_vtep_ip,
    CLX_IP_ADDR_T                   *ptr_mcast_group_ip,
    CLX_NV_TYPE_T                   *ptr_nv_type);


/* FUNCTION NAME:   clx_nv_addNvo3Group
 * PURPOSE:
 *      This API is used to add an NVO3 group.
 * INPUT:
 *        unit               --    Device unit number
 *        ptr_group_ip       --    A multicast group IP address
 *
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK               --  Operation is successful.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND  --  Entry not found
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_addNvo3Group(
    const UI32_T                 unit,
    const CLX_IP_ADDR_T          *ptr_group_ip);

/* FUNCTION NAME:   clx_nv_delNvo3Group
 * PURPOSE:
 *      This API is used to delete an NVO3 group.
 * INPUT:
 *        unit               --    Device unit number
 *        ptr_group_ip       --    A multicast group IP address
 *
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK               --  Operation is successful.
 *        CLX_E_BAD_PARAMETER    --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND  --  Entry not found
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_delNvo3Group(
    const UI32_T               unit,
    const CLX_IP_ADDR_T        *ptr_group_ip);

/* FUNCTION NAME:   clx_nv_addNvo3GroupEgrPort
 * PURPOSE:
 *      This API is used to add the port and the outgoing interface of an NVO3 group.
 * INPUT:
 *        unit                  --    Device unit number
 *        ptr_group_ip          --    A multicast group IP address
 *        port_id               --    The outgoing port ID of the multicast group
 *        nvo3_adj_id           --    The outgoing NVO3 adjacency ID for the outgoing port of the multicast group
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *        CLX_E_TABLE_FULL      --  The table is full.
 *
 * NOTES:
 *    Application SW programs the NVO3 group related member ports based on the
 *    multicast routing information of transport layer.
 */

CLX_ERROR_NO_T
clx_nv_addNvo3GroupEgrPort(
    const UI32_T              unit,
    const CLX_IP_ADDR_T       *ptr_group_ip,
    const UI32_T              port_id,
    const UI32_T              nvo3_adj_id);

/* FUNCTION NAME:   clx_nv_delNvo3GroupEgrPort
 * PURPOSE:
 *      This API is used to delete a port of an NVO3 group.
 * INPUT:
 *        unit                  --    Device unit number
 *        ptr_group_ip          --    A multicast group IP address
 *        port_id               --    The outgoing port ID of the multicast group
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_delNvo3GroupEgrPort(
    const UI32_T              unit,
    const CLX_IP_ADDR_T    *ptr_group_ip,
    const UI32_T              port_id);

/* FUNCTION NAME:   clx_nv_getNvo3GroupEgrPortList
 * PURPOSE:
 *      This API is used to get the port list of an NVO3 group.
 * INPUT:
 *        unit                  --    Device unit number
 *        ptr_group_ip          --    A multicast group IP address
 * OUTPUT:
 *        ptr_port_list         --    The outgoing port list of the multicast group
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *
 * NOTES:
 *        None
 *
 */

CLX_ERROR_NO_T
clx_nv_getNvo3GroupEgrPortList(
    const UI32_T                unit,
    const CLX_IP_ADDR_T         *ptr_group_ip,
    CLX_PORT_BITMAP_T           *ptr_port_list);

/* FUNCTION NAME:   clx_nv_getNvo3GroupEgrInfo
 * PURPOSE:
 *      This API is used to get the NVO3 adjacency ID of a port of a NVO3 group.
 * INPUT:
 *        unit                  --    Device unit number
 *        ptr_group_ip          --    A multicast group IP address
 *        port_id               --    A outgoing port ID
 * OUTPUT:
 *        ptr_nvo3_adj_id       --    NVO3 adjacency ID
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *
 * NOTES:
 *
 */
CLX_ERROR_NO_T
clx_nv_getNvo3GroupEgrInfo(
    const UI32_T                unit,
    const CLX_IP_ADDR_T         *ptr_group_ip,
    const UI32_T                port_id,
    UI32_T                      *ptr_nvo3_adj_id);

/* FUNCTION NAME:   clx_nv_setP2pUcastTunnelAdj
 * PURPOSE:
 *      This API is used to set the NVO3 adjacency ID for the unicast tunnel used in
 *      VXLAN or NVGRE multicast-P2P mode.
 * INPUT:
 *        unit               --    Device unit number
 *        ptr_src_vtep_addr  --    The source VTEP IP address of the unicast tunnel
 *        ptr_dst_vtep_addr  --    The destination VTEP IP address of the unicast tunnel
 *        nvo3_adj_id        --    The NVO3 adjacency ID for the unicast tunnel
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_setP2pUcastTunnelAdj(
    const UI32_T                 unit,
    const CLX_IP_ADDR_T          *ptr_src_vtep_addr,
    const CLX_IP_ADDR_T          *ptr_dst_vtep_addr,
    const UI32_T                 nvo3_adj_id);

/* FUNCTION NAME:   clx_nv_delP2pUcastTunnelAdj
 * PURPOSE:
 *      This API is used to delete the NVO3 adjacency ID used for the unicast tunnel
 *      used in VXLAN or NVGRE multicast-P2P mode.
 * INPUT:
 *        unit               --    Device unit number
 *        ptr_src_vtep_addr  --    The source VTEP IP address of the unicast tunnel
 *        ptr_dst_vtep_addr  --    The destination VTEP IP address of the unicast tunnel
 *
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_delP2pUcastTunnelAdj(
    const UI32_T                unit,
    const CLX_IP_ADDR_T         *ptr_src_vtep_addr,
    const CLX_IP_ADDR_T         *ptr_dst_vtep_addr);

/* FUNCTION NAME:   clx_nv_getP2pUcastTunnelAdj
 * PURPOSE:
 *      This API is used to get the NVO3 adjacency ID for the unicast tunnel used in
 *      VXLAN or NVGRE multicast-P2P mode.
 * INPUT:
 *        unit                 --    Device unit number
 *        ptr_src_vtep_addr    --    The source VTEP IP address of the unicast tunnel
 *        ptr_dst_vtep_addr    --    The destination VTEP IP address of the unicast tunnel
 * OUTPUT:
 *        ptr_nvo3_adj_id      --    NVO3 adjacency ID
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_getP2pUcastTunnelAdj(
    const UI32_T            unit,
    const CLX_IP_ADDR_T     *ptr_src_vtep_addr,
    const CLX_IP_ADDR_T     *ptr_dst_vtep_addr,
    UI32_T                  *ptr_nvo3_adj_id);

/* FUNCTION NAME:   clx_nv_setP2pSplitHorizonCheck
 * PURPOSE:
 *      This API is used to set the split-horizon-check flag of a given bridge domain
 *      in VXLAN or NVGRE multicast-P2P mode.
 * INPUT:
 *        unit              --    Device unit number
 *        bdid              --    A bridge domain ID
 *        enable            --    TRUE: Enable <CL>
 *                                FALSE: Disable
 * OUTPUT:
 *        None
 *
 * RETURN:
 *        CLX_E_OK --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_setP2pSplitHorizonCheck(
    const UI32_T                       unit,
    const CLX_BRIDGE_DOMAIN_T           bdid,
    const BOOL_T                       enable);

/* FUNCTION NAME:   clx_nv_getP2pSplitHorizonCheck
 * PURPOSE:
 *      This API is used to get the split-horizon-check flag of a given bridge domain
 *      in VXLAN or NVGRE multicast-P2P mode.
 * INPUT:
 *        unit            --    Device unit number
 *        bdid            --    A bridge domain ID
 * OUTPUT:
 *        ptr_enable      --    TRUE: Enable <CL>
 *                              FALSE: Disable
 * RETURN:
 *        CLX_E_OK --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *
 * NOTES:
 *        None
 *
 */

CLX_ERROR_NO_T
clx_nv_getP2pSplitHorizonCheck(
    const UI32_T                       unit,
    const CLX_BRIDGE_DOMAIN_T           bdid,
    BOOL_T                             *ptr_enable);

/* FUNCTION NAME:   clx_nv_addVxlanVni
 * PURPOSE:
 *      This API is used to add the specified VNI to the bridge domain.
 * INPUT:
 *        unit              --    Device unit number
 *        vni               --    A VNI value(24 bits)
 *        bdid              --    A bridge domain ID
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK            --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *        CLX_E_TABLE_FULL    --  The table is full.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_addVxlanVni(
    const UI32_T                    unit,
    const UI32_T                    vni,
    const CLX_BRIDGE_DOMAIN_T       bdid);

/* FUNCTION NAME:   clx_nv_delVxlanVni
 * PURPOSE:
 *      This API is used to delete the specified VNI from the bridge domain.
 * INPUT:
 *        unit              --    Device unit number
 *        vni               --    A VNI value(24 bits)
 *        bdid              --    A  bridge domain ID
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK            --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND -- Entry not found
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_delVxlanVni(
    const UI32_T                    unit,
    const UI32_T                    vni,
    const  CLX_BRIDGE_DOMAIN_T      bdid);

/* FUNCTION NAME:   clx_nv_getVxlanVni
 * PURPOSE:
 *      This API is used to get the VNI from the specified bridge domain.
 * INPUT:
 *        unit              --    Device unit number
 *        bdid              --    A bridge domain ID
 * OUTPUT:
 *        ptr_vni           --    The VNI value(24 bits)
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *        CLX_E_OTHERS          --  Operation failed or wrong tag type
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_getVxlanVni(
    const UI32_T                   unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    UI32_T                          *ptr_vni);

/* FUNCTION NAME:   clx_nv_addNvgreVsid
 * PURPOSE:
 *      This API is used to add the specified VSID to the bridge domain.
 * INPUT:
 *        unit              --    Device unit number
 *        vsid              --    A VSID value(24 bits)
 *        bdid              --    A  bridge domain ID
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK            --  Operation is successful.
 *        CLX_E_BAD_PARAMETER --  Bad parameter
 *        CLX_E_TABLE_FULL    --  The table is full.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_addNvgreVsid(
    const UI32_T                    unit,
    const UI32_T                    vsid,
    const CLX_BRIDGE_DOMAIN_T       bdid);

/* FUNCTION NAME:   clx_nv_delNvgreVsid
 * PURPOSE:
 *      This API is used to delete the specified VSID from the bridge domain.
 * INPUT:
 *        unit              --    Device unit number
 *        vsid              --    A VSID value(24 bits)
 *        bdid             --    A bridge domain ID
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Not Found.
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_delNvgreVsid(
    const UI32_T                    unit,
    const UI32_T                    vsid,
    const CLX_BRIDGE_DOMAIN_T       bdid);

/* FUNCTION NAME:   clx_nv_getNvgreVsid
 * PURPOSE:
 *      This API is used to get the VSID from the specified the bridge domain.
 * INPUT:
 *        unit              --   Device unit number
 *        bdid              --   A bridge domain ID
 * OUTPUT:
 *        ptr_vsid          --   The VSID value(24 bits)
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *        CLX_E_OTHERS          --  Operation failed or wrong tag type
 * NOTES:
 *        None
 *
 */
CLX_ERROR_NO_T
clx_nv_getNvgreVsid(
    const UI32_T                    unit,
    const CLX_BRIDGE_DOMAIN_T       bdid,
    UI32_T                          *ptr_vsid);

/* FUNCTION NAME:   clx_nv_addSegService
 * PURPOSE:
 *      This API is used to add or set a tunnel to a specified segment and related service.
 * INPUT:
 *        unit              --   Device unit number
 *        seg               --   Segment value(24 bits)
 *        ptr_key           --   Tunnel key
 *        ptr_seg_srv       --   (seg, tunnel) service
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_EXISTS    --  Entry exists
 *        CLX_E_TABLE_FULL      --  The table is full.
 *        CLX_E_NOT_SUPPORT     --  Not Supported
 * NOTES:
 *        The ptr_seg_srv->bdid value modification is not allowed.
 *
 */
CLX_ERROR_NO_T
clx_nv_addSegService(
    const UI32_T                unit,
    const UI32_T                seg,
    const CLX_TUNNEL_KEY_T      *ptr_key,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   clx_nv_delSegService
 * PURPOSE:
 *      This API is used to delete a tunnel from a specified segment.
 * INPUT:
 *        unit              --   Device unit number
 *        seg               --   Segment value(24 bits)
 *        ptr_key           --   Tunnel key
 * OUTPUT:
 *        None
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *        CLX_E_NOT_SUPPORT     --  Not Supported
 * NOTES:
 *
 *
 */
CLX_ERROR_NO_T
clx_nv_delSegService(
    const UI32_T            unit,
    const UI32_T            seg,
    const CLX_TUNNEL_KEY_T  *ptr_key);

/* FUNCTION NAME:   clx_nv_getSegService
 * PURPOSE:
 *        This API is used to get the service of a (segment, tunnel) pair.
 * INPUT:
 *        unit              --   Device unit number
 *        seg               --   Segment value(24 bits)
 *        ptr_key           --   Tunnel key
 * OUTPUT:
 *        ptr_seg_srv       --   (seg, tunnel) service
 * RETURN:
 *        CLX_E_OK              --  Operation is successful.
 *        CLX_E_BAD_PARAMETER   --  Bad parameter
 *        CLX_E_ENTRY_NOT_FOUND --  Entry not found
 *        CLX_E_NOT_SUPPORT     --  Not Supported
 * NOTES:
 *
 *
 */
CLX_ERROR_NO_T
clx_nv_getSegService(
    const UI32_T                unit,
    const UI32_T                seg,
    const CLX_TUNNEL_KEY_T      *ptr_key,
          CLX_PORT_SEG_SRV_T    *ptr_seg_srv);


#endif /*#ifndef CLX_NV_H */
