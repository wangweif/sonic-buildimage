/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_sflow.h
 * PURPOSE:
 *  Define the declartion for sFlow module.
 *
 * NOTES:
 *
 */

#ifndef HAL_SFLOW_H
#define HAL_SFLOW_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_SFLOW_INVALID_ID    (0xFFFFFFFF)

/* DATA TYPE DECLARATIONS
 */
typedef enum HAL_SFLOW_SRC_TYPE_E
{
    /* Caller use L2 local intf to bind sFlow profile. */
    HAL_SFLOW_SRC_TYPE_L2_LCL_INFT_IGR = 0,
    HAL_SFLOW_SRC_TYPE_L2_LCL_INFT_EGR,
    /* Caller use service L2/MPLS intf to bind sFlow profile. */
    HAL_SFLOW_SRC_TYPE_SRV_INFT_IGR,
    HAL_SFLOW_SRC_TYPE_SRV_INFT_EGR,
    /* Caller bind sFlow profile to physical port. */
    HAL_SFLOW_SRC_TYPE_PHY_PORT_IGR,
    HAL_SFLOW_SRC_TYPE_PHY_PORT_EGR,
    HAL_SFLOW_SRC_TYPE_ACL_IGR,
    HAL_SFLOW_SRC_TYPE_ACL_EGR,
    HAL_SFLOW_SRC_TYPE_FLOW_IGR,
    HAL_SFLOW_SRC_TYPE_LAST
} HAL_SFLOW_SRC_TYPE_T;

typedef enum HAL_SFLOW_DST_TYPE_E
{
    HAL_SFLOW_DST_TYPE_CPU = 0, /* sFlow to CPU */
    HAL_SFLOW_DST_TYPE_MIR_SESSION, /* sFlow to mirror session */
    HAL_SFLOW_DST_TYPE_LAST
} HAL_SFLOW_DST_TYPE_T;

/* GLOBAL VARIABLE DECLARATIONS
 */

/* LOCAL SUBPROGRAM DECLARATIONS
 */

CLX_ERROR_NO_T
hal_sflow_init (
    const UI32_T unit);

CLX_ERROR_NO_T
hal_sflow_deinit (
    const UI32_T unit);

CLX_ERROR_NO_T
hal_sflow_addProfile(
    const UI32_T               unit,
    const HAL_SFLOW_SRC_TYPE_T src_type,
    const UI32_T               sampling_rate,
    const BOOL_T               sample_high_latency,
    const HAL_SFLOW_DST_TYPE_T dst_type,
    const UI32_T               mir_session_id,
    const UI32_T               old_profile_id,
    UI32_T                     *ptr_profile_id);

CLX_ERROR_NO_T
hal_sflow_freeProfile(
    const UI32_T unit,
    const HAL_SFLOW_SRC_TYPE_T src_type,
    const UI32_T               profile_id);

CLX_ERROR_NO_T
hal_sflow_getProfile(
    const UI32_T               unit,
    const HAL_SFLOW_SRC_TYPE_T src_type,
    const UI32_T               profile_id,
    BOOL_T                     *ptr_sample_high_latency,
    HAL_SFLOW_DST_TYPE_T       *ptr_dst_type,
    UI32_T                     *ptr_mir_session_id,
    UI32_T                     *ptr_sampling_rate);

CLX_ERROR_NO_T
hal_sflow_setSampleHighLatencyThreshold(
    const UI32_T                unit,
    const UI32_T                threshold);

CLX_ERROR_NO_T
hal_sflow_getSampleHighLatencyThreshold(
    const UI32_T                unit,
    UI32_T                      *ptr_threshold);

CLX_ERROR_NO_T
hal_sflow_setDtelProfile(
    const UI32_T    unit,
    const CLX_DIR_T dir,
    const UI32_T    profile_id,
    const UI32_T    cp_to_cpu_bidx,
    const UI32_T    sampling_rate,
    const UI32_T    ioam_en,
    const UI32_T    ioam_flw_lbl_val);

CLX_ERROR_NO_T
hal_sflow_getDtelProfile(
    const UI32_T    unit,
    const CLX_DIR_T dir,
    const UI32_T    profile_id,
    UI32_T          *ptr_cp_to_cpu_bidx,
    UI32_T          *ptr_sampling_rate,
    UI32_T          *ptr_ioam_en,
    UI32_T          *ptr_ioam_flw_lbl_val);

CLX_ERROR_NO_T
hal_sflow_isDtelProfileValid(
    const UI32_T    unit,
    const UI32_T    profile_id);

CLX_ERROR_NO_T
hal_sflow_setDtelProfileNumber(
    const UI32_T    unit,
    const UI32_T    number);

CLX_ERROR_NO_T
hal_sflow_getDtelProfileNumber(
    const UI32_T    unit,
    UI32_T          *ptr_number);

CLX_ERROR_NO_T
hal_sflow_checkDtelAndSflowParam(
    const UI32_T    unit,
    const UI32_T    sampling_rate,
    const UI32_T    dtel_flags_rst,
    const UI32_T    dtel_profile_id,
    const CLX_DIR_T data_source_dir);

#endif /* End of HAL_SFLOW_H */

