/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  dcc_io.h
 * PURPOSE:
 *  1. Provide the IO channel access interface to chip Device Control Command(DCC).
 *  2. Define DCC IO channel related structures.
 *
 * NOTES:
 *
 */

#ifndef DCC_IO_H
#define DCC_IO_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <osal/osal.h>
#include <clx_init.h>
#include <dcc/dcc.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DCC constant definition */
#define DCC_MAX_IO_CMD_SIZE                 (64 * 4) /* 64 words */
#define DCC_IO_HASH_CMD_CFG_OFFSET          (0x0)
#define DCC_IO_HASH_CMD_BNK_BITMAP_OFFSET   (0x4)
#define DCC_IO_HASH_CMD_DATA_OFFSET         (0x8)
#define DCC_IO_HASH_RSLT_STAT_OFFSET        (0x0)
#define DCC_IO_HASH_RSLT_INDEX_OFFSET       (0x4)
#define DCC_IO_HASH_RSLT_DATA_OFFSET        (0xC)
#define DCC_IO_HASH_RSLT_HEADER_LEN         (DCC_IO_HASH_RSLT_DATA_OFFSET - DCC_IO_HASH_RSLT_STAT_OFFSET)
/* unit of time: us, all times need for further check */
#define DCC_IO_CMD_SUSPEND_TIME             (1)
#define DCC_IO_CMD_BUSY_POLL_CNT            (10)


/* For IO channel, we do not need to define BASE_DCE_MMIO_BUF registers.
We will copy response from this BASE_DCE_MMIO_BUF into the *ptr_rsp of DCC_CMD_T directly. */


/* MACRO FUNCTION DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/* DCC IO channel status */
enum
{
    IO_RSP_STAT_IDLE = 0, /* 0x0 */
    IO_RSP_STAT_BSY,      /* 0x1 */
    IO_RSP_STAT_RDY,      /* 0x2 */
    IO_RSP_STAT_ABT,      /* 0x3 */
    IO_RSP_STAT_NAK,      /* 0x4 */
    IO_RSP_STAT_ERR,      /* 0x5 */
    IO_RSP_STAT_LAST
};

/* DCC IO channel error code */
enum
{
    IO_RSP_CODE_NORMAL               = 0x0,
    IO_RSP_CODE_BUS_SLV_ERR          = 0x1,
    IO_RSP_CODE_BUS_DEC_ERR          = 0x2,
    IO_RSP_CODE_BUF_ECC_ERR          = 0x3,
    IO_RSP_CODE_HASH_TIME_OUT_ERR    = 0x4,
    IO_RSP_CODE_CMD_ADDR_INVALID_ERR = 0x8,
    IO_RSP_CODE_CMD_LEN_ERR          = 0x9,
    IO_RSP_CODE_CMD_OP_ERR           = 0xA,
    IO_RSP_CODE_CMD_OPT_SIZE_ERR     = 0xB,
    IO_RSP_CODE_CMD_READ_NOT_WORD_ALIGN_MODE_ERR = 0xC,
    IO_RSP_CODE_CMD_ADDR_WORD_ALIGN_ERR          = 0xD,
    IO_RSP_CODE_CMD_ADDR_HALF_WORD_ALIGN_ERR     = 0xE,
    IO_RSP_CODE_CMD_LEN_NOT_WORD_ALIGN_MODE_ERR  = 0xF,
    IO_RSP_CODE_LAST
};

/* Hash result state */
typedef enum
{
    DCC_IO_HASH_STAT_SET_SUCCESS        = 0x0,
    DCC_IO_HASH_STAT_ADD_SUCCESS        = 0x1,
    DCC_IO_HASH_STAT_INSERT_FAIL        = 0x2,
    DCC_IO_HASH_STAT_SET_FAIL           = 0x3,
    DCC_IO_HASH_STAT_GET_SUCCESS        = 0x4,
    DCC_IO_HASH_STAT_GET_FAIL           = 0x5,
    DCC_IO_HASH_STAT_UCERR              = 0x6,
    DCC_IO_HASH_STAT_MULTIPLE_INSTANCE  = 0x7,
    DCC_IO_HASH_STAT_DEL_SUCCESS        = 0x8,
    DCC_IO_HASH_STAT_DEL_FAIL           = 0x9,
    DCC_IO_HASH_STAT_LAST
} DCC_IO_HASH_STAT_T;

/* Hash width */
typedef enum
{
    DCC_IO_HASH_WIDTH_TYPE_1X = 0x0,
    DCC_IO_HASH_WIDTH_TYPE_2X = 0x1,
    DCC_IO_HASH_WIDTH_TYPE_4X = 0x2,
    DCC_IO_HASH_WIDTH_TYPE_HALF,
    DCC_IO_HASH_WIDTH_TYPE_LAST
} DCC_IO_HASH_WIDTH_TYPE_T;

/* IO frame struct start */
/* below is for w0 and w1 of BASE_DCE_MMIO_REG register. */

#define DCC_IO_CH_OPT_IRQ_MODE  (1)
#define DCC_IO_CH_OPT_SIZE_BYTE (0)
#define DCC_IO_CH_OPT_SIZE_HALF (1)
#define DCC_IO_CH_OPT_SIZE_WORD (2)

#ifdef CLX_EN_BIG_ENDIAN
/* Command Control */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T cmd_sn                        :     8;
        UI32_T cmd_op                        :     8;
        UI32_T                               :     4;
        UI32_T cmd_opt_size                  :     2;
        UI32_T cmd_opt_irq                   :     1;
        UI32_T                               :     1;
        UI32_T cmd_len                       :     8;
    } field;
} DCC_IO_REG_CMDCTL_REG_T;

/* Hash result length */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T                               :    24;
        UI32_T hash_rslt_len                 :     8;
    } field;
} DCC_IO_REG_HASH_RSLT_LEN_REG_T;

/* Response status */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T rsp_sn                        :     8;
        UI32_T rsp_code                      :     8;
        UI32_T rsp_status                    :     8;
        UI32_T rsp_len                       :     8;
    } field;
} DCC_IO_REG_RSPSTAT_REG_T;

/* Hash configuration */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T      : 22;
        UI32_T  view:  2;
        UI32_T      :  6;
        UI32_T  cmd :  2;
    } field;
} DCC_IO_BUF_HASH_CFG_REG_T;

/* Hash trigger */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T          : 31;
        UI32_T  load    :  1;
    } field;
} DCC_IO_BUF_HASH_TRIG_REG_T;

/* Hash status */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T              : 23;
        UI32_T  res_done    :  1;
        UI32_T              :  4;
        UI32_T  res_state   :  4;
    } field;
} DCC_IO_BUF_HASH_STAT_REG_T;
#else
/* Command Control */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T cmd_len                       :     8;
        UI32_T                               :     1;
        UI32_T cmd_opt_irq                   :     1;
        UI32_T cmd_opt_size                  :     2;
        UI32_T                               :     4;
        UI32_T cmd_op                        :     8;
        UI32_T cmd_sn                        :     8;
    } field;
} DCC_IO_REG_CMDCTL_REG_T;

/* Hash result length */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T hash_rslt_len                 :     8;
        UI32_T                               :    24;
    } field;
} DCC_IO_REG_HASH_RSLT_LEN_REG_T;

/* Response status */
typedef union
{
    UI32_T    reg;
    struct
    {
        UI32_T rsp_len                       :     8;
        UI32_T rsp_status                    :     8;
        UI32_T rsp_code                      :     8;
        UI32_T rsp_sn                        :     8;
    } field;
} DCC_IO_REG_RSPSTAT_REG_T;

/* Hash configuration */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T  cmd :  2;
        UI32_T      :  6;
        UI32_T  view:  2;
        UI32_T      : 22;
    } field;
} DCC_IO_BUF_HASH_CFG_REG_T;

/* Hash trigger */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T  load    :  1;
        UI32_T          : 31;
    } field;
} DCC_IO_BUF_HASH_TRIG_REG_T;

/* Hash status */
typedef union
{
    UI32_T reg;
    struct
    {
        UI32_T  res_state   :  4;
        UI32_T              :  4;
        UI32_T  res_done    :  1;
        UI32_T              : 23;
    } field;
} DCC_IO_BUF_HASH_STAT_REG_T;
#endif

typedef struct
{
    UI32_T  reg_cmdadr_mmio_addr;
    UI32_T  reg_cmdctl_mmio_addr;
    UI32_T  reg_hash_rslt_len_mmio_addr;
    UI32_T  reg_rspstat_mmio_addr;
    UI32_T  reg_rspdata_mmio_addr;
    UI32_T  reg_hashstat_mmio_addr;
    UI32_T  buf_data_buf_mmio_addr;
} DCC_IO_MMIO_ADDR_CB_T;

/* DCC IO channel control block structure */
typedef struct
{
    /* channel OS resource */
    CLX_SEMAPHORE_ID_T      protect_sema; /* channel protection semaphore */
    /* channel operation mode */
    DCC_CH_OP_MODE_T        op_mode;        /* operation is polling or interrupt */
    UI32_T                  op_timeout_cnt; /* time-out count while channel access operation */
    /* debug counters */
    UI32_T                  rst_cnt; /* reset count */
    UI32_T                  abt_cnt; /* abort count */
    UI32_T                  nak_cnt; /* non-ack count */
    UI32_T                  err_cnt; /* error count */
    /* performance timestamp */
    CLX_TIME_T              cmd_start; /* io command start execution time */
    CLX_TIME_T              cmd_stop; /* io command end execution time */
    CLX_TIME_T              cmd_max_time; /* io command Max execution time */
    CLX_TIME_T              cmd_min_time; /* io command min execution time */
    /* mmio addr control block */
    DCC_IO_MMIO_ADDR_CB_T   mmio_addr_cb;
    /* channel cmd serial number */
    UI8_T                   sn;
} DCC_IO_CH_CB_T;

/* FUNCTION NAME:   dcc_io_initIoRsrc
 * PURPOSE:
 *      dcc_io_initIoRsrc() is responsible for resource of DCC IO initialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_io_initIoRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_io_initIoThread
 * PURPOSE:
 *      dcc_io_initIoThread() is responsible for thread of DCC IO initialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_io_initIoThread(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_io_deinitIoRsrc
 * PURPOSE:
 *      dcc_io_deinitIoRsrc() is responsible for resource of DCC IO deinitialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_io_deinitIoRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_io_deinitIoRsrc
 * PURPOSE:
 *      dcc_io_deinitIoRsrc() is responsible for thread of DCC IO deinitialization
 *
 * INPUT:
 *      unit             -- The unit number that would like to be initialized.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully initialize DCC.
 *      CLX_E_OTHERS  -- Fail to complete initialization procedure.
 *      CLX_E_NO_MEMORY  -- Fail to allocate memory.
 *
 * NOTES:
 *      This function will be invoked by init module's initialization
 *      framework.
 *
 */
CLX_ERROR_NO_T
dcc_io_deinitIoThread(
    const UI32_T                unit);

/* FUNCTION NAME:   dcc_io_txCmd
 * PURPOSE:
 *      dcc_io_txCmd() is the function that will send a command to DCE IO channel.
 *
 * INPUT:
 *      unit        -- The unit number that would like to be accessed.
 *      action      -- Read or write action.
 *      addr        -- Chip register or table address.
 *      ptr_data    -- The command data or data buffer.
 *      data_len    -- The command data length.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Successfully send a DCC command.
 *      CLX_E_OTHERS  -- Fail to send a DCC command.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_io_txCmd(
    const UI32_T        unit,
    const DCC_CMD_ACT_T action,
    const UI32_T        addr,
    UI32_T              *ptr_data,
    const UI32_T        data_len);

/* FUNCTION NAME:   dcc_io_txHashCmd
 * PURPOSE:
 *      dcc_io_txHashCmd() is a function that will send a hash command through DCE IO channel.
 *
 * INPUT:
 *      unit          -- The unit number that would like to be accessed.
 *      action        -- Hash add, lookup, or delete action.
 *      addr          -- Chip register or table address.
 *      ptr_hash_info -- Hash table meta info, indirect addr, trig addr, view.
 *      bnk_bitmap    -- The bank bitmap to apply hash action.
 *      ptr_data      -- The hash command data and data buffer.
 *      data_len      -- The hash command data length.
 *
 * OUTPUT:
 *      ptr_entry_idx -- The hash value of the hash key.
 *
 * RETURN:
 *      CLX_E_OK      -- Successfully send a DCC command.
 *      CLX_E_OTHERS  -- Fail to send a DCC command.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_io_txHashCmd(
    const UI32_T                unit,
    const DCC_CMD_HASH_ACT_T    action,
    const UI32_T                addr,
    HASH_TBL_META_T             *ptr_hash_info,
    const UI32_T                bnk_bitmap,
    UI32_T                      *ptr_data,
    const UI32_T                data_len,
    UI32_T                      *ptr_entry_idx);

/* FUNCTION NAME:   dcc_io_setIoOperationMode
 * PURPOSE:
 *      dcc_io_setIoOperationMode() is a function to change DCC IO channel operation mode to be poll or
 *      interrupt.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      op_mode       -- The IO channel operation mode, valid are:
 *                       1. DCC_CH_OP_MODE_POLL
 *                       2. DCC_CH_OP_MODE_INTR
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set IO channel operation mode successfully.
 *      CLX_E_OTHERS  -- Fail to set IO channel operation mode.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_io_setIoOperationMode(
    const UI32_T unit,
    const DCC_CH_OP_MODE_T op_mode);

/* FUNCTION NAME:   dcc_io_setIoOperationTimeoutCnt
 * PURPOSE:
 *      dcc_io_setIoOperationTimeoutCnt() is a function to change DCC IO channel operation time-out count.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      timeout_cnt   -- The IO channel operation time-out count for polling mode.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK      -- Set IO channel operation time-out count successfully.
 *      CLX_E_OTHERS  -- Fail to set IO channel operation time-out count.
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_io_setIoOperationTimeoutCnt(
    const UI32_T unit,
    const UI32_T timeout_cnt);

/* FUNCTION NAME:   dcc_io_showIoChannelInfo
 * PURPOSE:
 *      dcc_io_showIoChannelInfo() is a function to display DCC IO channel information.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      None
 *
 * NOTES:
 *      None
 *
 */
void
dcc_io_showIoChannelInfo(
    const UI32_T unit);

/* FUNCTION NAME:   dcc_ioCmdCoreOneError
 * PURPOSE:
 *      dcc_ioCmdCoreOneError() is a function to handle io core one error irq.
 *
 * INPUT:
 *      unit          -- The specified unit number.
 *      isr_cookie   -- The specified isr cookie.
 * OUTPUT:
 *      None
 *      CLX_E_OK  -- handle io command error successfully
 *
 * NOTES:
 *      None
 *
 */
CLX_ERROR_NO_T
dcc_ioCmdCoreOneError(
    const UI32_T unit,
    const UI32_T isr_cookie);

#endif /* END of DCC_IO_H*/
