/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_dawn_l3_mcast.h
 * PURPOSE:
 *      It provide module api for L3 layer multicast.
 * NOTES:
 *
 */

#ifndef HAL_DAWN_L3_MCAST_H
#define HAL_DAWN_L3_MCAST_H

/* INCLUDE FILE DECLARTIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <clx_init.h>
#include <clx_l3.h>
#include <cdb/cdb.h>
#include <hal/common/hal_io.h>
#include <hal/common/hal_vlan.h>
#include <hal/common/hal_l3.h>

/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
/*************************************
 * ETM_RSLT_MEL_INFO
 * EMI_RSLT_MEL
 *************************************/
#define HAL_DAWN_L3_MCAST_MEL_INFO_VALID                         (0x0)
#define HAL_DAWN_L3_MCAST_MEL_INFO_INVALID                       (0x3FFF)/*should be 0x3FFF*/
#define HAL_DAWN_L3_MCAST_MEL_HDR_INVALID                        (0x1FFF)/*0x1FFF*/
#define HAL_DAWN_L3_MCAST_MET_PORT_INVALID                       (0x3F)
#define HAL_DAWN_L3_MCAST_MEL_SUB_ENTRY_INVALID_SRC_SUPP_TAG     (0x1F)
#define HAL_DAWN_L3_MCAST_MEL_SUB_ENTRY_NOT_DECREASE_TTL         (0x0)
#define HAL_DAWN_L3_MCAST_MEL_SUB_ENTRY_INVALID_ADJ_IDX          (0x3FFFF)

#define HAL_DAWN_L3_MCAST_PER_GROUP_PER_PORT_MAX_EGR_INTF_NUM    (8192)
#define HAL_DAWN_L3_MCAST_ID_BASE                                (16384) /*20K-4K*/
#define HAL_DAWN_L3_MCAST_ID_MAX_NUM                             (8192)

/* SW veiw address */
#define HAL_DAWN_L3_MCAST_IS_V4_ADDR(addr) (((addr >> 28) == 0xe) ? 1 : 0)
#define HAL_DAWN_L3_MCAST_IS_V6_ADDR(addr) ((addr[0] == 0xff) ? 1 : 0)

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */
/* ----------------------------------------------------------------------------------- Init and Deinit */
CLX_ERROR_NO_T
hal_dawn_l3_mcast_saveSwdb(
    const UI32_T            unit,
    HAL_IO_WB_DB_T          *ptr_db);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_restoreSwdb(
    const UI32_T            unit,
    HAL_IO_WB_DB_T          *ptr_db);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_initWarm(
    const UI32_T            unit);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_initCfg(
    const UI32_T            unit);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_init(
    const UI32_T            unit);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_deinit(
    const UI32_T            unit);

/* ----------------------------------------------------------------------------------- Internal API */
CLX_ERROR_NO_T
hal_dawn_l3_mcast_setValidateIp(
    const UI32_T  unit,
    const UI32_T  enable,
    const UI32_T  fail_act);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getValidateIp(
    const UI32_T  unit,
    UI32_T        *ptr_enable,
    UI32_T        *ptr_fail_act);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delMemberAll(
    const UI32_T  unit,
    const UI32_T  mcast_id);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_addMelSubEntryByPort(
    const UI32_T                           unit,
    const UI32_T                           mcast_id,
    const UI32_T                           port_id,
    const UI32_T                           entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T     *ptr_sub_entry);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delMelSubEntryByPort(
    const UI32_T                           unit,
    const UI32_T                           mcast_id,
    const UI32_T                           port_id,
    const UI32_T                           entry_num,
    const HAL_L3_MCAST_MEL_SUB_ENTRY_T     *ptr_sub_entry);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getMelSubEntryByPort(
    const UI32_T                      unit,
    const UI32_T                      mcast_id,
    const UI32_T                      port_id,
    const UI32_T                      entry_num,
    HAL_L3_MCAST_MEL_SUB_ENTRY_T      *ptr_sub_entry,
     UI32_T                           *ptr_actual_num);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getMelSubEntryNumByPort(
     const UI32_T                     unit,
     const UI32_T                     mcast_id,
     const UI32_T                     port_id,
     UI32_T                           *ptr_entry_num);

/* ----------------------------------------------------------------------------------- CLX API */
CLX_ERROR_NO_T
hal_dawn_l3_mcast_addEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_setEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    const CLX_L3_MCAST_EGR_INTF_T   *ptr_egr_intf);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getEgrIntfCntByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    UI32_T                          *ptr_egr_intf_cnt);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getEgrIntfByPort(
    const UI32_T                    unit,
    const UI32_T                    mcast_id,
    const UI32_T                    port_id,
    const UI32_T                    egr_intf_cnt,
    CLX_L3_MCAST_EGR_INTF_T         *ptr_egr_intf,
    UI32_T                          *ptr_actual_egr_intf_cnt);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_addId(
    const UI32_T        unit,
    const UI32_T        flags,
    UI32_T              *ptr_mcast_id);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delId(
    const UI32_T        unit,
    const UI32_T        mcast_id);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getId(
    const UI32_T        unit,
    const UI32_T        mcast_id,
    UI32_T              *ptr_flags,
    CLX_PORT_BITMAP_T   port_bitmap);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_addGroup(
    const UI32_T                    unit,
    const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delGroup(
    const UI32_T                    unit,
    const CLX_L3_MCAST_GROUP_INFO_T *ptr_group_info);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getGroup(
    const UI32_T                    unit,
    CLX_L3_MCAST_GROUP_INFO_T       *ptr_group_info);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_traverseGroup(
    const UI32_T                                unit,
    const CLX_L3_MCAST_GROUP_TRAVERSE_FUNC_T    callback,
    void                                        *ptr_cookie);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_addDfIntf(
    const UI32_T         unit,
    const UI32_T         intf_id,
    const CLX_IP_ADDR_T  *ptr_rp_addr);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delDfIntf(
    const UI32_T         unit,
    const UI32_T         intf_id,
    const CLX_IP_ADDR_T  *ptr_rp_addr);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getDfIntf(
    const UI32_T         unit,
    const UI32_T         intf_id,
    const UI32_T         rp_addr_cnt,
    UI32_T               *ptr_actual_rp_addr_cnt,
    CLX_IP_ADDR_T        *ptr_rp_addr);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_addSrcForPimReg(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_delSrcForPimReg(
    const UI32_T                    unit,
    const CLX_L3_PIM_REG_INFO_T     *ptr_info);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_getSrcForPimReg(
    const UI32_T                    unit,
    CLX_L3_PIM_REG_INFO_T           *ptr_info);

CLX_ERROR_NO_T
hal_dawn_l3_mcast_dumpSwdb(
    const UI32_T    unit);

#endif /* End of HAL_DAWN_L3_MCAST_H */
