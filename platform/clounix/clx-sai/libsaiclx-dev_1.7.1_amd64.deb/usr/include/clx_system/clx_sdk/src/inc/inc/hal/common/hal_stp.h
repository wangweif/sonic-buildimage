/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_stp.h
 * PURPOSE:
 *  Define STP module HAL function.
 *
 * NOTES:
 *
 */
#ifndef HAL_STP_H
#define HAL_STP_H


/* INCLUDE FILE DECLARTIONS
*/
#include <clx_types.h>
#include <clx_error.h>
#include <clx_stp.h>

/* NAMING CONSTANT DECLARATIONS
*/

/* MACRO FUNCTION DECLARATIONS
*/

/* DATA TYPE DECLARATIONS
*/

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/******************************************************************************/
/* hal multiplexing api                                                       */
/******************************************************************************/

/* FUNCTION NAME: hal_stp_init
 * PURPOSE:
 *     Initialize the STP module. In the initialization process, it will create
 *     the STG 0, and set the port state to be "forward" or "discard" for all
 *     ports in  STG 0 according to user's choose.
 * INPUT:
 *     unit                 -- Device unit number
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK             -- Operation success
 *     CLX_E_BAD_PARAMETER  -- bad parameter
 *     CLX_E_NO_MEMORY      -- no available memory
 *     CLX_E_OTHERS         -- Operation failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_init(
    const UI32_T    unit);

/* FUNCTION NAME: hal_stp_deinit
 * PURPOSE:
 *     Deinitialize the STP module.
 * INPUT:
 *     unit                 -- Device unit number
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK             -- Operation success
 *     CLX_E_BAD_PARAMETER  -- bad parameter
 *     CLX_E_OTHERS         -- Operation failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_deinit(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_stp_setPortDefault
 * PURPOSE:
 *      Apply default stp related properties for the new created port:
 *      (1) Set port state to forward on default stp group
 * INPUT:
 *      unit -- Device unit number
 *      port -- Port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_OTHER -- Operate fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_setPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME:   hal_stp_resetPortDefault
 * PURPOSE:
 *      Reset default stp related properties for the deleted port:
 *      (1) Set port state to discard on default stp
 * INPUT:
 *      unit -- Device unit number
 *      port -- Port number
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK    -- Operate success.
 *      CLX_E_OTHER -- Operate fail.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_resetPortDefault(
    const UI32_T    unit,
    const UI32_T    port);

/* FUNCTION NAME: hal_stp_createStg
 * PURPOSE:
 *     Create a STG without user specific STG ID, and output the created STG ID
 *     to user.
 * INPUT:
 *     unit                 -- Device unit number
 * OUTPUT:
 *     ptr_stg              -- The ID of the created STG
 * RETURN:
 *     CLX_E_OK             -- operation success
 *     CLX_E_BAD_PARAMETER  -- bad parameter, "unit" is invalid or "ptr_stg"
 *                             is NULL
 *     CLX_E_TABLE_FULL     -- the mstp table is full
 *     CLX_E_OTHERS         -- operation failed
 * NOTES:
 *     STG 0 has been created in STP module initialization process, and will not
 *     been created again.
 */
CLX_ERROR_NO_T
hal_stp_createStg(
    const UI32_T    unit,
    const UI32_T    stg);

/* FUNCTION NAME: hal_stp_destroyStg
 * PURPOSE:
 *     Destroy a specific STG. User should allocate these VLAN/Bridge Domain
 *     associated with this STG to other STG(s) by API clx_stp_setVlanStg() or
 *     clx_stp_setBridgeDomainStg() before call this API.
 * INPUT:
 *     unit                   -- Device unit number
 *     stg                    -- The ID of the STG which will be deleted
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK               -- operation success
 *     CLX_E_BAD_PARAMETER    -- bad parameter, "unit" or "stg" is invalid
 *     CLX_E_ENTRY_NOT_FOUND  -- the specific STG has not been created
 *     CLX_E_OTHERS           -- operation failed
 * NOTES:
 *     STG 0 is always active and will not be deleted.
 */
CLX_ERROR_NO_T
hal_stp_destroyStg(
    const UI32_T    unit,
    const UI32_T    stg);

/* FUNCTION NAME: hal_stp_setPortstate
 * PURPOSE:
 *     Set the port state for a port in a specific STG.
 * INPUT:
 *     unit                   -- Device unit number
 *     stg                    -- STG ID
 *     port                   -- Port ID
 *     portstate              -- STP port state
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK               -- operation success
 *     CLX_E_BAD_PARAMETER    -- bad parameter, "unit","stg" or "port" is invalid
 *     CLX_E_ENTRY_NOT_FOUND  -- the STG has not been created
 *     CLX_E_OTHERS           -- operation failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_setPortstate(
    const UI32_T                 unit,
    const UI32_T                 stg,
    const UI32_T                 port,
    const CLX_STP_PORTSTATE_T    portstate);

/* FUNCTION NAME: hal_stp_getPortstate
 * PURPOSE:
 *     Get the port state for a port in a specific STG.
 * INPUT:
 *     unit                   -- Device unit number
 *     stg                    -- STG ID
 *     port                   -- Port ID
 * OUTPUT:
 *     ptr_portstate          -- The STP port state for the port in the STG
 * RETURN:
 *     CLX_E_OK               -- operation success
 *     CLX_E_BAD_PARAMETER    -- bad parameter, "unit","stg" or "port" invalid,
 *                               or "ptr_portstate" is NULL
 *     CLX_E_ENTRY_NOT_FOUND  -- the STG has not been created
 *     CLX_E_OTHERS           -- operation failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_getPortstate(
    const UI32_T           unit,
    const UI32_T           stg,
    const UI32_T           port,
    CLX_STP_PORTSTATE_T    *ptr_portstate);

/* FUNCTION NAME: hal_stp_isStgValid
 * PURPOSE:
 *     Check whether a STG has been created.
 * INPUT:
 *     unit                   -- Device unit number
 *     stg                    -- The STG id.
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK               -- operation success, and the STG has been created
 *     CLX_E_BAD_PARAMETER    -- bad parameter, "unit" or "stg" invalid
 *     CLX_E_OTHERS           -- operation failed
 *     CLX_E_ENTRY_NOT_FOUND  -- the STG has not been created
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_stp_isStgValid(
    const UI32_T    unit,
    const UI32_T    stg);

#endif
