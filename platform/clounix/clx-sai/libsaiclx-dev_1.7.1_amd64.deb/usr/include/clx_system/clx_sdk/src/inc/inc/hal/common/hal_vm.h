/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_vm.h
 * PURPOSE:
 *      It provide vm module hal level api.
 * NOTES:
 *  Description
 */

#ifndef HAL_VM_H
#define HAL_VM_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_types.h>
#include <clx_error.h>
#include <hal/common/hal_const_cmn.h>
#include <hal/common/hal_vlan.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_VM_VID_INFO_FLAGS_IS_L2_UC  (1U << 0)

/* MACRO FUNCTION DECLARATIONS
 */
/* Hw-view to user-view : will not extend, can be full mapped */
#define HAL_VM_PORT_MODE_TO_VM_MODE(__port_mode__)   (_hal_vm_mode_map[(__port_mode__)]     )
#define HAL_VM_PORT_MODE_TO_VM_TYPE(__port_mode__)   (_hal_vm_type_map[(__port_mode__)]     )
#define HAL_VM_PORT_MODE_TO_PORT_ROLE(__port_mode__) (_hal_vm_port_role_map[(__port_mode__)])

/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_VM_PORT_ROLE_EXT,
    HAL_VM_PORT_ROLE_CAS,
    HAL_VM_PORT_ROLE_UPS,
} HAL_VM_PORT_ROLE_T;

/* LOCAL SUBPROGRAM BODIES
 */
extern CLX_VM_MODE_T        _hal_vm_mode_map[14];
extern CLX_VM_TAG_TYPE_T    _hal_vm_type_map[14];
extern HAL_VM_PORT_ROLE_T   _hal_vm_port_role_map[14];

/* FUNCTION NAME: hal_vm_init
 * PURPOSE:
 *     initialize the vm module.
 * INPUT:
 *     unit -- Device unit number
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK            -- initialize success
 *     CLX_E_BAD_PARAMETER -- Bad parameter
 *     CLX_E_OTHERS        -- initialize failed
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_init(
    const UI32_T    unit);

/* FUNCTION NAME: hal_vm_deinit
 * PURPOSE:
 *     Deinitialize the vm module.
 * INPUT:
 *     unit -- Device unit number
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK            -- Deinitialization success.
 *     CLX_E_BAD_PARAMETER -- Bad parameter.
 *     CLX_E_OTHERS        -- Deinitialization failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_deinit(
    const UI32_T    unit);

#if defined(CLX_EN_VM)
/* FUNCTION NAME:   hal_vm_dumpDb
 * PURPOSE:
 *      dump vm swdb
 * INPUT:
 *      unit    -- Device unit number
 *      flags   -- SWDB option
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_*
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_dumpDb(
    const UI32_T    unit,
    const UI32_T    flags);

/* FUNCTION NAME:   hal_vm_setVmMode
 * PURPOSE:
 *      Set chip vm mode.
 * INPUT:
 *      unit -- Device unit number
 *      mode -- Chip virtual machine mode
 * OUTPUT:
 *      none
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHER         -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_setVmMode(
    const UI32_T           unit,
    const CLX_VM_MODE_T    mode);

/* FUNCTION NAME:   hal_vm_getVmMode
 * PURPOSE:
 *      Get chip vm mode.
 * INPUT:
 *      unit     -- Device unit number
 * OUTPUT:
 *      ptr_mode -- Chip virtual machine mode
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_OTHER         -- Operate failed.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getVmMode(
    const UI32_T     unit,
    CLX_VM_MODE_T    *ptr_mode);

/* FUNCTION NAME:   hal_vm_createPort
 * PURPOSE:
 *      This API is used to create a VM interface object
 * INPUT:
 *      unit          -- Device unit number
 *      port          -- Native port/unit port/LAG port
 *      vm_id         -- VM id
 *      vm_type       -- VM tag type
 * OUTPUT:
 *      ptr_intf      -- VM port
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_vm_createPort(
    const UI32_T               unit,
    const CLX_PORT_T           port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type,
    CLX_PORT_T                 *ptr_vm_port);

/* FUNCTION NAME:   hal_vm_destroyPort
 * PURPOSE:
 *      This API is used to destroy a VM interface object.
 * INPUT:
 *      unit -- Device unit number
 *      intf -- VM port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not found.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_vm_destroyPort(
    const UI32_T        unit,
    const CLX_PORT_T    vm_port);

/* FUNCTION NAME:   hal_vm_getPort
 * PURPOSE:
 *      This API is used to get a VM port.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Port or LAG port
 *      vm_id       -- VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 *      vm_type     -- VM type
 * OUTPUT:
 *      ptr_vm_port -- VM port
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- VM port is not created.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_vm_getPort(
    const UI32_T               unit,
    const CLX_PORT_T           port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_tag_type,
    CLX_PORT_T                 *ptr_vm_port);

/* FUNCTION NAME:   hal_vm_getKey
 * PURPOSE:
 *      This API is used to get keys of a VM port.
 * INPUT:
 *      unit        -- Device unit number
 *      vm_port     -- VM port
 * OUTPUT:
 *      ptr_port    -- Port or LAG port
 *      ptr_vm_id   -- VM id (1BR P2P ECID/ NIV VIF/ VEPA S-channel id)
 *      ptr_vm_type -- VM type
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- VM port is not created or is destroyed.
 * NOTES:
 *      None
 */
CLX_ERROR_NO_T
hal_vm_getKey(
    const UI32_T         unit,
    const CLX_PORT_T     vm_port,
    CLX_PORT_T           *ptr_port,
    CLX_VM_ID_T          *ptr_vm_id,
    CLX_VM_TAG_TYPE_T    *ptr_vm_type);

/* FUNCTION NAME:   hal_vm_setUpstreamPort
 * PURPOSE:
 *      Set upstream interface of the downstream interface.
 * INPUT:
 *      unit            -- Device unit number
 *      downstream_port -- Downstream port
 *      upstream_port   -- Upstream port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      1. Should set chip vm mode to PE/IV first.
 *      2. The downstream_port must be
 *           (1) port/lag port of extended port, or
 *           (2) vm port of cascade port.
 *      3. The upstream_port must be port/lag port.
 */
CLX_ERROR_NO_T
hal_vm_setUpstreamPort(
    const UI32_T        unit,
    const CLX_PORT_T    downstream_port,
    const CLX_PORT_T    upstream_port);

/* FUNCTION NAME:   hal_vm_getUpstreamPort
 * PURPOSE:
 *      Get upstream interface of the downstream interface.
 * INPUT:
 *      unit              -- Device unit number
 *      downstream_port   -- Downstream port
 * OUTPUT:
 *      ptr_upstream_port -- Upstream port
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getUpstreamPort(
    const UI32_T        unit,
    const CLX_PORT_T    downstream_port,
    CLX_PORT_T          *ptr_upstream_port);

/* FUNCTION NAME:   hal_vm_resetUpstreamPort
 * PURPOSE:
 *      Set upstream port for downstream port.
 * INPUT:
 *      unit            -- Device unit number
 *      downstream_port -- Downstream port
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_resetUpstreamPort(
    const UI32_T        unit,
    const CLX_PORT_T    downstream_port);

/* FUNCTION NAME:   hal_vm_setPortProperty
 * PURPOSE:
 *      Set VM related port properties such as
 *      vm port type, vm check fail action, vm rpf fail action... etc
 * INPUT:
 *      unit      -- Device unit number
 *      port      -- Native port/unit port
 *      ptr_prty  -- VM related port property
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      1. Not support per port-based remove vepa tag.
 *         Setting remove-egress vepa tag per forwarding entry.
 *      2. Only support per system-based tag_miss_action. (last will cover first)
 *      3. Only support per system-based rpf_fail_action. (last will cover first)
 */
CLX_ERROR_NO_T
hal_vm_setPortProperty(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_PORT_PRTY_T    *ptr_prty);

/* FUNCTION NAME:   hal_vm_getPortProperty
 * PURPOSE:
 *      Get VM related port properties such as
 *      vm port type, vm check fail action, vm rpf fail action... etc
 * INPUT:
 *      unit      -- Device unit number
 *      port      -- Native port/unit port
 * OUTPUT:
 *      ptr_prty  -- VM related port property
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      This function will get port property.
 */
CLX_ERROR_NO_T
hal_vm_getPortProperty(
    const UI32_T          unit,
    const CLX_PORT_T      port,
    CLX_VM_PORT_PRTY_T    *ptr_prty);

/* FUNCTION NAME:   hal_vm_pe_addUcastAddr
 * PURPOSE:
 *     Add an unicast entry in PE/IV.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_addr            -- Unicast entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vm_pe_addUcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_UCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   hal_vm_pe_delUcastAddr
 * PURPOSE:
 *     Delete an unicast entry in PE/IV.
 * INPUT:
 *      unit                -- Device unit number
 *      ptr_addr            -- Unicast entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vm_pe_delUcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_UCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   hal_vm_pe_getUcastAddr
 * PURPOSE:
 *     Get an unicast entry in PE/IV.
 * INPUT:
 *      unit     -- Device unit number
 *      ptr_addr -- Key parts of unicast entry
 * OUTPUT:
 *      ptr_addr -- Result parts of Unicast entry
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vm_pe_getUcastAddr(
    const UI32_T              unit,
    CLX_VM_PE_UCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   hal_vm_pe_addMcastAddr
 * PURPOSE:
 *      Add a multicast entry in PE/IV.
 * INPUT:
 *      unit     -- Device unit number
 *      ptr_addr -- Multicast entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vm_pe_addMcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   hal_vm_pe_delMcastAddr
 * PURPOSE:
 *      Delete a multicast entry in PE/IV.
 * INPUT:
 *      unit     -- Device unit number
 *      ptr_addr -- Multicast entry
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vm_pe_delMcastAddr(
    const UI32_T                    unit,
    const CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   hal_vm_pe_getMcastAddr
 * PURPOSE:
 *      Get a multicast entry in PE/IV.
 * INPUT:
 *      unit     -- Device unit number
 *      ptr_addr -- Key parts of multicast entry
 * OUTPUT:
 *      ptr_addr -- Result parts of multicast entry
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_vm_pe_getMcastAddr(
    const UI32_T              unit,
    CLX_VM_PE_MCAST_ADDR_T    *ptr_addr);

/* FUNCTION NAME:   hal_vm_addMcastIntfProperty
 * PURPOSE:
 *      This API is used to add interface of a port combined with multicast vm id, and
 *      set related interface properties.
 * INPUT:
 *      unit          -- Device unit number
 *      port          -- Native port/ unit port
 *      vm_type       -- VM type
 *      vm_id         -- 1BR p2mp or NIV vif-list VM id
 *      ptr_property  -- Interface property
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
hal_vm_addMcastIntfProperty(
    const UI32_T                      unit,
    const CLX_PORT_T                  port,
    const CLX_VM_ID_T                 vm_id,
    const CLX_VM_TAG_TYPE_T           vm_type,
    const CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   hal_vm_delMcastIntfProperty
 * PURPOSE:
 *      This API is used to delete interface of a port combined with multicast vm id.
 * INPUT:
 *      unit      -- Device unit number
 *      port      -- Native port/ unit port
 *      vm_type   -- VM type
 *      vm_id     -- 1BR p2mp or NIV vif-list VM id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Operate success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
hal_vm_delMcastIntfProperty(
    const UI32_T               unit,
    const CLX_PORT_T           port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type);

/* FUNCTION NAME:   hal_vm_getMcastIntfProperty
 * PURPOSE:
 *      This API is used to get interface properties of a port combined with multicast vm id.
 * INPUT:
 *      unit          -- Device unit number
 *      vm_type       -- VM type
 *      vm_id         -- 1BR p2mp or NIV vif-list VM id
 *      port          -- Native port/ unit port
 * OUTPUT:
 *      ptr_property  -- Interface property
 * RETURN:
 *      CLX_E_OK              -- Operation success.
 *      CLX_E_BAD_PARAMETER   -- Bad parameter.
 *      CLX_E_ENTRY_NOT_FOUND -- Entry not exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
hal_vm_getMcastIntfProperty(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    CLX_PORT_INTF_PROPERTY_T    *ptr_property);

/* FUNCTION NAME:   hal_vm_addMcastSegService
 * PURPOSE:
 *      This API is used to add service of a port combined multicast vm-id and vlan.
 *      1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *      2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Port
 *      vm_type     -- VM type
 *      vm_id       -- 1BR p2mp or NIV vif-list VM id
 *      seg0        -- Segment parameter 0
 *      seg1        -- Segment parameter 1
 *      ptr_seg_srv -- Service
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
hal_vm_addMcastSegService(
    const UI32_T                unit,
    const CLX_PORT_T            port,
    const CLX_VM_ID_T           vm_id,
    const CLX_VM_TAG_TYPE_T     vm_type,
    const UI32_T                seg0,
    const UI32_T                seg1,
    const CLX_PORT_SEG_SRV_T    *ptr_seg_srv);

/* FUNCTION NAME:   hal_vm_delMcastSegService
 * PURPOSE:
 *      This API is used to delete service of a port combined multicast vm-id and vlan.
 *      1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *      2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Port
 *      vm_type     -- VM type
 *      vm_id       -- 1BR p2mp or NIV vif-list VM id
 *      seg0        -- Segment parameter 0
 *      seg1        -- Segment parameter 1
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
hal_vm_delMcastSegService(
    const UI32_T               unit,
    const CLX_PORT_T           port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type,
    const UI32_T               seg0,
    const UI32_T               seg1);

/* FUNCTION NAME:   hal_vm_getMcastSegService
 * PURPOSE:
 *      This API is used to get service of a port combined multicast vm-id and vlan.
 *      1. Setting c-vid only, seg0 = c-vid, seg1 = invalid value.
 *      2. Setting s-vid and c-vid both, seg0 = s-vid, seg1 = c-vid.
 * INPUT:
 *      unit        -- Device unit number
 *      port        -- Port
 *      vm_type     -- VM type
 *      vm_id       -- 1BR p2mp or NIV vif-list VM id
 *      seg0        -- Segment parameter 0
 *      seg1        -- Segment parameter 1
 * OUTPUT:
 *      ptr_srv     -- Service
 * RETURN:
 *      CLX_E_OK            -- Operation success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 *      CLX_E_ENTRY_EXISTS  -- Entry exists.
 * NOTES:
 *      1. Only p2mp 1BR/NIV vmid.
 */
CLX_ERROR_NO_T
hal_vm_getMcastSegService(
    const UI32_T               unit,
    const CLX_PORT_T           port,
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type,
    const UI32_T               seg0,
    const UI32_T               seg1,
    CLX_PORT_SEG_SRV_T         *ptr_srv);
#endif /* defined(CLX_EN_VM) */

/* EXPORTED HAL PROGRAMS
 */
/* FUNCTION NAME:   [hal] hal_vm_checkVmId
 * PURPOSE:
 *      check vm_id in valid range.
 * INPUT:
 *      vm_id   -- vm id (for vntag, consist of p-bit)
 *      vm_type -- vm tag type
 *      is_p2p  -- vm id is p2p or p2mp
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- VM id is legal.
 *      CLX_E_BAD_PARAMETER -- VM id is illegal.
 * NOTES:
  */
CLX_ERROR_NO_T
hal_vm_checkVmId(
    const CLX_VM_ID_T          vm_id,
    const CLX_VM_TAG_TYPE_T    vm_type,
    const UI32_T               is_p2p);

/* FUNCTION NAME:   [hal] hal_vm_setNivSrcVif
 * PURPOSE:
 *     Set system default srv vrf for niv.
 * INPUT:
 *      unit   -- Device unit number
 *      vif_id -- vif id
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Operate not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_setNivSrcVif(
    const UI32_T    unit,
    const UI32_T    vif_id);

/* FUNCTION NAME:   [hal] hal_vm_getNivSrcVif
 * PURPOSE:
 *      Get system default srv vrf for niv.
 * INPUT:
 *      unit       -- Device unit number
 * OUTPUT:
 *      ptr_vif_id -- Niv src_vif
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Operate not support.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getNivSrcVif(
    const UI32_T    unit,
    UI32_T          *ptr_vif_id);

/* FUNCTION NAME:   [hal] hal_vm_setPeFcoeTransMode
 * PURPOSE:
 *      Set PE fcoe transit mode.
 * INPUT:
 *      unit   -- Device unit number
 *      enable -- Enable/Disable PE fcoe transit mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_setPeFcoeTransMode(
    const UI32_T    unit,
    const UI32_T    enable);

/* FUNCTION NAME:   [hal] hal_vm_getPeFcoeTransMode
 * PURPOSE:
 *     Get current PE fcoe transit mode status.
 * INPUT:
 *      unit           -- Device unit number
 * OUTPUT:
 *      ptr_is_enabled -- PE Fcoe transit mode enabled or not
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getPeFcoeTransMode(
    const UI32_T    unit,
    UI32_T          *ptr_enable);

/* FUNCTION NAME:   [HAL] hal_vm_getSrcSuppTag
 * PURPOSE:
 *      Get per port src_supp_tag.
 * INPUT:
 *      unit    -- Device unit number
 *      port    -- uc: vm_port, mc: native port
 * OUTPUT:
 *      ptr_sst -- source suppression tag
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      Port/Lag can NOT call this API.
 *      Because this api will call port/lag api to get per di sst,
 *      will hang if caller is port/lag module.
 */
CLX_ERROR_NO_T
hal_vm_getSrcSuppTag(
    const UI32_T        unit,
    const CLX_PORT_T    port,
    UI32_T              *ptr_sst);

/* FUNCTION NAME:   [HAL] hal_vm_getHwVidInfo
 * PURPOSE:
 *      Get HW vid_ctl/1st/2nd info of vm port.
 * INPUT:
 *      unit                  -- Device unit number
 *      vm_port               -- VM port
 *      vlan_action           -- VLAN action
 *      ptr_tag_action        -- VLAN tag action
 *      flags                 -- Refer HAL_VM_VID_INFO_FLAGS_XXX
 * OUTPUT:
 *      ptr_info              -- HW vlan info
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_ENTRY_NOT_FOUND -- Entry doesn't exist
 *      CLX_E_BAD_PARAMETER   -- Some of inputs are illegal
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getHwVidInfo(
    const UI32_T                   unit,
    const CLX_PORT_T               vm_port,
    const CLX_VLAN_ACTION_T        vlan_action,
    const CLX_VLAN_TAG_ACTION_T    *ptr_tag_action,
    const UI32_T                   flags,
    HAL_VLAN_VID_CTL_T             *ptr_info);

/* FUNCTION NAME:   [HAL] hal_vm_getSwVidInfo
 * PURPOSE:
 *      Get user view vlan-action of vm-port
 * INPUT:
 *      unit                  -- Device unit number
 *      ptr_vid_ctl           -- HW vlan info
 * OUTPUT:
 *      ptr_vlan_action       -- VLAN action
 *      ptr_tag_action        -- VLAN tag action
 * RETURN:
 *      CLX_E_OK              -- Operate success
 *      CLX_E_ENTRY_NOT_FOUND -- Entry doesn't exist
 *      CLX_E_BAD_PARAMETER   -- Some of inputs are illegal
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getSwVidInfo(
    const UI32_T                unit,
    const HAL_VLAN_VID_CTL_T    *ptr_vid_ctl,
    CLX_VLAN_ACTION_T           *ptr_vlan_action,
    CLX_VLAN_TAG_ACTION_T       *ptr_tag_action);

/* FUNCTION NAME:   [HAL] hal_vm_transToHwEgrInfo
 * PURPOSE:
 *      Translate VM egress user data to HW info.
 * INPUT:
 *      unit                 -- Device unit number
 *      port                 -- uc: vm_port,    mc: native port
 *      vm_type              -- uc: don't care, mc: vm tag type
 *      vm_id                -- uc: don't care, mc: vm id
 * OUTPUT:
 *      ptr_dst_idx (option) -- uc: di,         mc: NULL
 *      ptr_seg_vmid         -- seg_vmid value
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_transToHwEgrInfo(
    const UI32_T               unit,
    const CLX_PORT_T           port,
    const CLX_VM_TAG_TYPE_T    vm_type,
    const UI32_T               vm_id,
    UI32_T                     *ptr_dst_idx,
    UI32_T                     *ptr_seg_vmid);

/* FUNCTION NAME:   [HAL] hal_vm_transToSwEgrInfo
 * PURPOSE:
 *      Translate VM egress HW data to SW info.
 * INPUT:
 *      unit           -- Device unit number
 *      dst_idx        -- dest idx
 *      port_mode      -- hw vm port mode
 *      seg_vmid       -- seg_vmid
 * OUTPUT:
 *      ptr_vm_port    -- uc: vm_port, mc: NULL
 *      ptr_vm_id      -- uc: NULL,    mc: vm id
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_transToSwEgrInfo(
    const UI32_T                     unit,
    const UI32_T                     dst_idx,
    const HAL_VM_PORT_MODE_ENUM_T    port_mode,
    const UI32_T                     seg_vmid,
    CLX_PORT_T                       *ptr_vm_port,
    UI32_T                           *ptr_vm_id);

/* FUNCTION NAME:   [HAL] hal_vm_getPortMode
 * PURPOSE:
 *      Get vm port mode by dst_idx.
 * INPUT:
 *      unit           -- Device unit number
 *      dst_idx        -- dst_idx
 * OUTPUT:
 *      ptr_port_mode  -- hw defined vm port mode
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter if vm mode is not CB_XXX.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_getPortMode(
    const UI32_T               unit,
    const UI32_T               dst_idx,
    HAL_VM_PORT_MODE_ENUM_T    *ptr_port_mode);

/* FUNCTION NAME:   [HAL] hal_vm_checkIsUpstreamSrv
 * PURPOSE:
 *      Check service idx not belongs to vm upstream scenario used.
 * INPUT:
 *      unit           -- Device unit number
 *      srv_idx        -- hw service idx
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK              -- Is vm upstream service.
 *      CLX_E_ENTRY_NOT_FOUND -- Not vm upstream service.
 * NOTES:
 *
 */
CLX_ERROR_NO_T
hal_vm_checkIsUpstreamSrv(
    const UI32_T    unit,
    const UI32_T    srv_idx);

#endif /* HAL_VM_H */