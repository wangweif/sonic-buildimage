/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_up.h
 * PURPOSE:
 *      1. It provides uP download API.
 *
 * NOTES:
 *
 */


#ifndef HAL_LIGHTNING_UP_H
#define HAL_LIGHTNING_UP_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>


/* NAMING CONSTANT DECLARATIONS
 */

/* DATA TYPE DECLARATIONS
 */
typedef enum name
{
    HAL_LIGHTNING_UP_DCE,
    HAL_LIGHTNING_UP_PSYST,
    HAL_LIGHTNING_UP_PSYSP,
    HAL_LIGHTNING_UP_ETHX,
    HAL_LIGHTNING_UP_ETHL,
    HAL_LIGHTNING_UP_LAST
} HAL_LIGHTNING_UP_TYPE_T;

typedef struct
{
    UI32_T M0_CMN_BG_V2VTRIM                : 5;
    UI32_T M0_CMN_BG_V2ITRIM                : 5;
    UI32_T M0_CMN_BG_PTATTRIM               : 5;
    UI32_T resv_15                          : 1;
    UI32_T M0_TX_L0_RESCAL                  : 2;
    UI32_T M0_TX_L1_RESCAL                  : 2;
    UI32_T M0_TX_L2_RESCAL                  : 2;
    UI32_T M0_TX_L3_RESCAL                  : 2;
    UI32_T M0_RX_L0_RTERM_CTRL              : 4;
    UI32_T M0_RX_L1_RTERM_CTRL              : 4;
    UI32_T M0_RX_L2_RTERM_CTRL              : 4;
    UI32_T M0_RX_L3_RTERM_CTRL              : 4;
    UI32_T resv_8                           : 8;
    UI32_T M1_CMN_BG_V2VTRIM                : 5;
    UI32_T M1_CMN_BG_V2ITRIM                : 5;
    UI32_T M1_CMN_BG_PTATTRIM               : 5;
    UI32_T resv_31                          : 1;
    UI32_T M1_TX_L0_RESCAL                  : 2;
    UI32_T M1_TX_L1_RESCAL                  : 2;
    UI32_T M1_TX_L2_RESCAL                  : 2;
    UI32_T M1_TX_L3_RESCAL                  : 2;
    UI32_T M1_RX_L0_RTERM_CTRL              : 4;
    UI32_T M1_RX_L1_RTERM_CTRL              : 4;
    UI32_T M1_RX_L2_RTERM_CTRL              : 4;
    UI32_T M1_RX_L3_RTERM_CTRL              : 4;
    UI32_T resv_24                          : 8;
} HAL_LIGHTNING_UP_ETHL_EFUSE_T;

typedef struct
{
    UI32_T CMN_BG_V2VTRIM                   : 5;
    UI32_T CMN_BG_V2ITRIM                   : 5;
    UI32_T CMN_BG_PTATTRIM                  : 5;
    UI32_T resv_15                          : 1;
    UI32_T TX_L0_RESCAL                     : 2;
    UI32_T TX_L1_RESCAL                     : 2;
    UI32_T RX_L0_RTERM_CTRL                 : 4;
    UI32_T RX_L1_RTERM_CTRL                 : 4;
    UI32_T resv_28                          : 4;
} HAL_LIGHTNING_UP_ETHX_EFUSE_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME:   hal_lightning_up_initEthlSerdesUp
 * PURPOSE:
 *      Download Pdie Serdes uP FW.
 *
 * INPUT:
 *      unit        -- unit index
        die_idx     -- die_id
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_initEthlSerdesUp(
    const UI32_T    unit,
    const UI32_T    die_idx);


CLX_ERROR_NO_T
hal_lightning_up_setEthlSerdesUpHalt(
    const UI32_T    unit,
    const UI32_T    die_idx);

/* FUNCTION NAME:   hal_lightning_up_initEthxSerdesUp
 * PURPOSE:
 *      Download Tdie Serdes uP FW.
 *
 * INPUT:
 *      unit        -- unit index
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_initEthxSerdesUp(
    const UI32_T    unit);


CLX_ERROR_NO_T
hal_lightning_up_setEthxSerdesUpHalt(
    const UI32_T    unit);


/* FUNCTION NAME:   hal_lightning_up_initPsystUp
 * PURPOSE:
 *      Download Tdie port uP FW.
 *
 * INPUT:
 *      unit        -- unit index
  * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_initPsystUp(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_lightning_up_initPsystUpRov
 * PURPOSE:
 *      Download Tdie port uP FW.
 *
 * INPUT:
 *      unit        -- unit index
  * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_initPsystUpRov(
    const UI32_T    unit);

/* FUNCTION NAME:   hal_lightning_up_initPsyspUp
 * PURPOSE:
 *      Download Pdie port uP FW.
 *
 * INPUT:
 *      unit        -- unit index
 *      die_idx     -- die index
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_initPsyspUp(
    const UI32_T    unit,
    const UI32_T    die_idx);

/* FUNCTION NAME:   hal_lightning_up_syncPsyspUpReady
 * PURPOSE:
 *      Notify psyst that psysp is ready for access (link status/link speed/mac activity)
 *
 * INPUT:
 *      unit        -- unit index
 *      die_idx     -- die index
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- sync psysp ready pattern success.
 *      CLX_E_OTHERS -- sync psysp ready pattern fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_syncPsyspUpReady(
    const UI32_T    unit,
    const UI32_T    die_idx);


/* FUNCTION NAME:   hal_lightning_up_initDceUp
 * PURPOSE:
 *      Download DCE uP FW.
 *          Index 0 - for DMA uP
 *          Index 1 - for ZC uP
 *
 * INPUT:
 *      unit        -- unit index
 *      idx         -- uP index:
 *                      Index 0 - for DMA uP
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- download success.
 *      CLX_E_OTHERS -- download fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_initDceUp(
    const UI32_T    unit,
    const UI32_T    idx);

/* FUNCTION NAME:   hal_lightning_up_deinitDceUp
 * PURPOSE:
 *      Deinit DCE uP FW.
 *
 * INPUT:
 *      unit        -- unit index
 *
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK     -- Deinit success.
 *      CLX_E_OTHERS -- Deinit fail.
 *
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_lightning_up_deinitDceUp(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_lightning_up_resetTdieUp(
    const UI32_T    unit);

CLX_ERROR_NO_T
hal_lightning_up_resetPdieUp(
    const UI32_T    unit,
    const UI32_T    die_idx);

#endif /* HAL_LIGHTNING_UP_H */
