/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_tm_sch.h
 * PURPOSE:
 *      It provides hal tm SCH module schedule block API.
 * NOTES:
 *
 *
 */

#ifndef HAL_TM_SCH_H
#define HAL_TM_SCH_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_tm.h>
#include <hal/common/hal_tm.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_TM_SCH_NODE_NUM             (18)
#define HAL_TM_SCH_NODE_RESERVE_NUM     (1)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_TM_SCH_LOCK(unit)        (hal_tm_sch_lockSchResource(unit))
#define HAL_TM_SCH_UNLOCK(unit)      (hal_tm_sch_unLockSchResource(unit))
/* DATA TYPE DECLARATIONS
 */

/* TM EEE Mode */
typedef enum
{
    HAL_TM_EEE_MODE_DISABLE = 0,
    HAL_TM_EEE_MODE_FASTUPDATE,
    HAL_TM_EEE_MODE_DEEPSLEEP,
    HAL_TM_EEE_MODE_LAST,
} HAL_TM_EEE_MODE_T;

typedef enum
{
    HAL_TM_SCH_MINBW_DWRR_COMBINE_MODE_SEPARATE = 0,/*minBW is not counted by dwrr weight*/
    HAL_TM_SCH_MINBW_DWRR_COMBINE_MODE_SHARE,/*minBW is counted by dwrr*/
    HAL_TM_SCH_MINBW_DWRR_COMBINE_MODE_LAST
}HAL_TM_SCH_MINBW_DWRR_COMBINE_MODE_T;

/*property of a scheduele tree node*/
typedef struct HAL_TM_SCH_PROPERTY_S
{
    CLX_TM_BANDWIDTH_T  bandwidth; /*min bandwidth & max bandwidth*/
    CLX_TM_SCH_MODE_T   mode;/*schedule algorithm. sp or dwrr*/
    UI32_T              weight;/*dwrr weight. valid only when mode is dwrr*/
}HAL_TM_SCH_PROPERTY_T;

typedef enum
{
    HAL_TM_SCH_TREE_NODE_TYPE_UNICAST_QUEUE = 0,/*unicast queue*/
    HAL_TM_SCH_TREE_NODE_TYPE_MULTICAST_QUEUE,/*multicast queue*/
    HAL_TM_SCH_TREE_NODE_TYPE_SCHEDULE_NODE,/*schedule node*/
    HAL_TM_SCH_TREE_NODE_TYPE_LAST
}HAL_TM_SCH_TREE_NODE_TYPE_T;

/*include schedule property(sp/dwrr weight/bandwidth)*/
typedef struct HAL_TM_SCH_PORT_PROPERTY_S
{
    /*property of all schedule nodes*/
    HAL_TM_SCH_PROPERTY_T    schedule_node[HAL_TM_SCH_NODE_NUM];
    /*property of all unicast queues*/
    HAL_TM_SCH_PROPERTY_T    unicast_queue[HAL_TM_UNICAST_QUEUE_NUM];
    /*property of all multicast queues*/
    HAL_TM_SCH_PROPERTY_T    multicast_queue[HAL_TM_MULTICAST_QUEUE_NUM];
    CLX_TM_BANDWIDTH_T          port_shaping;
}HAL_TM_SCH_PORT_PROPERTY_T;

/*include topology information and property information*/
typedef struct HAL_TM_SCH_TREE_NODE_INFO_S
{
    /*indicate this node is for unicast queue or
     *multicat queue or schedule node*/
    HAL_TM_SCH_TREE_NODE_TYPE_T             type;
    /*indicate if this node has been created by user*/
    BOOL_T                                      is_valid;
    /*indicate is this node has been attached to
     *a hardware queue or hardware node*/
    BOOL_T                                      is_hw_allocate;
    /*indicate this node's schedule level*/
    UI32_T                                      hw_level_id;
    /*indicate the hardware node id attached by this node*/
    UI32_T                                      hw_node_id;
    /*this node's children id as this node is
     *another node's children*/
    UI32_T                                      hw_parent_input_id;
    /*point to the parent of this node*/
    struct HAL_TM_SCH_TREE_NODE_INFO_S      *ptr_parent_node;
    /*point to the head of a list which
     *listed all childrens of this node*/
    struct HAL_TM_SCH_TREE_NODE_INFO_S      *ptr_child_node;
    /*point to neighboring node which anear to
     *the head of its parent's children list*/
    struct HAL_TM_SCH_TREE_NODE_INFO_S      *ptr_left_sibling_node;
    /*point to neighboring node which anear to
     *the tail of its parent's children list*/
    struct HAL_TM_SCH_TREE_NODE_INFO_S      *ptr_right_sibling_node;
    /*children sequence.A node's parent may has
    *many childrens.Each children will has its
    *schedule_sequence.This is useful when these
    *childrens are working in sp algorithm.A larger
    *schedule_sequence means a higher priority.*/
    UI32_T                                      schedule_sequence;
}HAL_TM_SCH_TREE_NODE_INFO_T;

/*per port informaion include all information of its queues and
 *schedule nodes and other information*/
typedef struct HAL_TM_SCH_PORT_SW_INFO_S
{
    /*TRUE means topology is traditional;
     *FALSE means user defined topology*/
    BOOL_T                              legacy_mode;
    /*all schedule node*/
    HAL_TM_SCH_TREE_NODE_INFO_T     schedule_node[HAL_TM_SCH_NODE_NUM];
    /*all unicast queues*/
    HAL_TM_SCH_TREE_NODE_INFO_T     unicast_queue[HAL_TM_UNICAST_QUEUE_NUM];
    /*all multicast queues*/
    HAL_TM_SCH_TREE_NODE_INFO_T     multicast_queue[HAL_TM_MULTICAST_QUEUE_NUM];
}HAL_TM_SCH_PORT_SW_INFO_T;

typedef struct HAL_TM_SCH_CPU_PORT_PROPERTY_S
{
    /*cpu port's max bandwidth*/
    CLX_TM_BANDWIDTH_T              cpu_port_shaping;
    /*property of all cpu queues*/
    HAL_TM_SCH_PROPERTY_T       cpu_queue_property[HAL_TM_CPU_QUEUE_NUM];
}HAL_TM_SCH_CPU_PORT_PROPERTY_T;

typedef struct HAL_TM_SCH_CPI_PORT_PROPERTY_S
{
    /*cpu port's max bandwidth*/
    CLX_TM_BANDWIDTH_T              cpi_port_shaping;
    /*property of all cpu queues*/
    HAL_TM_SCH_PROPERTY_T       cpi_queue_property[HAL_TM_CPI_QUEUE_NUM];
}HAL_TM_SCH_CPI_PORT_PROPERTY_T;

typedef struct HAL_TM_HW_BANDWIDTH_S
{
    UI32_T  shape_min;/*hardware view based min Bandwidth*/
    UI32_T  shape_max;/*hardware view based max Bandwidth*/
    UI32_T  bsize_min;/*hardware view based bucket size of min bandwidth*/
    UI32_T  bsize_max;/*hardware view based bucket size of max bandwidth*/
}HAL_TM_HW_BANDWIDTH_T;


/*control block for sch module*/
typedef struct HAL_TM_SCHEDULE_CB_S
{
    /*front-plane-ports*/
    /*array, index by port_id*/
    HAL_TM_SCH_PORT_SW_INFO_T           *ptr_fp_sch_info;

    /*semaphore for schedule module*/
    /*semaphore for schedule block*/
    CLX_SEMAPHORE_ID_T                     sch_sema;
}HAL_TM_SCHEDULE_CB_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

extern CLX_ERROR_NO_T
hal_tm_getSchCtrlBlock(
    const UI32_T                unit,
    HAL_TM_SCHEDULE_CB_T        **pptr_cb);

/* FUNCTION NAME:   hal_tm_sch_initRsrc
* PURPOSE:
*      Init tm module sch software shadow and hardware shadow.
*
* INPUT:
*      unit        --  Device unit number.
* OUTPUT:
*      None
* RETURN:
*      CLX_E_OK    --  Operate success.
*      CLX_E_OTHER --  Init fail.
*
* NOTES:
*      This function will allocate memory.
*/
CLX_ERROR_NO_T
hal_tm_sch_initRsrc(
    const UI32_T                unit);


/* FUNCTION NAME:   hal_tm_sch_initThread
 * PURPOSE:
 *      Init Thread.
 *
 * INPUT:
 *      unit         --  Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     --  initialize success.
 *      CLX_E_OTHERS -- initialize failed.
 *
 * NOTES:
 *     No thread.
 */
CLX_ERROR_NO_T
hal_tm_sch_initThread(
    const UI32_T                unit);

/* FUNCTION NAME:   hal_tm_sch_deinitRsrc
 * PURPOSE:
 *     Deinit tm module sch software shadow and hardware shadow.
 *
 * INPUT:
 *     unit        --  Device unit number.
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK    --  Operate success.
 *     CLX_E_OTHER --  Init fail.
 *
 * NOTES:
 *     This function will free memory.
 */
CLX_ERROR_NO_T
hal_tm_sch_deinitRsrc(
    const UI32_T                unit);

/* FUNCTION NAME:   hal_tm_sch_deinitCfg
 * PURPOSE:
 *     Deinit tm module sch configuration.
 * INPUT:
 *     unit        --  Device unit number.
 * OUTPUT:
 *     None
 * RETURN:
 *     CLX_E_OK    --  Operate success.
 *     CLX_E_OTHER --  Init fail.
 *
 * NOTES:
 *     None.
 */
CLX_ERROR_NO_T
hal_tm_sch_deinitCfg(
    const UI32_T                unit);


/* FUNCTION NAME:   hal_tm_sch_deinitThread
 * PURPOSE:
 *      DeInit Thread.
 *
 * INPUT:
 *      unit         -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Deinitialize success.
 *      CLX_E_OTHERS -- Deinitialize failed.
 *
 * NOTES:
 *      No thread.
 */
CLX_ERROR_NO_T
hal_tm_sch_deinitThread(
    const UI32_T                unit);

/* FUNCTION NAME:   hal_tm_sch_lockSchResource
 * PURPOSE:
 *      Lock semaphore of tm schedule block.
 *
 * INPUT:
 *      unit         -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_tm_sch_lockSchResource(
    const UI32_T            unit);

/* FUNCTION NAME:   hal_tm_sch_unLockSchResource
 * PURPOSE:
 *      Unlock semaphore of tm schedule block.
 *
 * INPUT:
 *      unit         -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      None.
 */
CLX_ERROR_NO_T
hal_tm_sch_unLockSchResource(
    const UI32_T            unit);

/* FUNCTION NAME:   hal_tm_sch_createHandler
 * PURPOSE:
 *      create handler.
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      port         -- Egress physical port id.
 *      handler_type -- Type of handler to be created.
 *      queue_id     -- Physical queue id. valid only when handler_type is
 *                      CLX_TM_HANDLER_TYPE_UNICAST_QUEUE or
 *                      CLX_TM_HANDLER_TYPE_MULTICAST_QUEUE.
 * OUTPUT:
 *      ptr_handler  -- Handler of sdk created
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      This function should be called first if user want to
 *      use user-define-topology.
 */
CLX_ERROR_NO_T
hal_tm_sch_createHandler(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_TM_HANDLER_TYPE_T     handler_type,
    const UI32_T                    queue_id,
    CLX_TM_HANDLER_T                *ptr_handler) ;

/* FUNCTION NAME:   hal_tm_sch_deleteHandler
 * PURPOSE:
 *      Delete handler.
 *
 * INPUT:
 *      unit         -- Device unit number.
 *      port         -- Physical port id.
 *      handler      -- Hander to be deleted.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK     -- Success.
 *      CLX_E_OTHERS -- Failed.
 *
 * NOTES:
 *      Only when a handler is not used by user-defined-topology
 *      can it be deleted.
 */
CLX_ERROR_NO_T
hal_tm_sch_deleteHandler(
    const UI32_T                    unit,
    const UI32_T                    port,
    const CLX_TM_HANDLER_T          handler);

/* FUNCTION NAME:   hal_tm_sch_setCosqMapping
 * PURPOSE:
 *      Configure the mapping of tc to queue_id per egress port.
 * INPUT:
 *      unit                -- Device unit number.
 *      port                -- Egress physical port id which to be written.
 *      tc                  -- Traffic class to be mapped.
 *      type                -- The type of the handler. must be unicast queue
 *                             or multicast queue.
 *      handler             -- The handler of the queue mapped out.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK            -- Operate success.
 *      CLX_E_BAD_PARAMETER -- Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_tm_sch_setTcQueueMapping(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    tc,
    const CLX_TM_HANDLER_TYPE_T     type,
    const CLX_TM_HANDLER_T          handler);

/* FUNCTION NAME:   hal_tm_sch_getCosqMapping
 * PURPOSE:
 *      Get the mapping of tc to queue_id for the specified port and
 *      specified tc.
 * INPUT:
 *      unit                --  Device unit number.
 *      port                --  Egress port
 *      tc                  --  Trffic class to be mapped.
 * OUTPUT:
 *      queue_id            --  The queue_id which packets with traffic class
 *                              "tc" should go to.
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_tm_sch_getTcQueueMapping(
    const UI32_T                    unit,
    const UI32_T                    port,
    const UI32_T                    tc,
    const CLX_TM_HANDLER_TYPE_T     type,
    CLX_TM_HANDLER_T                *ptr_handler);

/* FUNCTION NAME:   hal_tm_sch_setQueueEnable
 * PURPOSE:
 *      Set schedule queue enable.
 * INPUT:
 *      unit                --  Device unit number.
 *      port                --  Egress port
 *      handler             --  Handler user wants to control.
 *      enable              --  Queue enable or not
 * OUTPUT:
 *      NONE.
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_tm_sch_setQueueEnable(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler,
    const UI32_T            enable);

/* FUNCTION NAME:   hal_tm_sch_getQueueEnable
 * PURPOSE:
 *      Get schedule queue enable.
 * INPUT:
 *      unit                --  Device unit number.
 *      port                --  Egress port
 *      handler             --  Handler user wants to control.
 * OUTPUT:
 *      ptr_enable          --  Queue enable or not
 * RETURN:
 *      CLX_E_OK            --  Operate success.
 *      CLX_E_BAD_PARAMETER --  Bad parameter.
 * NOTES:
 *      NONE.
 */
CLX_ERROR_NO_T
hal_tm_sch_getQueueEnable(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler,
    UI32_T                  *ptr_enable);

CLX_ERROR_NO_T
hal_tm_sch_dumpDb(
    const UI32_T    unit);


#endif /* End of HAL_TM_SCH_H */

