/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_lightning_tm_buf_buf.h
 * PURPOSE:
 *      It provides hal traffic management module API.
 * NOTES:
 *
 *
 */

#ifndef HAL_LIGHTNING_TM_BUF_H
#define HAL_LIGHTNING_TM_BUF_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <clx_tm.h>
#include <osal/osal.h>
#include <hal/common/hal_tbl.h>
#include <hal/common/hal.h>
#include <hal/common/hal_const_cmn.h>

/* NAMING CONSTANT DECLARATIONS
 */

#define HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_GREEN         (32)
#define HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_RED           (32)
#define HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_NON_TCP_YELLOW        (32)
#define HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN             (32)
#define HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_RED               (32)
#define HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_YELLOW            (32)
#define HAL_LIGHTNING_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE                       (32)

#define HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_MAX_THRESHOLD_WIDTH              (16)
#define HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH                   (10)
#define HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH                   (6)

#define HAL_LIGHTNING_TM_IA_P_PLANE_NUM               (1)
#define HAL_LIGHTNING_TM_IA_P_SLICE_NUM               (8)
#define HAL_LIGHTNING_TM_ADM_SLICE_NUM                (1)
#define HAL_LIGHTNING_TM_ADM_PLANE_NUM                (1)

#define HAL_LIGHTNING_TM_MIA_SLICE_NUM                (2)
#define HAL_LIGHTNING_TM_MEA_P_SLICE_NUM              (2)
#define HAL_LIGHTNING_TM_MEA_G_SLICE_NUM              (1)

#define HAL_LIGHTNING_TM_MAX_PFC_SC_NUM               (2)
#define HAL_LIGHTNING_TM_ADM_SC_NUM                   (8)

#define HAL_LIGHTNING_TM_BUF_FC_LOSSLESS_IDX          (0)
#define HAL_LIGHTNING_TM_BUF_FC_SC                    (7)
#define HAL_LIGHTNING_TM_BUF_PFC_SC                   (6)

#define HAL_LIGHTNING_TM_BUF_DCTCP_FIX_MODE           (0)
#define HAL_LIGHTNING_TM_BUF_DCTCP_PC_MODE            (1)
#define HAL_LIGHTNING_TM_BUF_DCTCP_PC_MAX             (256)


#define HAL_LIGHTNING_TM_ADM_DP_AIP_CPI_IDX           (256)
#define HAL_LIGHTNING_TM_ADM_DP_AIP_PICE_IDX          (264)

#define HAL_LIGHTNING_TM_AIP_CPI_IDX                  (32)
#define HAL_LIGHTNING_TM_AIP_PICE_IDX                 (33)


#define HAL_LIGHTNING_TM_ADM_DP_FP_NUM                (32)


#define HAL_LIGHTNING_TM_EA_Q_MIN                     (18)

#define HAL_LIGHTNING_TM_ADM_HRM                      (280)
#define HAL_LIGHTNING_TM_OP_HRM                       (1640)
#define HAL_LIGHTNING_TM_GCM_HRM                      (112)
#define HAL_LIGHTNING_TM_GCM_BW_HRM                   (152)
#define HAL_LIGHTNING_TM_RCM_HRM                      (204)

#define HAL_LIGHTNING_TM_EA_FP_NUM                    (8)
#define HAL_LIGHTNING_TM_EA_ETH_CPI_IDX               (HAL_LIGHTNING_TM_EA_FP_NUM)
#define HAL_LIGHTNING_TM_EA_AOQ_MC_MAP_IDX            (108)


#define HAL_LIGHTNING_TM_DP_IA_NUM                    (8)

#define HAL_LIGHTNING_TM_SLICE_IA_ENTRY_NUM           (34)

#define HAL_LIGHTNING_TM_EA_ETH_CPI_SLICE_IDX_0       (3)
#define HAL_LIGHTNING_TM_EA_ETH_CPI_SLICE_IDX_1       (7)


#define HAL_LIGHTNING_TM_FP_MACRO                     (4)

#define HAL_LIGHTNING_TM_DP_NUM                       (2)

#define HAL_LIGHTNING_TM_EA_GROUP_MAX                 (8)

#define HAL_LIGHTNING_TM_EA_UC_SCG_NUM                (8)
#define HAL_LIGHTNING_TM_EA_MC_SCG_NUM_FF_MODE        (4)
#define HAL_LIGHTNING_TM_EA_MC_SCG_NUM_ZE_MODE        (8)

#define HAL_LIGHTNING_TM_EA_AOP_MC_MAP_IDX            (9)


#define HAL_LIGHTNING_TM_EA_CMQ_CPU_NUM               (HAL_LIGHTNING_TM_CPU_QUEUE_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_CPI_NUM               (HAL_LIGHTNING_TM_CPI_QUEUE_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_MIR_NUM               (8)

#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_CPU            (0)
#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_LCPI0          (HAL_LIGHTNING_TM_EA_CMQ_OFFSET_CPU + HAL_LIGHTNING_TM_EA_CMQ_CPU_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_LCPI1          (HAL_LIGHTNING_TM_EA_CMQ_OFFSET_LCPI0 + HAL_LIGHTNING_TM_EA_CMQ_CPI_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_RCPI0          (HAL_LIGHTNING_TM_EA_CMQ_OFFSET_LCPI1 + HAL_LIGHTNING_TM_EA_CMQ_CPU_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_RCPI1          (HAL_LIGHTNING_TM_EA_CMQ_OFFSET_RCPI0 + HAL_LIGHTNING_TM_EA_CMQ_CPI_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_IMIR           (HAL_LIGHTNING_TM_EA_CMQ_OFFSET_RCPI1 + HAL_LIGHTNING_TM_EA_CMQ_CPI_NUM)
#define HAL_LIGHTNING_TM_EA_CMQ_OFFSET_EMIR           (HAL_LIGHTNING_TM_EA_CMQ_OFFSET_IMIR + HAL_LIGHTNING_TM_EA_CMQ_MIR_NUM)

#define HAL_LIGHTNING_TM_ADM_P_SUB_INST_IDX           (0)

#define HAL_LIGHTNING_TM_DP_Q_NUM                     (HAL_LIGHTNING_TM_EA_UC_SCG_NUM * HAL_LIGHTNING_TM_ADM_DP_FP_NUM * 2)
#define HAL_LIGHTNING_TM_DP_ETH_CPI_0_IDX             (HAL_LIGHTNING_TM_DP_Q_NUM)
#define HAL_LIGHTNING_TM_DP_ETH_CPI_1_IDX             (HAL_LIGHTNING_TM_DP_Q_NUM + HAL_LIGHTNING_TM_EA_UC_SCG_NUM)


#define HAL_LIGHTNING_TM_IA_XON_TH                    (300)
#define HAL_LIGHTNING_TM_IA_XOFF_TH                   (600)
#define HAL_LIGHTNING_TM_DP_IA_HR_TH                  (600)
#define HAL_LIGHTNING_TM_DP_IA_MIN_TH                 (1152)


#define HAL_LIGHTNING_TM_MIR_SESSION_NUM              (8)


#define HAL_LIGHTNING_TM_IOS_IA_SC2PCP_CPI_IDX        (0)
#define HAL_LIGHTNING_TM_IOS_IA_SC2PCP_PCIE_IDX       (1)
#define HAL_LIGHTNING_TM_IOS_IA_SC2PCP_NUM            (32)


#define HAL_LIGHTNING_TM_IOS_COS_NUM                  (4)
#define HAL_LIGHTNING_TM_IOS_SLC_CPI_IDX              (1)
#define HAL_LIGHTNING_TM_IOS_SLC_PCIE_IDX             (0)
#define HAL_LIGHTNING_TM_IOS_SLC_NUM                  (4)
#define HAL_LIGHTNING_TM_IOS_SLC_PORT_NUM             (HAL_LIGHTNING_TM_IOS_IA_SC2PCP_NUM / HAL_LIGHTNING_TM_IOS_SLC_NUM)

#define HAL_LIGHTNING_TM_PERCNTAGE                    (100)
#define HAL_LIGHTNING_TM_IEA_Q_MIN_CEILING            (0x7FFF)

#define HAL_LIGHTNING_TM_IEA_UNIT                     (1)
#define HAL_LIGHTNING_TM_IA_MAX_DYNAMIC_TH            (2)
#define HAL_LIGHTNING_TM_EA_MAX_DYNAMIC_TH            (2048)

#define HAL_LIGHTNING_TM_EA_MC_MAX_DYNAMIC_TH         (2)

#define HAL_LIGHTNING_TM_PCP_NUM                      (8)
#define HAL_LIGHTNING_TM_DSCP_NUM                     (64)

#define HAL_LIGHTNING_TM_EA_G_STR_TH                  (256)

#define HAL_LIGHTNING_TM_EA_CMQ_NUM                   (96)
#define HAL_LIGHTNING_TM_EA_CMQ_TH                    (18)

#define HAL_LIGHTNING_TM_EA_G_CM_POOL                 (HAL_LIGHTNING_TM_EA_CMQ_NUM * HAL_LIGHTNING_TM_EA_CMQ_TH \
                                                + HAL_LIGHTNING_TM_EA_G_STR_TH)

#define HAL_LIGHTNING_TM_SC_BITMAP                    (0xFF)
#define HAL_LIGHTNING_TM_CELL_SIZE                    (520)

#define HAL_LIGHTNING_TM_MTU                          ((22 * 1024 + 9) / 10)
#define HAL_LIGHTNING_TM_GAP                          (60)

#define HAL_LIGHTNING_TM_BUF_FP_PORT_MAX_NUM          (256)
#define HAL_LIGHTNING_TM_DEB_FP_NUM                   (32)
#define HAL_LIGHTNING_TM_IA_FP_NUM                    (32)


/* max value, Limit by HW design. */
#define HAL_LIGHTNING_TM_IA_MAX_DYNAMIC_VALUE         (12)
#define HAL_LIGHTNING_TM_IA_MAX_DYNAMIC_VALUE_OFFSET  (0)
#define HAL_LIGHTNING_TM_EA_MAX_DYNAMIC_VALUE         (12)
#define HAL_LIGHTNING_TM_EA_MAX_DYNAMIC_VALUE_OFFSET  (0)


#define HAL_LIGHTNING_TM_WRED_PROFILE_SW_NUM          (HAL_LIGHTNING_MAX_NUM_OF_TM_WRED_PROFILE_CONFIG_TCP_GREEN)

#define HAL_LIGHTNING_TM_DCTCP_PROFILE_SW_NUM         (HAL_LIGHTNING_MAX_NUM_OF_TM_DCTCP_THD_G_PROFILE)

/* WRED SMDP */
#define HAL_LIGHTNING_TM_UI16_WIDTH                   (16)
#define HAL_LIGHTNING_TM_UI16_MAX_VALUE               ((1U << (HAL_LIGHTNING_TM_UI16_WIDTH)) - 1)
#define HAL_LIGHTNING_TM_WRED_MAX_EXPONENT_SIGN_BIT   (1U << ((HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH) - 1))
#define HAL_LIGHTNING_TM_WRED_MAX_EXPONENT_VALUE      ((1U << ((HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_EXPONENT_WIDTH) \
                                                - 1)) - 1)
#define HAL_LIGHTNING_TM_WRED_MAX_MANTISSA_VALUE      ((1U << (HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH)) - 1)
#define HAL_LIGHTNING_TM_UI16_TO_MANTISSA_SHIFT       (HAL_LIGHTNING_TM_UI16_WIDTH \
                                                - (HAL_LIGHTNING_TM_WRED_PROFILE_CONFIG_MANTISSA_WIDTH))

#define HAL_LIGHTNING_TM_WRED_PROFILE_MAX_DROP_RATE   (100)
#define HAL_LIGHTNING_TM_WRED_Q_WEIGHT_VALUE_SW_MAX   (10000)
#define HAL_LIGHTNING_TM_WRED_Q_WEIGHT_VALUE_HW_MAX   (7) /* weight min = 1/2^HAL_LIGHTNING_TM_WRED_Q_WEIGHT_VALUE_HW_MAX */


#define HAL_LIGHTNING_TM_WRED_PROFILE_ID_MAX          (HAL_LIGHTNING_TM_WRED_PROFILE_SW_NUM - 1)
#define HAL_LIGHTNING_TM_DCTCP_PROFILE_ID_MAX         (HAL_LIGHTNING_TM_DCTCP_PROFILE_SW_NUM - 1)

#define HAL_LIGHTNING_TM_WRED_PF_MAX_DROP             (100)

#define HAL_LIGHTNING_TM_GLOBAL_ECN_HWTH              (0x200)


/* DCTCP */
#define HAL_LIGHTNING_TM_DCTCP_PF_TH_G                (0)
#define HAL_LIGHTNING_TM_DCTCP_PF_TH_Y                (16)
#define HAL_LIGHTNING_TM_DCTCP_PF_TH_R                (32)

#define HAL_LIGHTNING_TM_IOS_SLC_CELL         (4092)
#define HAL_LIGHTNING_TM_IOS_SLC_HW           (144)
#define HAL_LIGHTNING_TM_IOS_SLC_SHARE        (3372) /* VCELL - VHW - SUM(all active FPC_MIN and FCC_MIN) */
#define HAL_LIGHTNING_TM_IOS_SLC_HRM          (2393) /* SUM(active port number * VFPC_HRM). Worst case is 4x100G+25G CPI in a FPS = 544*4+217=2393 */
#define HAL_LIGHTNING_TM_IOS_SLC_FREE         (HAL_LIGHTNING_TM_IOS_SLC_SHARE - HAL_LIGHTNING_TM_IOS_SLC_HRM) /* VSHARE - VHRM */
#define HAL_LIGHTNING_TM_IOS_SLC_GAP          (180)
#define HAL_LIGHTNING_TM_IOS_SLC_XON          (HAL_LIGHTNING_TM_IOS_SLC_FREE - HAL_LIGHTNING_TM_IOS_SLC_GAP) /* VFREE-VGAP */
#define HAL_LIGHTNING_TM_IOS_SLC_LL_SHARE     (HAL_LIGHTNING_TM_IOS_SLC_SHARE)
#define HAL_LIGHTNING_TM_IOS_SLC_LL_FREE      (HAL_LIGHTNING_TM_IOS_SLC_FREE)
#define HAL_LIGHTNING_TM_IOS_SLC_LS_SHARE     (HAL_LIGHTNING_TM_IOS_SLC_FREE)


#define HAL_LIGHTNING_TM_IOS_SLC_FPC_GAP      (20)
#define HAL_LIGHTNING_TM_IOS_SLC_FPC_MIN      (16)
#define HAL_LIGHTNING_TM_IOS_SLC_FPC_DYN      (8)


#define HAL_LIGHTNING_TM_IOS_FPC_HRM_400G     (HAL_LIGHTNING_TM_IOS_SLC_LS_SHARE - HAL_LIGHTNING_TM_IOS_SLC_FPC_GAP)
#define HAL_LIGHTNING_TM_IOS_FPC_HRM_200G     (896)
#define HAL_LIGHTNING_TM_IOS_FPC_HRM_100G     (544)
#define HAL_LIGHTNING_TM_IOS_FPC_HRM_50G      (255)
#define HAL_LIGHTNING_TM_IOS_FPC_HRM_40G      (281)
#define HAL_LIGHTNING_TM_IOS_FPC_HRM_25G      (217)
#define HAL_LIGHTNING_TM_IOS_FPC_HRM_10G      (152)

#define HAL_LIGHTNING_TM_MAX_BIN_CNT          (4)

typedef enum
{
    HAL_LIGHTNING_TM_TYPE_ING  = 0,
    HAL_LIGHTNING_TM_TYPE_EGR  = 1,
    HAL_LIGHTNING_TM_TYPE_LAST
} HAL_LIGHTNING_TM_TYPE_T;


typedef enum
{
    HAL_LIGHTNING_TM_EA_CMP_CPU  = 0,
    HAL_LIGHTNING_TM_EA_CMP_CPI0  = 1,
    HAL_LIGHTNING_TM_EA_CMP_CPI1  = 2,
    HAL_LIGHTNING_TM_EA_CMP_IMIR  = 3,
    HAL_LIGHTNING_TM_EA_CMP_EMIR  = 4,
    HAL_LIGHTNING_TM_EA_CMP_LAST
} HAL_LIGHTNING_TM_EA_CMP_T;

typedef enum
{
    HAL_LIGHTNING_TM_IA_P_FP      = 0,
    HAL_LIGHTNING_TM_IA_P_CPI0    = 1,
    HAL_LIGHTNING_TM_IA_P_CPI1    = 2,
    HAL_LIGHTNING_TM_IA_P_IMIR    = 3,
    HAL_LIGHTNING_TM_IA_P_EMIR    = 4,
    HAL_LIGHTNING_TM_EA_P_LAST
} HAL_LIGHTNING_TM_IA_P_T;

typedef enum
{
    HAL_LIGHTNING_TM_GRP_FP_UC   = 0,
    HAL_LIGHTNING_TM_GRP_FP_MC   = 1,
    HAL_LIGHTNING_TM_GRP_LCL     = 2,
    HAL_LIGHTNING_TM_GRP_CPU     = 3,
    HAL_LIGHTNING_TM_GRP_PCIE    = 4,
    HAL_LIGHTNING_TM_GRP_MIR     = 5,
    HAL_LIGHTNING_TM_GRP_LAST
} HAL_LIGHTNING_TM_GRP_T;


typedef enum
{
    HAL_LIGHTNING_TM_ADM_SC_TYPE_LOSSY    = 0x0,
    HAL_LIGHTNING_TM_ADM_SC_TYPE_LOSSLESS = 0x2,
    HAL_LIGHTNING_TM_ADM_SC_TYPE_CTRL     = 0x3,
    HAL_LIGHTNING_TM_ADM_SC_TYPE_LAST
} HAL_LIGHTNING_TM_ADM_SC_TYPE_T;

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_LIGHTNING_TM_HANDLER_ID_GET(handler, id) do {                   \
        (id) = ((handler) & ((1U << HAL_LIGHTNING_TM_HANDLER_TYPE_SHIFT) - 1)); \
    } while(0)


/* DATA TYPE DECLARATIONS
 */
typedef enum
{
    HAL_LIGHTNING_TM_BUF_RELEASE_NONE           = 0,
    HAL_LIGHTNING_TM_BUF_RELEASE_SEMAPHORE      = (1U << 0),
    HAL_LIGHTNING_TM_BUF_RELEASE_RESOURCE_1     = (1U << 1),
    HAL_LIGHTNING_TM_BUF_RELEASE_RESOURCE_2     = (1U << 2),
    HAL_LIGHTNING_TM_BUF_RELEASE_LAST           = (1U << 3)
} HAL_LIGHTNING_TM_BUF_RELEASE_ACTION_T;

/* HAL layer API structure */
typedef struct HAL_LIGHTNING_TM_WRED_ENTRY_HW_S {
    UI32_T hw_min;
    UI32_T hw_max;
    UI32_T hw_mantissa;
    UI32_T hw_exponent;
} HAL_LIGHTNING_TM_WRED_ENTRY_HW_T;

typedef struct HAL_LIGHTNING_TM_DCTCP_PROFILE_HW_S {
    UI32_T hw_threshold[CLX_COLOR_LAST];
} HAL_LIGHTNING_TM_DCTCP_PROFILE_HW_T;


typedef enum
{
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST0_SS0 = 0,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST0_SS1,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST1_SS0,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST1_SS1,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST2_SS0,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST2_SS1,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST3_SS0,
    HAL_TM_SNAPSHOT_INTR_EA_GLB_INST3_SS1,
    HAL_TM_SNAPSHOT_INTR_TYPE_LAST
} HAL_TM_SNAPSHOT_INTR_TYPE_T;


typedef struct HAL_TM_MBURST_DATA_S {
            UI32_T max_cell;
            UI32_T dwin_start;
            UI32_T dwin_end;
} HAL_TM_MBURST_DATA_T;

typedef struct HAL_TM_MBURST_INFO_S {
            UI32_T pool_id;
            UI32_T total_cell;
            UI32_T uburst_total_cell;
            UI32_T uburst_total_dwin;
            UI32_T uburst_total_cnt;
            HAL_TM_MBURST_DATA_T data[3];
} HAL_TM_MBURST_INFO_T;


typedef struct HAL_IGR_TM_MBURST_INFO_S {
            UI32_T pool_cnt;
            HAL_TM_MBURST_INFO_T pool_info[4];
} HAL_TM_IGR_MBURST_INFO_T;


/*********************************************/
/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* FUNCTION NAME: hal_lightning_tm_buf_initRsrc
 * PURPOSE:
 *      The function is used to init TM buffer management HW & SW DB
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_initRsrc(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_lightning_tm_buf_deinitRsrc
 * PURPOSE:
 *      The function is used to deinit TM buffer management HW & SW DB
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_deinitRsrc(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_lightning_tm_buf_initCfg
 * PURPOSE:
 *      The function is used to init TM buffer management configuration
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_initCfg(
    const UI32_T                            unit);

/* FUNCTION NAME: hal_lightning_tm_buf_setFlowCtrlMode
 * PURPOSE:
 *      The function is used to set flow control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      mode             -- flow control mode(lossy, FC, PFC)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setFlowCtrlMode(
    const UI32_T                            unit,
    const UI32_T                            port,
    const HAL_TM_FC_T                       mode);

/* FUNCTION NAME: hal_lightning_tm_buf_setIgrBufPcpThreshold
 * PURPOSE:
 *      The function is used to set ingress buffer per pcp thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp value.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setIgrBufPcpThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pcp,
    const CLX_TM_BUF_THRESHOLD_T            *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_updateQueueState
 * PURPOSE:
 *      The function is used to update the port status with action for non-block used.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      dir              -- direction (CLX_DIR_INGRESS, CLX_DIR_EGRESS, CLX_DIR_BOTH).
 *      status           -- action (HAL_LIGHTNING_TM_PS_ACTIVED, HAL_LIGHTNING_TM_PS_NO_ACTIVED)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_updateQueueState(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_DIR_T                         dir,
    const HAL_TM_SC_T                       status,
    const UI32_T                            all_queue,
    const CLX_TM_HANDLER_T                  handler);


/* FUNCTION NAME: hal_lightning_tm_buf_getIgrBufPcpThreshold
 * PURPOSE:
 *      The function is used to get ingress buffer per pcp thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pfc_pcp          -- pfc pcp value.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */

CLX_ERROR_NO_T
hal_lightning_tm_buf_getIgrBufPcpThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pcp,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_getIgrBufPcpRemap
 * PURPOSE:
 *      The function is used to get orginal pcp remap to ingress buffer pcp
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      org_pcp          -- orginal pcp.
 * OUTPUT:
 *      ptr_ingbuf_pcp   -- ingress buffer pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getIgrBufPcpRemap(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            org_pcp,
    UI32_T                                  *ptr_ingbuf_pcp);

/* FUNCTION NAME: hal_lightning_tm_buf_setEgrBufQueueThreshold
 * PURPOSE:
 *      The function is used to set egress buffer per queue thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- tm handler.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setEgrBufQueueThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const CLX_TM_BUF_THRESHOLD_T            *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_getEgrBufQueueThreshold
 * PURPOSE:
 *      The function is used to get egress buffer per queue thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- tm handler.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufQueueThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_setEgrBufPortThreshold
 * PURPOSE:
 *      The function is used to set egress buffer per port thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      ptr_entry        -- the entry which the user want to set.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setEgrBufPortThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_getEgrBufPortThreshold
 * PURPOSE:
 *      The function is used to get egress buffer per port thresholds.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 * OUTPUT:
 *      ptr_entry        -- the entry which the user want to get.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufPortThreshold(
    const UI32_T                            unit,
    const UI32_T                            port,
    CLX_TM_BUF_THRESHOLD_T                  *ptr_entry);


/* FUNCTION NAME: hal_lightning_tm_buf_getEgrBufPfcPcpRemapQueue
 * PURPOSE:
 *      The function is used to get the pcp which received from PFC pause frame
 *      remap to which egress queue.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pfc_pcp          -- The pcp which received from PFC pause frame.
 * OUTPUT:
 *      ptr_handler      -- Egress queue handler.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufPfcPcpRemapQueue(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pfc_pcp,
    CLX_TM_HANDLER_T                        *ptr_handler);


/* FUNCTION NAME: hal_lightning_tm_buf_setCngCtrl
 * PURPOSE:
 *      The function is used to set queue TM congestion control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      mode             -- TM congestion control mode
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER           --  Other error
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setCngCtrl(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const CLX_TM_CNG_T                      mode);

/* FUNCTION NAME: hal_lightning_tm_buf_getCngCtrl
 * PURPOSE:
 *      The function is used to get queue TM congestion control mode.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_mode         -- TM congestion control mode
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getCngCtrl(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    CLX_TM_CNG_T                            *ptr_mode);

/* FUNCTION NAME: hal_lightning_tm_buf_getWredProfile
 * PURPOSE:
 *      The function is used to get WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 *      type             -- traffic type.
 *      color            -- traffic color.
 * OUTPUT:
 *      ptr_entry        -- WRED profile entry.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_TRAFFIC_TYPE_T             type,
    const CLX_COLOR_T                       color,
    CLX_TM_WRED_ENTRY_T                     *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_createWredProfile
 * PURPOSE:
 *      The function is used to create WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_createWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_lightning_tm_buf_setWredProfile
 * PURPOSE:
 *      The function is used to set WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 *      type             -- traffic type.
 *      color            -- traffic color.
 *      ptr_entry        -- WRED profile entry.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_TRAFFIC_TYPE_T             type,
    const CLX_COLOR_T                       color,
    const CLX_TM_WRED_ENTRY_T               *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_delWredProfile
 * PURPOSE:
 *      The function is used to delete WRED profile
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- WRED profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_delWredProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_lightning_tm_buf_setWredQueueConfig
 * PURPOSE:
 *      The function is used to set per queue WRED configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      ptr_entry        -- WRED configuration of egress queue.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setWredQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const CLX_TM_WRED_QUEUE_CFG_T           *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_getWredQueueConfig
 * PURPOSE:
 *      The function is used to get per queue WRED configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_entry        -- WRED configuration of egress queue.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getWredQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    CLX_TM_WRED_QUEUE_CFG_T                 *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_getDctcpProfile
 * PURPOSE:
 *      The function is used to get DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 * OUTPUT:
 *      ptr_entry        -- DCTCP profile entry.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    CLX_TM_DCTCP_PROFILE_T                  *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_createDctcpProfile
 * PURPOSE:
 *      The function is used to create DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_createDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_lightning_tm_buf_setDctcpProfile
 * PURPOSE:
 *      The function is used to set DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 *      ptr_entry        -- DCTCP profile entry.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id,
    const CLX_TM_DCTCP_PROFILE_T            *ptr_entry);

/* FUNCTION NAME: hal_lightning_tm_buf_delDctcpProfile
 * PURPOSE:
 *      The function is used to delete DCTCP profile.
 * INPUT:
 *      unit             -- Device unit number.
 *      profile_id       -- DCTCP profile ID.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_delDctcpProfile(
    const UI32_T                            unit,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_lightning_tm_buf_setDctcpQueueConfig
 * PURPOSE:
 *      The function is used to set per queue DCTCP configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      profile_id       -- The DCTCP profile id is binded by the queue.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setDctcpQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    const UI32_T                            profile_id);

/* FUNCTION NAME: hal_lightning_tm_buf_getDctcpQueueConfig
 * PURPOSE:
 *      The function is used to get per queue DCTCP configuration.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_profile_id   -- The DCTCP profile id is binded by the queue.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getDctcpQueueConfig(
    const UI32_T                            unit,
    const UI32_T                            port,
    const CLX_TM_HANDLER_T                  handler,
    UI32_T                                  *ptr_profile_id);

/* FUNCTION NAME: hal_lightning_tm_buf_setPfcMapping
 * PURPOSE:
 *      The function is used to set the mapping of the PCP and the queue group.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 *      pcp_bitmap       -- The bit map of port control protocal.
 * OUTPUT:
 *      None.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setDscpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        dscp_count,
    UI32_T                              *ptr_dscp_list);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getDscpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_dscp_count,
    UI32_T                              *ptr_dscp_list);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setPcpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        pcp_bitmap);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getPcpPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setQueuePfcPriMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const UI32_T                        bitmap);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getQueuePfcPriMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_bitmap);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setPfcPriQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    const CLX_TM_HANDLER_T              handler);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getPfcPriQueueMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        bitmap,
    CLX_TM_HANDLER_T                    *ptr_handler);

/* FUNCTION NAME: hal_lightning_tm_buf_getPfcMapping
 * PURPOSE:
 *      The function is used to set the mapping of the PCP and the queue group.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      handler          -- Egress queue handler.
 * OUTPUT:
 *      ptr_pcp_bitmap   -- The bit map of port control protocal.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getPfcMapping(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    UI32_T                              *ptr_pcp_bitmap);

/* FUNCTION NAME: hal_lightning_tm_buf_getEgrBufGsCmTh
 * PURPOSE:
 *      The function is used to get max threshold of share pool usage under CM accountable area of EA.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_max_static_th -- max threshold of share pool usage under IA accountable area.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufGsCmTh(
    const UI32_T                            unit,
    UI32_T                                  *ptr_max_static_th);

/* FUNCTION NAME: hal_lightning_tm_buf_getEgrBufGsTh
 * PURPOSE:
 *      The function is used to get EA global share threshold.
 * INPUT:
 *      unit             -- Device unit number.
 * OUTPUT:
 *      ptr_gs_thd       -- global share threshold.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufGsTh(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    UI32_T                                  *ptr_gs_thd);

/* FUNCTION NAME: hal_lightning_tm_buf_getScType
 * PURPOSE:
 *      The function is used to get sc type.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- The port number.
 *      sc               -- The sc number.
 * OUTPUT:
 *      type_value       -- sc type value.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getScType(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            sc,
    UI32_T                                  *ptr_type_value);

/* FUNCTION NAME: hal_lightning_tm_buf_getEgrBufUmQueueMinTh
 * PURPOSE:
 *      The function is used to get per queue min threshold
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      queue_type       -- queue type.
 *      queue_id         -- queue ID.
 * OUTPUT:
 *      ptr_min_th   -- strict min threshold.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufUmQueueMinTh(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            queue_type,
    const UI32_T                            queue_id,
    UI32_T                                  *ptr_min_th);

/* FUNCTION NAME: hal_lightning_tm_buf_getIgrBufPcpHrm
 * PURPOSE:
 *      The function is used to get IA per PCP headroom.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp value.
 * OUTPUT:
 *      ptr_headroom     -- headroom threshold for the pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getIgrBufPcpHrm(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    const UI32_T                            port,
    const UI32_T                            pcp,
    UI32_T                                  *ptr_headroom);

/* FUNCTION NAME: hal_lightning_tm_buf_getIgrBufPcpMaxStaticTh
 * PURPOSE:
 *      The function is used to get IA max static threshold for the pcp.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      pcp              -- pcp.
 * OUTPUT:
 *      ptr_max_static_th -- max static threshold for the pcp.
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getIgrBufPcpMaxStaticTh(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    const UI32_T                            port,
    const UI32_T                            pcp,
    UI32_T                                  *ptr_max_static_th);


/* FUNCTION NAME: hal_lightning_tm_buf_updatePortStatus
 * PURPOSE:
 *      The function is used to update the port status with action.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- Physical port id.
 *      status           -- action (HAL_LIGHTNING_TM_PS_ACTIVED, HAL_LIGHTNING_TM_PS_NO_ACTIVED)
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_updatePortStatus(
    const UI32_T                            unit,
    const UI32_T                            port,
    const HAL_TM_SC_T                       status);

/* FUNCTION NAME: hal_lightning_tm_buf_getAopEmpty
 * PURPOSE:
 *      The function is used to get EA port empty.
 * INPUT:
 *      unit             -- Device unit number.
 *      port             -- CLX port number.
 * OUTPUT:
 *      None
 * RETURN:
 *      CLX_E_OK         -- Operate success.
 *      CLX_E_OTHER      -- Other error.
 * NOTES:
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getAopEmpty(
    const UI32_T            unit,
    const UI32_T            port);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getAoqEmpty(
    const UI32_T            unit,
    const UI32_T            port,
    const CLX_TM_HANDLER_T  handler);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getAiqEmpty(
    const UI32_T            unit,
    const UI32_T            port,
    const UI32_T            queue);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const CLX_TM_BUF_THRESHOLD_T        *ptr_entry);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getBufThreshold(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_THRESHOLD_T              *ptr_entry);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getBufOccupancy(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_OCCUPANCY_T              *ptr_entry);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getAopIdx(
    const UI32_T                            unit,
    const UI32_T                            port,
    UI32_T                                  *ptr_inst_idx,
    UI32_T                                  *ptr_sub_idx,
    UI32_T                                  *ptr_entry_idx);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getWarmSize(
    const UI32_T        unit,
    UI32_T              *ptr_size);

CLX_ERROR_NO_T
hal_lightning_tm_buf_deinitWarm(
    const UI32_T        unit,
    HAL_IO_WB_DB_T      *ptr_db);

CLX_ERROR_NO_T
hal_lightning_tm_buf_initWarm(
    const UI32_T        unit,
    HAL_IO_WB_DB_T      *ptr_db);

CLX_ERROR_NO_T
hal_lightning_tm_buf_initWarmSS(
    const UI32_T        unit,
    HAL_IO_WB_DB_T      *ptr_db);

CLX_ERROR_NO_T
hal_lightning_tm_buf_deinitWarmSS(
    const UI32_T        unit,
    HAL_IO_WB_DB_T      *ptr_db);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getAipSubIdx(
    const UI32_T                            unit,
    const UI32_T                            bin_idx,
    const UI32_T                            port,
    UI32_T                                  *ptr_sub_idx);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry);

CLX_ERROR_NO_T
hal_lightning_tm_buf_clearBufWatermark(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getBufWatermarkList(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        list_cnt,
    CLX_TM_BUF_WATERMARK_T              *ptr_entry_list);

CLX_ERROR_NO_T
hal_lightning_tm_buf_clearBufWatermarkList(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              *ptr_handler_list,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        list_cnt);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrGrpMap(
    const UI32_T                        unit,
    const UI32_T                        queue_id,
    const UI32_T                        queue_type,
    UI32_T                              *ptr_group);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getIaIdxFromPcp(
    const UI32_T                        unit,
    const UI32_T                        port,
    const UI32_T                        pcp,
    UI32_T                              *ptr_idx);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrBufPfcPcpRemapQueueEntry(
    const UI32_T                            unit,
    const UI32_T                            port,
    const UI32_T                            pfc_pcp,
    UI32_T                                  *ptr_queue_bitmap);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getFlowCtrlMode(
    const UI32_T                            unit,
    const UI32_T                            port,
    HAL_TM_FC_T                             *ptr_mode);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getIgrBufDpHrm(
    const UI32_T                            unit,
    const UI32_T                            inst_idx,
    const UI32_T                            entry_idx,
    UI32_T                                  *ptr_headroom);

UI32_T
hal_lightning_tm_buf_getAipIdx(
    const UI32_T                            unit,
    const UI32_T                            port);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getGlobalEcn(
    const UI32_T                            unit,
    UI32_T                                  *ptr_enable,
    UI32_T                                  *ptr_ecn_th);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setGlobalEcn(
    const UI32_T                            unit,
    const UI32_T                            enable,
    const UI32_T                            ecn_th);

CLX_ERROR_NO_T
hal_lightning_tm_buf_initTask(
    const   UI32_T      unit);

CLX_ERROR_NO_T
hal_lightning_tm_buf_deinitTask(
    const   UI32_T      unit);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setSnapshotEgrGlobal(
    const UI32_T        unit,
    const UI32_T        param0,
    const UI32_T        param1);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getSnapshotEgrGlobal(
    const UI32_T        unit,
    UI32_T              *ptr_param0,
    UI32_T              *ptr_param1);

CLX_ERROR_NO_T
hal_lightning_tm_buf_registerSnapshotCallback(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_lightning_tm_buf_deregisterSnapshotCallback(
    const UI32_T                        unit,
    const CLX_TM_SNAPSHOT_FUNC_T        notify_function,
    void                                *ptr_cookie);

CLX_ERROR_NO_T
hal_lightning_tm_buf_handleSnapshot(
    const UI32_T                        unit,
    const HAL_TM_SNAPSHOT_INTR_TYPE_T   snapshot_type);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setWatermarkToDb(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        value);

CLX_ERROR_NO_T
hal_lightning_tm_buf_updateWatermarkToDb(
    const UI32_T                        unit,
    const UI32_T                        port,
    const CLX_TM_HANDLER_T              handler,
    const CLX_TM_BUF_TYPE_T             type,
    const UI32_T                        usage);

CLX_ERROR_NO_T
hal_lightning_tm_buf_setPortDefault(
    const UI32_T                            unit,
    const UI32_T                            port);

CLX_ERROR_NO_T
hal_lightning_tm_buf_resetPortDefault(
    const UI32_T                            unit,
    const UI32_T                            port);

CLX_ERROR_NO_T
hal_lightning_tm_buf_getIosSlicePortIdx(
    const UI32_T                            unit,
    const UI32_T                            port,
    UI32_T                                  *ptr_inst_idx,
    UI32_T                                  *ptr_sub_idx,
    UI32_T                                  *ptr_entry_idx);

/* FUNCTION NAME:   hal_lightning_tm_buf_setMburstDetWindow
 * PURPOSE:
 *    Set the detection window of Mburst per system.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    dwin                    -- Detection window in unit of 25T.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setMburstDetWindow(
    const   UI32_T  unit,
    const   UI32_T  dwin);

/* FUNCTION NAME:   hal_lightning_tm_buf_getMburstDetWindow
 * PURPOSE:
 *    Get the detection window of Mburst per system.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 * OUTPUT:
 *    ptr_dwin                -- Detection window in unit of 25T.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getMburstDetWindow(
    const   UI32_T  unit,
    UI32_T          *ptr_dwin);

/* FUNCTION NAME:   hal_lightning_tm_buf_setMburstLogPeriod
 * PURPOSE:
 *    Set the logging period of Mburst per system.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    period                  -- Logging period in unit of detection window.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setMburstLogPeriod(
    const   UI32_T  unit,
    const   UI32_T  period);

/* FUNCTION NAME:   hal_lightning_tm_buf_getMburstLogPeriod
 * PURPOSE:
 *    Get the logging period of Mburst per system.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 * OUTPUT:
 *    ptr_period              -- Logging period in unit of detection window.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getMburstLogPeriod(
    const   UI32_T  unit,
    UI32_T          *ptr_period);

/* FUNCTION NAME:   hal_lightning_tm_buf_setMburstThreshold
 * PURPOSE:
 *    Set high and low threshold of Mburst of specific ingress/egress port/queue.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Physical port ID.
 *    handler                 -- The handler on which queue be set Mburst threshold.
 *    type                    -- Type of buffer for Mburst.
 *    th_high                 -- Mburst will be started if the buffer usage is higher than this value(unit is cell).
 *    th_low                  -- Mburst will be ended if the buffer usage is lower than this value(unit is cell).
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setMburstThreshold(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_TM_HANDLER_T    handler,
    const   CLX_TM_BUF_TYPE_T   type,
    const   UI32_T              th_high,
    const   UI32_T              th_low);

/* FUNCTION NAME:   hal_lightning_tm_buf_getMburstThreshold
 * PURPOSE:
 *    Get high and low threshold of Mburst of specific ingress/egress port/queue.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Physical port ID.
 *    handler                 -- The handler on which queue be set Mburst threshold.
 *    type                    -- Type of buffer for Mburst.
 * OUTPUT:
 *    ptr_th_high             -- Mburst will be started if the buffer usage is higher than this value(unit is cell).
 *    ptr_th_low              -- Mburst will be ended if the buffer usage is lower than this value(unit is cell).
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getMburstThreshold(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_TM_HANDLER_T    handler,
    const   CLX_TM_BUF_TYPE_T   type,
    UI32_T                      *ptr_th_high,
    UI32_T                      *ptr_th_low);

/* FUNCTION NAME:   hal_lightning_tm_buf_resetMburstDetection
 * PURPOSE:
 *    Reset Mburst detection engine.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Physical port ID.
 *    handler                 -- The handler on which queue be set Mburst threshold.
 *    type                    -- Type of buffer for Mburst.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_resetMburstDetection(
    const   UI32_T              unit,
    const   UI32_T              port,
    const   CLX_TM_HANDLER_T    handler,
    const   CLX_TM_BUF_TYPE_T   type);


/* FUNCTION NAME:   hal_lightning_tm_buf_getIgrMburstData
 * PURPOSE:
 *    Get Mburst data of ingress buffer pool.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Physical port ID.
 *    handler                 -- The handler on which queue be set Mburst threshold.
 *    type                    -- Type of buffer for Mburst.
 * OUTPUT:
 *    ptr_info                -- Mburst data of all bins of ingress buffer.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getIgrMburstData(
    const   UI32_T                      unit,
    const   UI32_T                      port,
    const   CLX_TM_HANDLER_T            handler,
    const   CLX_TM_BUF_TYPE_T           type,
            HAL_TM_IGR_MBURST_INFO_T    *ptr_info);

/* FUNCTION NAME:   hal_lightning_tm_buf_getEgrMburstData
 * PURPOSE:
 *    Get Mburst data of egress buffer pool.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Physical port ID.
 *    handler                 -- The handler on which queue be set Mburst threshold.
 *    type                    -- Type of buffer for Mburst.
 * OUTPUT:
 *    ptr_info                -- Mburst data of egress port/queue.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getEgrMburstData(
    const   UI32_T                  unit,
    const   UI32_T                  port,
    const   CLX_TM_HANDLER_T        handler,
    const   CLX_TM_BUF_TYPE_T       type,
            HAL_TM_MBURST_INFO_T    *ptr_info);

/* FUNCTION NAME:   hal_lightning_tm_buf_setSnapshotInterval
 * PURPOSE:
 *    Set the interval of snapshot task.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    interval                -- the interval of snapshot task.
 * OUTPUT:
 *    None.
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setSnapshotInterval(
    const UI32_T        unit,
    const UI32_T        interval);

/* FUNCTION NAME:   hal_lightning_tm_buf_getSnapshotInterval
 * PURPOSE:
 *    Get the interval of snapshot task.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 * OUTPUT:
 *    ptr_interval            -- the interval of snapshot task
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getSnapshotInterval(
    const UI32_T        unit,
    UI32_T              *ptr_interval);


/* FUNCTION NAME:   hal_lightning_tm_buf_setTmiDisablebyZeroBufState
 * PURPOSE:
 *    Set Port Tmi Disable by Zero buffer State.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Port id
 *    state                   -- Configure the state (bitmask, each bit a queue)
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setTmiDisablebyZeroBufState(
    const UI32_T        unit,
    const UI32_T        port,
    const UI8_T         state);

/* FUNCTION NAME:   hal_lightning_tm_buf_getTmiDisablebyZeroBufState
 * PURPOSE:
 *    Get Port Tmi Disable by Zero buffer State.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    port                    -- Port id
 * OUTPUT:
 *    state                   -- Get the state (bitmask, each bit a queue)
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_getTmiDisablebyZeroBufState(
    const UI32_T        unit,
    const UI32_T        port,
          UI8_T         *state);

/* FUNCTION NAME:   hal_lightning_tm_buf_setUserIgrBufDpMin
 * PURPOSE:
 *    Get DP_min of buffer.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    plane                   -- plane
 *    dp_min                  -- Set the dp_min                    
 * OUTPUT:
 *    
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setUserIgrBufDpMin(
    const UI32_T unit,
    const UI32_T plane,
    const UI32_T dp_min);

/* FUNCTION NAME:   hal_lightning_tm_buf_setUserIgrBufDpHrm
 * PURPOSE:
 *    Get DP_hrm of buffer.
 *
 * INPUT:
 *    unit                    -- Device unit number.
 *    plane                   -- plane
 *    dp_hrm                  -- Set the dp_headroom
 * OUTPUT:
 *   
 * RETURN:
 *    CLX_E_OK                -- Operate success.
 *    CLX_E_BAD_PARAMETER     -- Bad parameter.
 *
 * NOTES:
 *    None.
 */
CLX_ERROR_NO_T
hal_lightning_tm_buf_setUserIgrBufDpHrm(
    const UI32_T unit,
    const UI32_T plane,
    const UI32_T dp_hrm);
#endif /*end of HAL_LIGHTNING_TM_BUF_H*/
