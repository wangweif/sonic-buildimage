/*******************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Hangzhou Clounix Technology Limited. (C) 2013-2021
*
*  BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
*  THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("CLOUNIX SOFTWARE")
*  RECEIVED FROM CLOUNIX AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON
*  AN "AS-IS" BASIS ONLY. CLOUNIX EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
*  NEITHER DOES CLOUNIX PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
*  SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
*  SUPPLIED WITH THE CLOUNIX SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH
*  THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. CLOUNIX SHALL ALSO
*  NOT BE RESPONSIBLE FOR ANY CLOUNIX SOFTWARE RELEASES MADE TO BUYER'S
*  SPECIFICATION OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
*
*  BUYER'S SOLE AND EXCLUSIVE REMEDY AND CLOUNIX'S ENTIRE AND CUMULATIVE
*  LIABILITY WITH RESPECT TO THE CLOUNIX SOFTWARE RELEASED HEREUNDER WILL BE,
*  AT CLOUNIX'S OPTION, TO REVISE OR REPLACE THE CLOUNIX SOFTWARE AT ISSUE,
*  OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO
*  CLOUNIX FOR SUCH CLOUNIX SOFTWARE AT ISSUE.
*
*  THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE
*  WITH THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF
*  LAWS PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND
*  RELATED THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER
*  THE RULES OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*
*******************************************************************************/

/* FILE NAME:  hal_intr.h
 * PURPOSE:
 *      1. hal_intr.h provides HAL ISR manipulation APIs.
 *
 * NOTES:
 *
 */

#ifndef HAL_INTR_H
#define HAL_INTR_H

/* INCLUDE FILE DECLARATIONS
 */
#include <clx_error.h>
#include <clx_types.h>
#include <aml/aml.h>

/* NAMING CONSTANT DECLARATIONS
 */
#define HAL_INTR_SUBSYS_MAX_NUM     (16)

/* MACRO FUNCTION DECLARATIONS
 */
#define HAL_INTR_GET_INTR_INFO_PTR(unit) \
    (_ext_chip_control_block[unit].ptr_driver_info->ptr_intr_info)

/* Callback Functions for IRQ related registers R/W */
typedef void
(*HAL_INTR_THREAD_FUNC_T) (
    void            *ptr_argv);

typedef CLX_ERROR_NO_T
(*HAL_INTR_READ_FUNC_T) (
    const UI32_T    unit,
          UI32_T    *ptr_reg_val,
    const UI32_T    reg_type);

typedef CLX_ERROR_NO_T
(*HAL_INTR_WRITE_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    reg_val,
    const UI32_T    reg_type);

typedef CLX_ERROR_NO_T
(*HAL_ISR_HANDLE_FUNC_T) (
    const UI32_T    unit,
    const UI32_T    intr_cookie);

typedef enum
{
    /* this enum is the index into _hal_*_intr_reg[].
     * do not break the old code.
     */
    HAL_INTR_RX_CH0 = 0,             /* Interrupt for RX channel 0 */
    HAL_INTR_RX_CH1,                 /* Interrupt for RX channel 1 */
    HAL_INTR_RX_CH2,                 /* Interrupt for RX channel 2 */
    HAL_INTR_RX_CH3,                 /* Interrupt for RX channel 3 */
    HAL_INTR_TX_CH0,                 /* Interrupt for TX channel 0 */
    HAL_INTR_TX_CH1,                 /* Interrupt for TX channel 1 */
    HAL_INTR_TX_CH2,                 /* Interrupt for TX channel 2 */
    HAL_INTR_TX_CH3,                 /* Interrupt for TX channel 3 */
    HAL_INTR_DCE_IO_CORE1_CH,        /* Interrupt for DCC IO Core1 channel */
    HAL_INTR_DCE_IO_CORE2_CH,        /* Interrupt for DCC IO Core2 channel */
    HAL_INTR_DCE_IO_CORE3_CH,        /* Interrupt for DCC IO Core3 channel */
    HAL_INTR_DCE_ZC_CH,              /* Interrupt for DCC ZC channel */
    HAL_INTR_DCE_DMA_D2H_CH,         /* Interrupt for DCC DMA D2H channel */
    HAL_INTR_DCE_DMA_H2D_CH,         /* Interrupt for DCC DMA H2D channel */
    HAL_INTR_DCE_DMA_D2D_CH,         /* Interrupt for DCC DMA D2D channel */
    HAL_INTR_DCE_STAT_DMA_D2H,       /* Interrupt for DCC STATUS DMA D2H */
    HAL_INTR_DCE_STAT_DMA_H2D,       /* Interrupt for DCC STATUS DMA H2D */
    HAL_INTR_PORT_SPEED_CHANGE,      /* Interrupt for port speed change */
    HAL_INTR_PORT_LINK_STAT_CHANGE,  /* Interrupt for port link status change */
    HAL_INTR_PORT_OVER_HEAT,         /* Interrupt for port over heat */
    HAL_INTR_PORT_NOTIFY,            /* Interrupt for port notify */
    HAL_INTR_PORT_0_INST0,           /* Interrupt for port INT 0 of inst 0 */
    HAL_INTR_PORT_1_INST0,           /* Interrupt for port INT 1 of inst 0 */
    HAL_INTR_PORT_2_INST0,           /* Interrupt for port INT 2 of inst 0 */
    HAL_INTR_PORT_0_INST1,           /* Interrupt for port INT 0 of inst 1 */
    HAL_INTR_PORT_1_INST1,           /* Interrupt for port INT 1 of inst 1 */
    HAL_INTR_PORT_2_INST1,           /* Interrupt for port INT 2 of inst 1 */
    HAL_INTR_1588_INST0,             /* Interrupt for 1588 of inst 0 */
    HAL_INTR_1588_INST1,             /* Interrupt for 1588 of inst 1 */
    HAL_INTR_NVO3_PATH_AVGR,         /* Interrupt for NVO3 path average rate overflow */
    HAL_INTR_L3_PATH_AVGR,           /* Interrupt for L3 path average rate overflow */
    HAL_INTR_SRV_PATH_AVGR,          /* Interrupt for service path average rate overflow */

    HAL_INTR_L2_FIFO_NOTIFY,         /* Interrupt for L2 FIFO notification */
    HAL_INTR_L2_FIFO_FULL,           /* Interrupt for L2 FIFO full */
    HAL_INTR_PDMA_ERR,               /* Interrupt for packet DMA error */
    HAL_INTR_DCE_CHANNEL_ERR,        /* Interrupt for DCC channel error */
    HAL_INTR_PCI_PARITY_ERR,         /* Interrupt for PCI data parity check error */
    HAL_INTR_INT_LOW_LVL_INTR,       /* Interrupt for low level interrupt */
    HAL_INTR_PM_0_INST0,             /* Interrupt for pm INT 0 of inst 0 */
    HAL_INTR_PM_1_INST0,             /* Interrupt for pm INT 1 of inst 0 */
    HAL_INTR_PP_0_INST0,             /* Interrupt for pp INT 0 of inst 0 */
    HAL_INTR_PP_1_INST0,             /* Interrupt for pp INT 1 of inst 0 */
    HAL_INTR_PP_2_INST0,             /* Interrupt for pp INT 2 of inst 0 */
    HAL_INTR_PP_0_INST1,             /* Interrupt for pp INT 0 of inst 1 */
    HAL_INTR_PP_1_INST1,             /* Interrupt for pp INT 1 of inst 1 */
    HAL_INTR_PP_2_INST1,             /* Interrupt for pp INT 2 of inst 1 */
    HAL_INTR_TM_INST0,               /* Interrupt for tm of inst 0 */
    HAL_INTR_TM_INST1,               /* Interrupt for tm of inst 1 */
    HAL_INTR_TM_SRAM_INST0,          /* Interrupt for tm SRAM error of inst 0 */
    HAL_INTR_TM_SRAM_INST1,          /* Interrupt for tm SRAM error of inst 1 */
    HAL_INTR_PSYS,                   /* Interrupt for PortSYS */
    HAL_INTR_CP,                     /* Interrupt for inside CPSYS */
    HAL_INTR_CP_SRAM_INST0,          /* Interrupt for CPSYS SRAM error of inst 0 */
    HAL_INTR_CP_SRAM_INST1,          /* Interrupt for CPSYS SRAM error of inst 1 */
    HAL_INTR_INFO_INST0,             /* Interrupt for inside Info of inst 0 */
    HAL_INTR_INFO_INST1,             /* Interrupt for inside Info of inst 1 */
    HAL_INTR_SERDES_ETHX_SRAM_INST0, /* Interrupt for serdes ETHX SRAM error of inst 0 */
    HAL_INTR_SERDES_ETHC_SRAM_INST0, /* Interrupt for serdes ETHC SRAM error of inst 0 */
    HAL_INTR_SERDES_ETHX_SRAM_INST1, /* Interrupt for serdes ETHX SRAM error of inst 1 */
    HAL_INTR_SERDES_ETHC_SRAM_INST1, /* Interrupt for serdes ETHC SRAM error of inst 1 */
    HAL_INTR_SW_TEST_INST0,          /* Interrupt for SW Test of inst 0 */
    HAL_INTR_SW_TEST_INST1,          /* Interrupt for SW Test of inst 1 */
    HAL_INTR_PP_SRAM_INST0,          /* Interrupt for pp SRAM error of inst 0 */
    HAL_INTR_PP_SRAM_INST1,          /* Interrupt for pp SRAM error of inst 1 */

    HAL_INTR_PDIE_HI_0,              /* Interrupt for P-Die 0 HIGH */
    HAL_INTR_PDIE_HI_1,              /* Interrupt for P-Die 1 HIGH */
    HAL_INTR_PDIE_HI_2,              /* Interrupt for P-Die 2 HIGH */
    HAL_INTR_PDIE_HI_3,              /* Interrupt for P-Die 3 HIGH */
    HAL_INTR_PDIE_HI_PSYS_0,         /* Interrupt for P-Die 0 HIGH PortSYS */
    HAL_INTR_PDIE_HI_PSYS_1,         /* Interrupt for P-Die 1 HIGH PortSYS */
    HAL_INTR_PDIE_HI_PSYS_2,         /* Interrupt for P-Die 2 HIGH PortSYS */
    HAL_INTR_PDIE_HI_PSYS_3,         /* Interrupt for P-Die 3 HIGH PortSYS */
    HAL_INTR_PDIE_LO_0,              /* Interrupt for P-Die 0 Low */
    HAL_INTR_PDIE_LO_1,              /* Interrupt for P-Die 1 Low */
    HAL_INTR_PDIE_LO_2,              /* Interrupt for P-Die 2 Low */
    HAL_INTR_PDIE_LO_3,              /* Interrupt for P-Die 3 Low */
    HAL_INTR_PDIE_LO_SRAM_0,         /* Interrupt for P-Die 0 Low SRAM error */
    HAL_INTR_PDIE_LO_SRAM_1,         /* Interrupt for P-Die 1 Low SRAM error */
    HAL_INTR_PDIE_LO_SRAM_2,         /* Interrupt for P-Die 2 Low SRAM error */
    HAL_INTR_PDIE_LO_SRAM_3,         /* Interrupt for P-Die 3 Low SRAM error */
    HAL_INTR_PDIE_CP_0,              /* Interrupt for P-Die 0 CPSYS */
    HAL_INTR_PDIE_CP_1,              /* Interrupt for P-Die 1 CPSYS */
    HAL_INTR_PDIE_CP_2,              /* Interrupt for P-Die 2 CPSYS */
    HAL_INTR_PDIE_CP_3,              /* Interrupt for P-Die 3 CPSYS */
    HAL_INTR_PDIE_L2_FIFO_NOTIFY_0,  /* Interrupt for P-Die 0 L2 FIFO notification */
    HAL_INTR_PDIE_L2_FIFO_NOTIFY_1,  /* Interrupt for P-Die 1 L2 FIFO notification */
    HAL_INTR_PDIE_L2_FIFO_NOTIFY_2,  /* Interrupt for P-Die 2 L2 FIFO notification */
    HAL_INTR_PDIE_L2_FIFO_NOTIFY_3,  /* Interrupt for P-Die 3 L2 FIFO notification */
    HAL_INTR_PDIE_L2_FIFO_FULL_0,    /* Interrupt for P-Die 0 L2 FIFO full */
    HAL_INTR_PDIE_L2_FIFO_FULL_1,    /* Interrupt for P-Die 1 L2 FIFO full */
    HAL_INTR_PDIE_L2_FIFO_FULL_2,    /* Interrupt for P-Die 2 L2 FIFO full */
    HAL_INTR_PDIE_L2_FIFO_FULL_3,    /* Interrupt for P-Die 3 L2 FIFO full */
    HAL_INTR_PDIE_TM_DP0_0,          /* Interrupt for P-Die 0 TM Datapath 0 */
    HAL_INTR_PDIE_TM_DP1_0,          /* Interrupt for P-Die 0 TM Datapath 1 */
    HAL_INTR_PDIE_TM_DP0_1,          /* Interrupt for P-Die 1 TM Datapath 0 */
    HAL_INTR_PDIE_TM_DP1_1,          /* Interrupt for P-Die 1 TM Datapath 1 */

    HAL_INTR_PDIE_TM_DP0_2,          /* Interrupt for P-Die 2 TM Datapath 0 */
    HAL_INTR_PDIE_TM_DP1_2,          /* Interrupt for P-Die 2 TM Datapath 1 */
    HAL_INTR_PDIE_TM_DP0_3,          /* Interrupt for P-Die 3 TM Datapath 0 */
    HAL_INTR_PDIE_TM_DP1_3,          /* Interrupt for P-Die 3 TM Datapath 1 */
    HAL_INTR_PDIE_PP_INST0_0,        /* Interrupt for P-Die 0 PP of inst 0 */
    HAL_INTR_PDIE_PP_INST1_0,        /* Interrupt for P-Die 0 PP of inst 1 */
    HAL_INTR_PDIE_PP_INST0_1,        /* Interrupt for P-Die 1 PP of inst 0 */
    HAL_INTR_PDIE_PP_INST1_1,        /* Interrupt for P-Die 1 PP of inst 1 */
    HAL_INTR_PDIE_PP_INST0_2,        /* Interrupt for P-Die 2 PP of inst 0 */
    HAL_INTR_PDIE_PP_INST1_2,        /* Interrupt for P-Die 2 PP of inst 1 */
    HAL_INTR_PDIE_PP_INST0_3,        /* Interrupt for P-Die 3 PP of inst 0 */
    HAL_INTR_PDIE_PP_INST1_3,        /* Interrupt for P-Die 3 PP of inst 1 */
    HAL_INTR_PDIE_INFO_INST0_0,      /* Interrupt for P-Die 0 Info of inst 0 */
    HAL_INTR_PDIE_INFO_INST1_0,      /* Interrupt for P-Die 0 Info of inst 1 */
    HAL_INTR_PDIE_INFO_INST0_1,      /* Interrupt for P-Die 1 Info of inst 0 */
    HAL_INTR_PDIE_INFO_INST1_1,      /* Interrupt for P-Die 1 Info of inst 1 */
    HAL_INTR_PDIE_INFO_INST0_2,      /* Interrupt for P-Die 2 Info of inst 0 */
    HAL_INTR_PDIE_INFO_INST1_2,      /* Interrupt for P-Die 2 Info of inst 1 */
    HAL_INTR_PDIE_INFO_INST0_3,      /* Interrupt for P-Die 3 Info of inst 0 */
    HAL_INTR_PDIE_INFO_INST1_3,      /* Interrupt for P-Die 3 Info of inst 1 */
    HAL_INTR_TDIE_INFO,              /* Interrupt for T-Die Info */
    HAL_INTR_TDIE_CP,                /* Interrupt for T-Die inside CPSYS */
    HAL_INTR_TDIE_CP_SRAM,           /* Interrupt for T-Die inside CPSYS SRAM error */
    HAL_INTR_TDIE_PP,                /* Interrupt for T-Die pp */
    HAL_INTR_TDIE_PP_SRAM,           /* Interrupt for T-Die pp SRAM error */
    HAL_INTR_TDIE_TM,                /* Interrupt for T-Die tm */
    HAL_INTR_TDIE_TM_SRAM,           /* Interrupt for T-Die tm SRAM error */
    HAL_INTR_INFO_INST2,             /* Interrupt for inside Info of inst 2 */
    HAL_INTR_INFO_INST3,             /* Interrupt for inside Info of inst 3 */
    HAL_INTR_INFO_INST4,             /* Interrupt for inside Info of inst 4 */
    HAL_INTR_INFO_INST5,             /* Interrupt for inside Info of inst 5 */
    HAL_INTR_INFO_INST6,             /* Interrupt for inside Info of inst 6 */

    HAL_INTR_INFO_INST7,             /* Interrupt for inside Info of inst 7 */
    HAL_INTR_PP_0_INST2,             /* Interrupt for pp INT 0 of inst 2 */
    HAL_INTR_PP_0_INST3,             /* Interrupt for pp INT 0 of inst 3 */
    HAL_INTR_PP_0_INST4,             /* Interrupt for pp INT 0 of inst 4 */
    HAL_INTR_PP_0_INST5,             /* Interrupt for pp INT 0 of inst 5 */
    HAL_INTR_PP_0_INST6,             /* Interrupt for pp INT 0 of inst 6 */
    HAL_INTR_PP_0_INST7,             /* Interrupt for pp INT 0 of inst 7 */
    HAL_INTR_PP_SRAM_INST2,          /* Interrupt for pp SRAM error of inst 2 */
    HAL_INTR_PP_SRAM_INST3,          /* Interrupt for pp SRAM error of inst 3 */
    HAL_INTR_PP_SRAM_INST4,          /* Interrupt for pp SRAM error of inst 4 */
    HAL_INTR_PP_SRAM_INST5,          /* Interrupt for pp SRAM error of inst 5 */
    HAL_INTR_PP_SRAM_INST6,          /* Interrupt for pp SRAM error of inst 6 */
    HAL_INTR_PP_SRAM_INST7,          /* Interrupt for pp SRAM error of inst 7 */
    HAL_INTR_TM_INST2,               /* Interrupt for tm of inst 2 */
    HAL_INTR_TM_INST3,               /* Interrupt for tm of inst 3 */
    HAL_INTR_TM_SRAM_INST2,          /* Interrupt for tm SRAM error of inst 2 */
    HAL_INTR_TM_SRAM_INST3,          /* Interrupt for tm SRAM error of inst 3 */
    HAL_INTR_PDIE_PORT_0_0,          /* Interrupt for P-Die 0 port INT 0 */
    HAL_INTR_PDIE_PORT_0_1,          /* Interrupt for P-Die 1 port INT 0 */
    HAL_INTR_PDIE_PORT_0_2,          /* Interrupt for P-Die 2 port INT 0 */
    HAL_INTR_PDIE_PORT_0_3,          /* Interrupt for P-Die 3 port INT 0 */
    HAL_INTR_TDIE_ETHX_SRAM,         /* Interrupt for T-Die ethx serdes SRAM error */
    HAL_INTR_TDIE_CP_T_SRAM,         /* Interrupt for T-Die cpi SRAM error */
    HAL_INTR_TDIE_PCIE_SRAM,         /* Interrupt for T-Die pcie SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_0_0,     /* Interrupt for P-Die 0 ethl serdes 0 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_1_0,     /* Interrupt for P-Die 0 ethl serdes 1 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_2_0,     /* Interrupt for P-Die 0 ethl serdes 2 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_3_0,     /* Interrupt for P-Die 0 ethl serdes 3 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_4_0,     /* Interrupt for P-Die 0 ethl serdes 4 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_5_0,     /* Interrupt for P-Die 0 ethl serdes 5 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_6_0,     /* Interrupt for P-Die 0 ethl serdes 6 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_7_0,     /* Interrupt for P-Die 0 ethl serdes 7 SRAM error */

    HAL_INTR_PDIE_CP_P_SRAM_0,       /* Interrupt for P-Die 0 cp SRAM error */
    HAL_INTR_PDIE_PP_SRAM_INST0_0,   /* Interrupt for P-Die 0 pp SRAM error of inst 0 */
    HAL_INTR_PDIE_PP_SRAM_INST1_0,   /* Interrupt for P-Die 0 pp SRAM error of inst 1 */
    HAL_INTR_PDIE_TM_SRAM_INST0_0,   /* Interrupt for P-Die 0 tm SRAM error of inst 0 */
    HAL_INTR_PDIE_TM_SRAM_INST1_0,   /* Interrupt for P-Die 0 tm SRAM error of inst 1 */
    HAL_INTR_PDIE_ETHL_SRAM_0_1,     /* Interrupt for P-Die 1 ethl serdes 0 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_1_1,     /* Interrupt for P-Die 1 ethl serdes 1 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_2_1,     /* Interrupt for P-Die 1 ethl serdes 2 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_3_1,     /* Interrupt for P-Die 1 ethl serdes 3 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_4_1,     /* Interrupt for P-Die 1 ethl serdes 4 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_5_1,     /* Interrupt for P-Die 1 ethl serdes 5 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_6_1,     /* Interrupt for P-Die 1 ethl serdes 6 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_7_1,     /* Interrupt for P-Die 1 ethl serdes 7 SRAM error */
    HAL_INTR_PDIE_CP_P_SRAM_1,       /* Interrupt for P-Die 1 cp SRAM error */
    HAL_INTR_PDIE_PP_SRAM_INST0_1,   /* Interrupt for P-Die 1 pp SRAM error of inst 0 */
    HAL_INTR_PDIE_PP_SRAM_INST1_1,   /* Interrupt for P-Die 1 pp SRAM error of inst 1 */
    HAL_INTR_PDIE_TM_SRAM_INST0_1,   /* Interrupt for P-Die 1 tm SRAM error of inst 0 */
    HAL_INTR_PDIE_TM_SRAM_INST1_1,   /* Interrupt for P-Die 1 tm SRAM error of inst 1 */
    HAL_INTR_PDIE_ETHL_SRAM_0_2,     /* Interrupt for P-Die 2 ethl serdes 0 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_1_2,     /* Interrupt for P-Die 2 ethl serdes 1 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_2_2,     /* Interrupt for P-Die 2 ethl serdes 2 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_3_2,     /* Interrupt for P-Die 2 ethl serdes 3 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_4_2,     /* Interrupt for P-Die 2 ethl serdes 4 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_5_2,     /* Interrupt for P-Die 2 ethl serdes 5 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_6_2,     /* Interrupt for P-Die 2 ethl serdes 6 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_7_2,     /* Interrupt for P-Die 2 ethl serdes 7 SRAM error */
    HAL_INTR_PDIE_CP_P_SRAM_2,       /* Interrupt for P-Die 2 cp SRAM error */
    HAL_INTR_PDIE_PP_SRAM_INST0_2,   /* Interrupt for P-Die 2 pp SRAM error of inst 0 */
    HAL_INTR_PDIE_PP_SRAM_INST1_2,   /* Interrupt for P-Die 2 pp SRAM error of inst 1 */
    HAL_INTR_PDIE_TM_SRAM_INST0_2,   /* Interrupt for P-Die 2 tm SRAM error of inst 0 */
    HAL_INTR_PDIE_TM_SRAM_INST1_2,   /* Interrupt for P-Die 2 tm SRAM error of inst 1 */
    HAL_INTR_PDIE_ETHL_SRAM_0_3,     /* Interrupt for P-Die 3 ethl serdes 0 SRAM error */

    HAL_INTR_PDIE_ETHL_SRAM_1_3,     /* Interrupt for P-Die 3 ethl serdes 1 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_2_3,     /* Interrupt for P-Die 3 ethl serdes 2 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_3_3,     /* Interrupt for P-Die 3 ethl serdes 3 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_4_3,     /* Interrupt for P-Die 3 ethl serdes 4 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_5_3,     /* Interrupt for P-Die 3 ethl serdes 5 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_6_3,     /* Interrupt for P-Die 3 ethl serdes 6 SRAM error */
    HAL_INTR_PDIE_ETHL_SRAM_7_3,     /* Interrupt for P-Die 3 ethl serdes 7 SRAM error */
    HAL_INTR_PDIE_CP_P_SRAM_3,       /* Interrupt for P-Die 3 cp SRAM error */
    HAL_INTR_PDIE_PP_SRAM_INST0_3,   /* Interrupt for P-Die 3 pp SRAM error of inst 0 */
    HAL_INTR_PDIE_PP_SRAM_INST1_3,   /* Interrupt for P-Die 3 pp SRAM error of inst 1 */
    HAL_INTR_PDIE_TM_SRAM_INST0_3,   /* Interrupt for P-Die 3 tm SRAM error of inst 0 */
    HAL_INTR_PDIE_TM_SRAM_INST1_3,   /* Interrupt for P-Die 3 tm SRAM error of inst 1 */
    HAL_INTR_TCAM_ECC,               /* Interrupt for tcam ECC error */

    HAL_INTR_TYPE_LAST

} HAL_INTR_TYPE_T;

typedef struct
{
    UI32_T                      reg_type;     /* register type */
    UI32_T                      reg_val;      /* register value */

} HAL_INTR_REG_T;

typedef struct
{
    HAL_INTR_TYPE_T             intr_type;    /* interrupt type */
    HAL_ISR_HANDLE_FUNC_T       intr_func;    /* interrupt handler function */

} HAL_INTR_VEC_T;

typedef struct
{
    HAL_INTR_VEC_T              *ptr_intr_vec;
    HAL_INTR_REG_T              *ptr_intr_reg;
    UI32_T                      intr_num;

    AML_DEV_ISR_FUNC_T          intr_init;
    AML_DEV_ISR_FUNC_T          intr_deinit;
    AML_DEV_ISR_FUNC_T          intr_init_cfg;
    AML_DEV_ISR_FUNC_T          intr_deinit_cfg;
    AML_DEV_ISR_FUNC_T          intr_dispatcher;
    HAL_INTR_THREAD_FUNC_T      intr_low_dispatcher;

    HAL_INTR_READ_FUNC_T        intr_read_stat;     /* INT_STAT_*,     RO | CP_ERR_INT_STAT  RO */
    HAL_INTR_WRITE_FUNC_T       intr_set;           /* INT_SET_*,      WO | CP_ERR_INT_SET   WO */
    HAL_INTR_WRITE_FUNC_T       intr_clear;         /* INT_CLR_*,      WO | CP_ERR_INT_CLR   WO */
    HAL_INTR_READ_FUNC_T        intr_read_mask;     /* INT_MASK_VAL_*  RO | CP_ERR_INT_MASK  RW */
    HAL_INTR_WRITE_FUNC_T       intr_mask;          /* INT_MASK_SET_*  WO | CP_ERR_INT_MASK  RW */
    HAL_INTR_WRITE_FUNC_T       intr_unmask;        /* INT_MASK_CLR_*  WO | CP_ERR_INT_MASK  RW */
    HAL_INTR_READ_FUNC_T        intr_read_enable;   /* INT_EN_*        RW | CP_ERR_INT_EN    RW */
    HAL_INTR_WRITE_FUNC_T       intr_enable;        /* INT_EN_*        RW | CP_ERR_INT_EN    RW */
    HAL_INTR_WRITE_FUNC_T       intr_disable;       /* INT_EN_*        RW | CP_ERR_INT_EN    RW */

    CLX_ISRLOCK_ID_T            spin_lock;          /* INT register spinlock      */
    CLX_SEMAPHORE_ID_T          intr_sema;          /* low-pri IRQ task semaphore */
    CLX_THREAD_ID_T             intr_thread;        /* low-pri IRQ task thread    */

    HAL_INTR_READ_FUNC_T        intr_read_level;    /* INT_LVL_*       RW | CP_ERR_INT_LVL   RW */
    HAL_INTR_WRITE_FUNC_T       intr_set_level;     /* INT_LVL_*       RW | CP_ERR_INT_LVL   RW */
    HAL_INTR_WRITE_FUNC_T       intr_clear_level;   /* INT_LVL_*       RW | CP_ERR_INT_LVL   RW */

} HAL_INTR_INFO_T;

/* EXPORTED SUBPROGRAM SPECIFICATIONS
 */

/* -------------------------------------- Init and deinit */
CLX_ERROR_NO_T
hal_intr_init(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_intr_deinit(
    const UI32_T unit);

CLX_ERROR_NO_T
hal_intr_initCfg(
    const UI32_T        unit);

CLX_ERROR_NO_T
hal_intr_deinitCfg(
    const UI32_T        unit);

/* -------------------------------------- Reg operation */
CLX_ERROR_NO_T
hal_intr_enableIntr(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_disableIntr(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_maskIntr(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_unmaskIntr(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_setLevelIntr(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_clearLevelIntr(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

/* -------------------------------------- API and callbacks */
CLX_ERROR_NO_T
hal_intr_triggerEvent(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_triggerL2FifoEvent(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_triggerIfmonEvent(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_waitEvent(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type,
    const UI32_T            timeout);

CLX_ERROR_NO_T
hal_intr_waitL2FifoEvent(
    const UI32_T            unit,
    const UI32_T            timeout);

CLX_ERROR_NO_T
hal_intr_waitIfmonEvent(
    const UI32_T            unit,
    const UI32_T            timeout);

CLX_ERROR_NO_T
hal_intr_getEventCnt(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type,
          UI32_T            *ptr_cnt);

CLX_ERROR_NO_T
hal_intr_incrEventCnt(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

CLX_ERROR_NO_T
hal_intr_clearEventCnt(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

const C8_T *
hal_intr_getEventString(
    const UI32_T            unit,
    const HAL_INTR_TYPE_T   intr_type);

#endif  /* #ifndef HAL_INTR_H */
